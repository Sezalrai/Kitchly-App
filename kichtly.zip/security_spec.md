# Kitchly Firestore Security Specification

## 1. Data Invariants
1. User PII (`email`) lives exclusively in `/users/{userId}` and is readable/writable only by `request.auth.uid == userId`.
2. Every household document `/households/{householdId}` has an immutable `ownerId == request.auth.uid` on creation.
3. Every subcollection document under `/households/{householdId}/...` must pass the Master Gate (`get(/databases/$(database)/documents/households/$(householdId)).data.ownerId == request.auth.uid`) and enforce `ownerId == request.auth.uid` immutably.
4. All writes require `request.auth != null && request.auth.token.email_verified == true`.
5. All document IDs (`userId`, `householdId`, `itemId`, `memberId`, `taskId`, `planId`, `recipeId`, `notifId`) must match `^[a-zA-Z0-9_\\-]+$` and length `<= 128`.
6. All `createdAt` fields must equal `request.time` on create and remain immutable on update; all `updatedAt` fields must equal `request.time` on create and update.
7. Every string has an explicit `.size()` bound; every array has an explicit `.size() <= MAX` bound; every update uses explicit `affectedKeys().hasOnly(...)` action branches.

## 2. The "Dirty Dozen" Adversarial Payloads (All Must Return PERMISSION_DENIED)
1. **Unauthenticated read/write**: `auth = null` reading `/households/h1`.
2. **Unverified email write**: `auth = { uid: 'u1', token: { email_verified: false } }` creating `/users/u1`.
3. **Cross-user PII get**: `u2` reading `/users/u1`.
4. **Blanket collection list**: `u2` listing `/households` without `ownerId == u2` constraint.
5. **Identity spoofing on create**: `u1` creating `/households/h1` with `ownerId: 'u2'`.
6. **Shadow / ghost field injection**: `u1` creating `/households/h1/pantry/p1` with extra key `isAdmin: true`.
7. **ID poisoning**: `u1` writing `/households/h1/pantry/../../bad$id` or 200-char ID.
8. **Immutable field mutation**: `u1` updating `/households/h1` to change `ownerId` or `createdAt`.
9. **Client timestamp forgery**: `u1` creating `/households/h1/grocery/g1` with backdated `createdAt`.
10. **Unbounded string exhaustion**: `u1` setting `name` to a 5,000-character string.
11. **Unbounded array exhaustion**: `u1` setting `family/m1.allergies` to 50 items (`> 15`).
12. **Orphaned subcollection write**: `u1` writing `/households/nonexistent/pantry/p1` where parent household does not exist or belongs to `u2`.
