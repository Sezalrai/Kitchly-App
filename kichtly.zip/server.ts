import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const PRIMARY_MODEL = 'gemini-4-hydrogen';
const FALLBACK_MODEL = 'gemini-3.1-flash-lite';

function isTransientOrOverloadError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return /503|429|500|UNAVAILABLE|RESOURCE_EXHAUSTED|high demand|overloaded|temporarily|timeout|ECONNRESET/i.test(msg);
}

function formatFriendlyAIError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err);
  if (/PERMISSION_DENIED|API_KEY_INVALID|API key not valid|403|400/i.test(raw) && /key/i.test(raw)) {
    return 'Kitchly AI could not verify the server API key. Please check Settings > Secrets.';
  }
  if (/503|UNAVAILABLE|high demand|overloaded/i.test(raw)) {
    return 'Kitchly AI is experiencing a temporary traffic spike right now. Please try again in a few seconds.';
  }
  if (/429|RESOURCE_EXHAUSTED|quota/i.test(raw)) {
    return 'Kitchly AI reached its temporary request limit. Please wait a moment and try again.';
  }
  if (/GEMINI_API_KEY is not configured/i.test(raw)) {
    return 'Kitchly AI is not configured on this server yet.';
  }
  return 'Kitchly AI hit a temporary snag. Please try again in a moment.';
}

async function callGeminiWithFallback(
  ai: GoogleGenAI,
  buildRequest: (model: string) => Parameters<GoogleGenAI['models']['generateContent']>[0]
) {
  const modelsToTry = [PRIMARY_MODEL, FALLBACK_MODEL];
  let lastErr: unknown;

  for (let attempt = 0; attempt < modelsToTry.length; attempt++) {
    const model = modelsToTry[attempt];
    try {
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('Gemini request timeout')), 14000);
      });
      return await Promise.race([ai.models.generateContent(buildRequest(model)), timeoutPromise]);
    } catch (err) {
      lastErr = err;
      console.warn(`Gemini attempt ${attempt + 1} (${model}) failed:`, err instanceof Error ? err.message : err);
      if (!isTransientOrOverloadError(err)) {
        throw err;
      }
      if (attempt < modelsToTry.length - 1) {
        await new Promise((r) => setTimeout(r, 250));
      }
    }
  }
  throw lastErr;
}

function safeParseAIJson(text: string | undefined): Record<string, unknown> {
  const cleaned = (text || '{}')
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
  return JSON.parse(cleaned || '{}') as Record<string, unknown>;
}

function fastConfigForModel(model: string) {
  return model.startsWith('gemini-4')
    ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
    : {};
}

const RECIPE_SCHEMA = {
  type: Type.OBJECT,
  required: ['title', 'cuisine', 'dietType', 'prepTimeMins', 'servings', 'estimatedCostINR', 'description', 'ingredients', 'instructions'],
  properties: {
    title: {
      type: Type.STRING,
      description: 'Short clean dish name ONLY (2 to 6 words, e.g. "Paneer Bhurji & Toast"). Never put descriptions, ingredients, or parentheses here.',
    },
    cuisine: { type: Type.STRING, description: 'e.g. Indian, Italian, Continental, Asian' },
    dietType: { type: Type.STRING, description: 'Vegetarian, Vegan, Eggetarian, Non-vegetarian, or Pescatarian' },
    prepTimeMins: { type: Type.INTEGER },
    difficulty: { type: Type.STRING, description: 'Easy, Medium, or Chef' },
    servings: { type: Type.INTEGER },
    estimatedCostINR: { type: Type.NUMBER },
    description: { type: Type.STRING, description: '1-2 appetizing sentences describing the dish.' },
    allergens: { type: Type.ARRAY, items: { type: Type.STRING } },
    tags: { type: Type.ARRAY, items: { type: Type.STRING } },
    nutrition: {
      type: Type.OBJECT,
      properties: {
        calories: { type: Type.INTEGER },
        protein: { type: Type.INTEGER },
        carbs: { type: Type.INTEGER },
        fat: { type: Type.INTEGER },
      },
    },
    ingredients: {
      type: Type.ARRAY,
      description: '3 to 8 real ingredients needed for this recipe.',
      items: {
        type: Type.OBJECT,
        required: ['name', 'quantity', 'unit', 'category'],
        properties: {
          name: { type: Type.STRING },
          quantity: { type: Type.NUMBER },
          unit: { type: Type.STRING },
          category: { type: Type.STRING },
        },
      },
    },
    instructions: {
      type: Type.ARRAY,
      description: '3 to 5 clear, concise cooking steps.',
      items: { type: Type.STRING },
    },
  },
};

function sanitizeRecipeTitle(rawTitle: unknown): string {
  let title = String(rawTitle || 'Home Kitchen Special').trim();
  if (title.includes('(')) {
    title = title.replace(/\s*\([^)]*\)/g, '').replace(/\s*\([^)]*$/g, '').trim();
  }
  if (title.length > 55 && title.includes(' - ')) {
    title = title.split(' - ')[0].trim();
  }
  return (title || 'Home Kitchen Special').slice(0, 75);
}

function sanitizeRecipeFromAI(raw: Record<string, unknown>, slot?: string) {
  const cuisine = String(raw.cuisine || 'Continental');
  const lowerC = cuisine.toLowerCase();
  let image = '/src/assets/images/meal_lunch_mediterranean_1795377617245.jpg';
  if (slot === 'Breakfast') image = '/src/assets/images/meal_breakfast_bowl_1795377617419.jpg';
  else if (lowerC.includes('indian')) image = '/src/assets/images/meal_dinner_indian_1795377616543.jpg';
  else if (lowerC.includes('korean') || lowerC.includes('japanese') || lowerC.includes('chinese')) {
    image = '/src/assets/images/meal_asian_noodles_1795377616512.jpg';
  } else if (lowerC.includes('italian') || lowerC.includes('french')) {
    image = '/src/assets/images/meal_italian_pasta_1795377617361.jpg';
  } else if (lowerC.includes('mexican')) {
    image = '/src/assets/images/meal_mexican_tacos_1795377617513.jpg';
  } else if (lowerC.includes('thai')) {
    image = '/src/assets/images/meal_thai_curry_1795377617593.jpg';
  }

  const nutritionRaw = (raw.nutrition as Record<string, unknown>) || {};
  const ingredientsRaw = Array.isArray(raw.ingredients) ? raw.ingredients : [];
  const instructionsRaw = Array.isArray(raw.instructions) ? raw.instructions : [];

  return {
    id: `ai-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    title: sanitizeRecipeTitle(raw.title),
    cuisine: cuisine.slice(0, 50),
    dietType: String(raw.dietType || 'Vegetarian').slice(0, 35),
    prepTimeMins: Math.max(1, Number(raw.prepTimeMins) || 25),
    difficulty: ['Easy', 'Medium', 'Chef'].includes(String(raw.difficulty)) ? raw.difficulty : 'Easy',
    servings: Math.max(1, Number(raw.servings) || 2),
    estimatedCostINR: Math.max(0, Number(raw.estimatedCostINR) || 160),
    image,
    description: String(raw.description || 'Personalized dish tailored to your kitchen profile.').slice(0, 580),
    mealSlot: slot || 'Dinner',
    allergens: Array.isArray(raw.allergens) ? raw.allergens.slice(0, 15).map(String) : [],
    tags: Array.isArray(raw.tags) ? raw.tags.slice(0, 15).map(String) : ['Personalized'],
    isAiGenerated: true,
    nutrition: {
      calories: Number(nutritionRaw.calories) || 420,
      protein: Number(nutritionRaw.protein) || 18,
      carbs: Number(nutritionRaw.carbs) || 48,
      fat: Number(nutritionRaw.fat) || 14,
    },
    ingredients: ingredientsRaw.slice(0, 30).map((ing: Record<string, unknown>) => ({
      name: String(ing.name || 'Ingredient').slice(0, 100),
      quantity: Math.max(0.1, Number(ing.quantity) || 1),
      unit: String(ing.unit || 'pc').slice(0, 25),
      category: String(ing.category || 'Vegetables').slice(0, 40),
    })),
    instructions: instructionsRaw.length > 0 ? instructionsRaw.slice(0, 25).map((s) => String(s).slice(0, 300)) : ['Prepare ingredients and cook until tender.'],
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, geminiConfigured: Boolean(process.env.GEMINI_API_KEY) });
  });

  app.post('/api/ai/diet-plan', async (req, res) => {
    try {
      const {
        profile,
        pantryNames = [],
        language = 'en',
        replaceSlot,
        calorieTarget,
        availableFoods = [],
        strictFoodsOnly = false,
        cuisineRegion = 'all',
        portionPreference = 'auto',
      } = req.body || {};
      const ai = getGeminiClient();

      const strictExclusions = [
        ...(profile?.allergies || []),
        ...(profile?.customAllergies || []),
        ...(profile?.neverRecommend || []),
        ...(profile?.dislikedIngredients || []),
        ...(profile?.avoidedVegetables || []),
      ];

      const effectiveCalories = Number(calorieTarget) || Number(profile?.calorieTarget) || 0;
      const enteredFoods = Array.isArray(availableFoods)
        ? availableFoods.map((x: unknown) => String(x).trim()).filter(Boolean)
        : [];
      const regionNote =
        cuisineRegion === 'national'
          ? 'STRICTLY use National Indian cuisine (set cuisine: "Indian") across every meal (e.g., Masala Poha, Aloo Paratha, Rajma Chawal, Dal Tadka, Paneer Bhurji, Egg Curry, Chicken/Mutton Biryani, Besan Chilla, Bread Upma).'
          : cuisineRegion === 'international'
          ? 'STRICTLY use International (non-Indian) cuisines such as Italian, Mediterranean, Korean, Mexican, Japanese, Thai, or Continental.'
          : 'When cuisines allow, include a balanced mix of authentic Indian dishes (cuisine: "Indian") and international dishes.';

      const smallPortionRequested = portionPreference === 'small' || (effectiveCalories > 0 && effectiveCalories <= 1450);
      const dietaryPrefsLower: string[] = Array.isArray(profile?.dietaryPreferences)
        ? profile.dietaryPreferences.map((p: unknown) => String(p).toLowerCase())
        : [];
      const wantsZeroSugar = dietaryPrefsLower.some((p) => p.includes('zero sugar') || p.includes('sugar-free'));
      const wantsLowOil = dietaryPrefsLower.some((p) => p.includes('low oil') || p.includes('oil-free'));
      const wantsLessFat = dietaryPrefsLower.some((p) => p.includes('less fat') || p.includes('low-fat') || p.includes('low fat'));

      const cleanNutritionRules = [
        wantsZeroSugar
          ? 'ZERO SUGAR RULE (STRICT): Use ZERO added sugar, honey, jaggery, maple syrup, sweet sauces, or sugary desserts across all meals. Use spices, herbs, lemon, or unsweetened whole foods; omit sweet desserts or keep optionalDessert unsweetened.'
          : '',
        wantsLowOil
          ? 'LOW OIL RULE (STRICT): Cook using steaming, boiling, grilling, roasting, air-frying, or at most 0.5–1 tsp oil/ghee per dish. Never suggest deep-fried or heavy tadka/butter dishes.'
          : '',
        wantsLessFat
          ? 'LESS FAT / LOW-FAT RULE (STRICT): Keep dietary fat very low (around 20–35g total fat for the full day). Prefer lean proteins, boiled egg whites, low-fat curd/paneer, lentils, vegetables, and clear broths over cream, heavy cheese, or excess butter.'
          : '',
      ]
        .filter(Boolean)
        .join('\n');

      const calorieAndFoodConstraint = [
        effectiveCalories > 0
          ? `CRITICAL DAILY CALORIE TARGET: ALWAYS fulfill this request cleanly (never refuse or say cannot for ${effectiveCalories} kcal). The SUM of nutrition.calories across breakfast + morningSnack + lunch + eveningSnack + dinner MUST be close to ${effectiveCalories} kcal (within ±7% of ${effectiveCalories} kcal). Distribute thoughtfully (Breakfast ~25%, Morning Snack ~10%, Lunch ~30%, Evening Snack ~10%, Dinner ~25%).`
          : '',
        smallPortionRequested
          ? 'PORTION SIZE RULE: Use realistic SMALL / LIGHT portions (e.g. 1–2 slices of bread toast, 1 boiled egg, half-cup rice/dal, small paneer sandwich, light salad/soup) and keep each meal nutrition.calories accurate to that small portion so the full day totals cleanly.'
          : '',
        cleanNutritionRules,
        enteredFoods.length > 0
          ? `FOODS AVAILABLE WITH USER RIGHT NOW: ${JSON.stringify(enteredFoods)}. ${
              strictFoodsOnly
                ? 'STRICT MODE: Build all meals using ONLY these entered foods plus basic household spices/oil/water/salt so no extra shopping is needed.'
                : 'PRIORITIZE these entered foods (including bread, eggs, rice, etc.) across the meals of the day and keep extra ingredients minimal.'
            }`
          : '',
        regionNote,
      ]
        .filter(Boolean)
        .join('\n');

      const systemInstruction = `You are Kitchly's culinary & everyday nutrition planner. Never make medical claims or prescribe medical diets. Never refuse calorie planning requests—adjust portion sizes realistically (including small portions like 1 slice bread toast or half-bowl rice) so totals fit cleanly. Strictly respect Zero sugar, Low oil, Less fat, and allergies whenever requested. Always respond in natural, clear language matching locale "${language}" for dish descriptions and instructions (keep JSON keys in English).`;

      const prompt = replaceSlot
        ? `Generate ONE replacement meal for slot "${replaceSlot}" tailored to this user profile:
Food preferences: ${JSON.stringify(profile?.foodPreferences || [])}
Cuisines: ${JSON.stringify(profile?.cuisines || [])}
Loved foods: ${JSON.stringify(profile?.lovedFoods || [])}
STRICT EXCLUSIONS (NEVER USE): ${JSON.stringify(strictExclusions)}
Dietary tags: ${JSON.stringify(profile?.dietaryPreferences || [])}
Goals: ${JSON.stringify(profile?.goals || [])}
Spice level: ${profile?.spiceLevel || 'Medium'}
Max prep time: ${profile?.maxCookingTimeMins || 35} mins, Skill: ${profile?.skillLevel || 'Intermediate'}, Servings: ${profile?.householdSize || 2}, Daily budget (INR equiv): ${profile?.dailyBudget || 450}.
Available pantry items to prioritize: ${JSON.stringify(enteredFoods.length > 0 ? enteredFoods : pantryNames)}.
${effectiveCalories > 0 ? `Target daily calories: ${effectiveCalories} kcal — keep this single meal's calories proportional to its slot (${replaceSlot}).` : ''}
Note: If Indian / North Indian / South Indian / Punjabi / Hyderabadi cuisines are preferred, set "cuisine" to "Indian" (or the specific Indian style) and feature authentic homestyle Indian dishes; if international cuisines are preferred, honor them.`
        : `Generate a complete personalized 1-day meal plan (breakfast, morningSnack, lunch, eveningSnack, dinner, optionalDessert) and a 1-sentence summary tailored to this profile:
Food preferences: ${JSON.stringify(profile?.foodPreferences || [])}
Preferred cuisines: ${JSON.stringify(profile?.cuisines || [])}
Loved foods: ${JSON.stringify(profile?.lovedFoods || [])}
STRICT EXCLUSIONS (NEVER USE): ${JSON.stringify(strictExclusions)}
Dietary preferences: ${JSON.stringify(profile?.dietaryPreferences || [])}
Goals: ${JSON.stringify(profile?.goals || [])}
Spice level: ${profile?.spiceLevel || 'Medium'}
Max prep time: ${profile?.maxCookingTimeMins || 35} mins, Skill: ${profile?.skillLevel || 'Intermediate'}, People eating: ${profile?.householdSize || 2}, Daily food budget (INR equiv): ${profile?.dailyBudget || 450}.
Available pantry items: ${JSON.stringify(pantryNames)}.
${calorieAndFoodConstraint}`;

      if (replaceSlot) {
        const response = await callGeminiWithFallback(ai, (model) => ({
          model,
          contents: prompt,
          config: {
            ...fastConfigForModel(model),
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: RECIPE_SCHEMA,
          },
        }));
        const parsed = safeParseAIJson(response.text);
        return res.json({ meal: sanitizeRecipeFromAI(parsed, replaceSlot) });
      }

      const response = await callGeminiWithFallback(ai, (model) => ({
        model,
        contents: prompt,
        config: {
          ...fastConfigForModel(model),
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              breakfast: RECIPE_SCHEMA,
              morningSnack: RECIPE_SCHEMA,
              lunch: RECIPE_SCHEMA,
              eveningSnack: RECIPE_SCHEMA,
              dinner: RECIPE_SCHEMA,
              optionalDessert: RECIPE_SCHEMA,
            },
          },
        },
      }));

      const parsed = safeParseAIJson(response.text) as Record<string, any>;
      res.json({
        plan: {
          id: `plan-${Date.now()}`,
          generatedAt: new Date().toISOString(),
          summary: String(parsed.summary || 'Your personalized Kitchly diet plan.'),
          breakfast: sanitizeRecipeFromAI(parsed.breakfast || {}, 'Breakfast'),
          morningSnack: sanitizeRecipeFromAI(parsed.morningSnack || {}, 'Snack'),
          lunch: sanitizeRecipeFromAI(parsed.lunch || {}, 'Lunch'),
          eveningSnack: sanitizeRecipeFromAI(parsed.eveningSnack || {}, 'Snack'),
          dinner: sanitizeRecipeFromAI(parsed.dinner || {}, 'Dinner'),
          optionalDessert: parsed.optionalDessert ? sanitizeRecipeFromAI(parsed.optionalDessert, 'Dessert') : undefined,
        },
      });
    } catch (err) {
      console.error('Gemini diet-plan error:', err);
      res.status(503).json({ error: formatFriendlyAIError(err) });
    }
  });

  app.post('/api/ai/surprise-meal', async (req, res) => {
    try {
      const { mood = 'Surprise me', regionScope = 'all', profile, pantryNames = [], language = 'en' } = req.body || {};
      const ai = getGeminiClient();

      const strictExclusions = [
        ...(profile?.allergies || []),
        ...(profile?.customAllergies || []),
        ...(profile?.neverRecommend || []),
        ...(profile?.dislikedIngredients || []),
      ];

      const regionInstruction =
        regionScope === 'national'
          ? 'Suggest 4 diverse, authentic NATIONAL (Indian) recipes (e.g., Rajma Chawal, Egg Curry, Mutton/Meat Biryani, Aloo Paratha, Dal Tadka, Paneer Bhurji, Masala Poha, Chole) with cuisine set to "Indian".'
          : regionScope === 'international'
          ? 'Suggest 4 diverse INTERNATIONAL (non-Indian) global recipes (Italian, Korean, Mexican, Mediterranean, Thai, Japanese, French, etc.).'
          : 'Suggest 6 diverse recipes split evenly: 3 NATIONAL (Indian) classics (set cuisine: "Indian", such as Rajma Chawal, Egg Curry, Mutton/Chicken Biryani, Paneer Bhurji, Poha) and 3 INTERNATIONAL global recipes.';

      const response = await callGeminiWithFallback(ai, (model) => ({
        model,
        contents: `The user says "I Don't Know What to Eat" and chose mood: "${mood}".
${regionInstruction}
Match this profile:
- Food preferences: ${JSON.stringify(profile?.foodPreferences || [])}
- Cuisines: ${JSON.stringify(profile?.cuisines || [])}
- STRICT EXCLUSIONS (NEVER USE): ${JSON.stringify(strictExclusions)}
- Pantry available: ${JSON.stringify(pantryNames)}
- Max cook time: ${profile?.maxCookingTimeMins || 35} mins
- Daily budget (INR): ${profile?.dailyBudget || 450}
- Language locale: "${language}".`,
        config: {
          ...fastConfigForModel(model),
          systemInstruction: 'You are Kitchly, an empathetic culinary assistant. Respect the requested National (Indian) vs International split and strict allergies/dislikes completely.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              suggestions: {
                type: Type.ARRAY,
                items: RECIPE_SCHEMA,
              },
            },
          },
        },
      }));

      const parsed = safeParseAIJson(response.text);
      const suggestions = Array.isArray(parsed.suggestions)
        ? parsed.suggestions.map((r: Record<string, unknown>) => sanitizeRecipeFromAI(r))
        : [];
      res.json({ suggestions });
    } catch (err) {
      console.error('Gemini surprise-meal error:', err);
      res.status(503).json({ error: formatFriendlyAIError(err) });
    }
  });

  app.post('/api/ai/pantry-recipes', async (req, res) => {
    try {
      const { ingredients = [], regionScope = 'all', allergies = [], dislikes = [], language = 'en' } = req.body || {};
      const ai = getGeminiClient();

      const regionHint =
        regionScope === 'national'
          ? 'Return 4 authentic NATIONAL (Indian) recipes (with cuisine set to "Indian", e.g., Rajma Chawal, Egg Curry, Meat/Mutton Biryani, Aloo Masala, Paneer Bhurji) using those ingredients.'
          : regionScope === 'international'
          ? 'Return 4 diverse INTERNATIONAL (non-Indian) recipes using those ingredients.'
          : 'Return 6 recipes split cleanly: 3 NATIONAL (Indian, cuisine: "Indian" e.g. Rajma Chawal, Egg Curry, Mutton Biryani, Aloo Bhujia) and 3 INTERNATIONAL recipes.';

      const response = await callGeminiWithFallback(ai, (model) => ({
        model,
        contents: `Available kitchen ingredients: ${JSON.stringify(ingredients)}.
Strict allergies/exclusions: ${JSON.stringify([...allergies, ...dislikes])}.
Language locale: "${language}".
${regionHint}
Maximize use of the available ingredients and minimize missing items.`,
        config: {
          ...fastConfigForModel(model),
          systemInstruction: 'You are Kitchly Smart Pantry Chef. Prioritize recipes using listed ingredients first, keep missing items minimal, and respect National (Indian) vs International sectioning.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              recipes: {
                type: Type.ARRAY,
                items: RECIPE_SCHEMA,
              },
            },
          },
        },
      }));

      const parsed = safeParseAIJson(response.text);
      const recipes = Array.isArray(parsed.recipes)
        ? parsed.recipes.map((r: Record<string, unknown>) => sanitizeRecipeFromAI(r))
        : [];
      res.json({ recipes });
    } catch (err) {
      console.error('Gemini pantry-recipes error:', err);
      res.status(503).json({ error: formatFriendlyAIError(err) });
    }
  });

  app.post('/api/ai/chat', async (req, res) => {
    try {
      const { message, history = [], context = {}, language = 'en' } = req.body || {};
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Message is required.' });
      }
      const ai = getGeminiClient();

      const systemInstruction = `You are Kitchly AI, the all-in-one kitchen, cooking, grocery, budget, nutrition, and Kitchly app assistant. You assist with EVERYTHING — recipes, cooking steps, ingredient substitutions, nutrition estimates, food storage, weekly budgeting, household meal coordination, AND step-by-step guidance or instant actions inside Kitchly.

Complete Kitchly App Guide (so you can help the user navigate or configure any feature):
- Change Language ("language" or "settings"): Kitchly supports 12 languages — English (en), Hindi (hi), Bengali (bn), Punjabi (pa), Tamil (ta), Telugu (te), Marathi (mr), Gujarati (gu), Kannada (kn), Malayalam (ml), Odia (or), and Assamese (as). Users can switch language anytime via the Globe dropdown in the top bar, Account Settings, or Language Selection screen ("language"), OR ask you directly to switch it! If the user asks to switch to one of these languages right now (e.g. "switch to Hindi"), set "languageCodeToSet" to its 2-letter code and "suggestedActionScreen" to "language".
- Reset Kitchen / Start Fresh ("settings" or "onboarding"): In Account Settings, users can click "Start Fresh / Reset Kitchen" to clear old cart/pantry history and re-run the 4-step Setup Wizard.
- Budget & Currency ("budget" or "settings"): Set daily, weekly, and monthly grocery caps and choose currency (INR, USD, EUR, GBP, AED, SGD).
- Guided Grocery Trip Builder ("grocery-wizard"): 12-step interactive trip builder for stores (Blinkit, Zepto, Instamart, BigBasket, Walmart, Costco, Kroger, Target, Trader Joe's, etc.), household portions, meal vibes, dislikes, pantry check, and budget cap.
- Price Comparison ("price-comparison"): Compare product prices, complete baskets, and smart split orders (with sample/estimated prices).
- Smart Pantry ("pantry"): Track Fridge, Freezer, Pantry, and Spice Rack stock & expiry dates.
- Cook With What I Have ("cook-with-have"): Match recipes to ingredients already at home.
- I Don't Know What to Eat ("dont-know"): Mood-based meal picks.
- Personal Diet Planner ("diet-planner") & Weekly Meal Planner ("meal-planner") & Global Cuisine Explorer ("cuisine-explorer").
- Family Members ("family") & Cook / Maid Mode ("cook-mode" — distraction-free instructions translated into any of 12 languages).
- Install App on phone/desktop: Tap "Install App" in the top bar or Account Settings.

User's Live Kitchen Context:
- Household: ${context.householdName || 'My Kitchen'} (${context.country || 'India'}, ${context.currency || 'INR'})
- Current language locale: ${language} (ALWAYS reply in the user's current language, or the requested new language if they ask to switch!)
- Diet & Food preferences: ${JSON.stringify(context.foodPreferences || [])}
- Allergies (strict zero-tolerance): ${JSON.stringify(context.allergies || [])}
- Dislikes / Excluded ingredients: ${JSON.stringify(context.dislikes || [])}
- Pantry items (${Array.isArray(context.pantry) ? context.pantry.length : 0}): ${JSON.stringify(context.pantry || [])}
- Grocery list items pending: ${context.groceryCount ?? 0}
- Family members: ${context.familyCount ?? 1}
- Weekly budget (INR equiv): ${context.weeklyBudget || 'Not set yet'}, Daily budget: ${context.dailyBudget || 'Not set yet'}

Rules:
1. Give practical, specific, warm answers — never generic filler.
2. If user states a dislike or exclusion (e.g. "I don't like mushrooms"), confirm it and set "excludedIngredientToSave".
3. Whenever a Kitchly screen directly solves what the user asked about, set "suggestedActionScreen" to that exact screen slug and "actionLabel" to a concise 2–4 word button label (e.g. "Open Language Picker", "Set Weekly Budget", "Open Trip Builder").`;

      const conversationText = [
        ...history.slice(-8).map((h: { role: string; text: string }) => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.text}`),
        `User: ${message}`,
      ].join('\n');

      const response = await callGeminiWithFallback(ai, (model) => ({
        model,
        contents: conversationText,
        config: {
          ...fastConfigForModel(model),
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: { type: Type.STRING, description: 'Helpful, clear conversational reply covering culinary or app-usage help.' },
              excludedIngredientToSave: { type: Type.STRING, description: 'Single ingredient name if user asked to dislike/exclude it, else empty string.' },
              suggestedActionScreen: { type: Type.STRING, description: 'Best matching screen slug (dashboard, language, onboarding, diet-planner, meal-planner, cuisine-explorer, dont-know, cook-with-have, grocery-wizard, grocery-list, price-comparison, pantry, budget, family, cook-mode, notifications, household-profile, settings) or empty string.' },
              actionLabel: { type: Type.STRING, description: 'Short 2-4 word button label for suggestedActionScreen, or empty string.' },
              languageCodeToSet: { type: Type.STRING, description: '2-letter code (en, hi, bn, pa, ta, te, mr, gu, kn, ml, or, as) ONLY if user explicitly asked to switch app language, else empty string.' },
            },
          },
        },
      }));

      const parsed = safeParseAIJson(response.text);
      res.json({
        reply: String(parsed.reply || 'Here is how I can help with your kitchen.'),
        excludedIngredientToSave: parsed.excludedIngredientToSave ? String(parsed.excludedIngredientToSave).trim() : '',
        suggestedActionScreen: parsed.suggestedActionScreen ? String(parsed.suggestedActionScreen).trim() : '',
        actionLabel: parsed.actionLabel ? String(parsed.actionLabel).trim() : '',
        languageCodeToSet: parsed.languageCodeToSet ? String(parsed.languageCodeToSet).trim() : '',
      });
    } catch (err) {
      console.error('Gemini chat error:', err);
      res.status(503).json({ error: formatFriendlyAIError(err) });
    }
  });

  app.post('/api/ai/translate', async (req, res) => {
    try {
      const { title, description, instructions = [], targetLanguageName = 'Hindi' } = req.body || {};
      const ai = getGeminiClient();

      const response = await callGeminiWithFallback(ai, (model) => ({
        model,
        contents: `Translate this recipe accurately into ${targetLanguageName} using simple, clear kitchen cooking language:
Title: ${title}
Description: ${description}
Instructions: ${JSON.stringify(instructions)}`,
        config: {
          ...fastConfigForModel(model),
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              instructions: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
          },
        },
      }));

      const parsed = safeParseAIJson(response.text);
      res.json({ translated: parsed });
    } catch (err) {
      console.error('Gemini translate error:', err);
      res.status(503).json({ error: formatFriendlyAIError(err) });
    }
  });

  // AI Route 6: Guided Grocery Trip & Meal Plan Builder
  app.post('/api/ai/trip-plan', async (req, res) => {
    try {
      const {
        stores = [],
        adults = 1,
        kids = 0,
        portionsPerMeal = 2,
        mealSlots = ['Breakfast', 'Lunch', 'Dinner'],
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        appliances = ['Stove', 'Oven'],
        eatingStyles = ['No Restrictions'],
        vibes = ['Quick & Easy'],
        calorieTarget,
        allergies = [],
        dislikes = [],
        alreadyHave = [],
        weeklyBudgetINR = 8300,
        currency = 'USD',
        language = 'en',
      } = req.body || {};

      const ai = getGeminiClient();

      const mealCount = Math.min(6, Math.max(4, Array.isArray(days) ? days.length : 5));
      const prompt = `Build a practical grocery shopping & meal plan for a household:
- Preferred stores: ${JSON.stringify(stores)}
- Household: ${adults} adults, ${kids} kids (${portionsPerMeal} portions per meal)
- Meals to plan: ${JSON.stringify(mealSlots)}
- Cooking days: ${JSON.stringify(days)}
- Available appliances ONLY: ${JSON.stringify(appliances)}
- Eating styles: ${JSON.stringify(eatingStyles)}
- Meal vibes: ${JSON.stringify(vibes)}
- Calorie target per serving: ${calorieTarget ? `${calorieTarget} kcal` : 'Balanced family portions'}
- STRICT ALLERGIES (ZERO TOLERANCE): ${JSON.stringify(allergies)}
- DISLIKED INGREDIENTS (NEVER INCLUDE): ${JSON.stringify(dislikes)}
- Ingredients ALREADY AT HOME (omit from groceryItems): ${JSON.stringify(alreadyHave)}
- Total weekly grocery budget cap (INR equiv): ${weeklyBudgetINR} (currency: ${currency})${
        Number(weeklyBudgetINR) <= 2200
          ? '\n- TIGHT BUDGET MODE: Prioritize economical everyday family staples (lentils/dal, rice, atta/roti, poha, oats, potatoes, onions, tomatoes, seasonal veggies, eggs) and reuse shared ingredients across meals so the total cost fits comfortably below budget!'
          : ''
      }
- Language locale: "${language}".

Return strictly valid JSON:
1. "meals": Exactly ${mealCount} diverse, concise recipes across the selected days & mealSlots. Every meal MUST have a short clean "title" (2-6 words ONLY), a brief 1-sentence "description", 4-6 real "ingredients" with quantities, and 3-4 clear "instructions".
2. "groceryItems": 7 to 12 consolidated missing grocery items needed for those meals (excluding anything in alreadyHave), grouped with storeSection ("Produce", "Meat & Seafood", "Dairy & Eggs", "Bakery", "Canned & Pantry", "Condiments & Spices", "Frozen"), packNote, quantity, unit, category, and realistic estimatedCostINR such that the SUM of estimatedCostINR is strictly <= ${weeklyBudgetINR}.`;

      const response = await callGeminiWithFallback(ai, (model) => ({
        model,
        contents: prompt,
        config: {
          ...fastConfigForModel(model),
          systemInstruction:
            'You are Kitchly Smart Grocery & Meal Architect. Respond concisely and fast. Keep recipe titles to 2-6 words. Include real ingredients and 3-4 short steps per meal. Keep total grocery cost under the weekly budget.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            required: ['meals', 'groceryItems'],
            properties: {
              meals: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: [
                    'dayLabel',
                    'mealSlot',
                    'title',
                    'cuisine',
                    'dietType',
                    'prepTimeMins',
                    'servings',
                    'estimatedCostINR',
                    'description',
                    'ingredients',
                    'instructions',
                  ],
                  properties: {
                    dayLabel: { type: Type.STRING, description: 'e.g. MON · DINNER' },
                    mealSlot: { type: Type.STRING, description: 'Breakfast, Lunch, Dinner, or Snack' },
                    ...RECIPE_SCHEMA.properties,
                  },
                },
              },
              groceryItems: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: ['name', 'storeSection', 'packNote', 'quantity', 'unit', 'category', 'estimatedCostINR'],
                  properties: {
                    name: { type: Type.STRING },
                    storeSection: { type: Type.STRING },
                    packNote: { type: Type.STRING },
                    quantity: { type: Type.NUMBER },
                    unit: { type: Type.STRING },
                    category: { type: Type.STRING },
                    estimatedCostINR: { type: Type.NUMBER },
                  },
                },
              },
            },
          },
        },
      }));

      const parsed = safeParseAIJson(response.text);
      const meals = Array.isArray(parsed.meals)
        ? parsed.meals.map((m: Record<string, unknown>, idx: number) => ({
            ...sanitizeRecipeFromAI(m, String(m.mealSlot || 'Dinner')),
            dayLabel: String(m.dayLabel || `${String(days[idx % Math.max(1, days.length)] || 'MON').slice(0, 3).toUpperCase()} · ${String(m.mealSlot || 'MEAL').toUpperCase()}`),
          }))
        : [];
      const pantryLower = Array.isArray(alreadyHave) ? alreadyHave.map((x: unknown) => String(x).toLowerCase()) : [];
      let groceryItems = Array.isArray(parsed.groceryItems)
        ? parsed.groceryItems.map((g: Record<string, unknown>, idx: number) => ({
            id: `wiz-groc-${Date.now()}-${idx}`,
            name: String(g.name || 'Grocery Item').slice(0, 120),
            storeSection: String(g.storeSection || 'Produce'),
            packNote: String(g.packNote || '1 pack'),
            quantity: Math.max(0.1, Number(g.quantity) || 1),
            unit: String(g.unit || 'pc').slice(0, 25),
            category: String(g.category || 'Vegetables'),
            estimatedCostINR: Math.max(10, Number(g.estimatedCostINR) || 60),
            purchased: false,
            source: 'meal-plan' as const,
          }))
        : [];

      if (groceryItems.length === 0 && meals.length > 0) {
        const seen = new Set<string>();
        meals.forEach((meal) => {
          (meal.ingredients || []).forEach((ing) => {
            const key = ing.name.toLowerCase().trim();
            if (!key || seen.has(key)) return;
            if (pantryLower.some((p) => key.includes(p) || p.includes(key))) return;
            seen.add(key);
            groceryItems.push({
              id: `wiz-groc-${Date.now()}-${groceryItems.length}`,
              name: ing.name,
              storeSection:
                ing.category === 'Dairy'
                  ? 'Dairy & Eggs'
                  : ing.category === 'Meat and seafood'
                  ? 'Meat & Seafood'
                  : ing.category === 'Bakery'
                  ? 'Bakery'
                  : ing.category === 'Spices'
                  ? 'Condiments & Spices'
                  : ['Vegetables', 'Fruits'].includes(ing.category)
                  ? 'Produce'
                  : 'Canned & Pantry',
              packNote: `${ing.quantity} ${ing.unit}`,
              quantity: ing.quantity,
              unit: ing.unit,
              category: ing.category,
              estimatedCostINR: 75,
              purchased: false,
              source: 'meal-plan' as const,
            });
          });
        });
      }

      const safeBudgetCap = Math.max(200, Number(weeklyBudgetINR) || 1500);
      const totalItemsCost = groceryItems.reduce((sum, item) => sum + item.estimatedCostINR, 0);
      if (totalItemsCost > safeBudgetCap && groceryItems.length > 0) {
        const ratio = (safeBudgetCap * 0.92) / totalItemsCost;
        groceryItems = groceryItems.map((item) => ({
          ...item,
          estimatedCostINR: Math.max(10, Math.round(item.estimatedCostINR * ratio)),
        }));
      }

      res.json({ meals, groceryItems });
    } catch (err) {
      console.error('Gemini trip-plan error:', err);
      res.status(503).json({ error: formatFriendlyAIError(err) });
    }
  });

  app.post('/api/ai/explore-recipes', async (req, res) => {
    try {
      const {
        regionScope = 'all',
        cuisine = 'All',
        dietType = 'All',
        difficulty = 'All',
        nutritionTag = 'All',
        maxPrepMins = 60,
        maxBudgetINR = 500,
        searchQuery = '',
        profile,
        language = 'en',
      } = req.body || {};
      const ai = getGeminiClient();

      const strictExclusions = [
        ...(profile?.allergies || []),
        ...(profile?.customAllergies || []),
        ...(profile?.neverRecommend || []),
        ...(profile?.dislikedIngredients || []),
      ];

      const cuisineInstruction =
        cuisine !== 'All'
          ? cuisine
          : regionScope === 'national'
          ? 'Indian (National classics like Rajma Chawal, Egg Curry, Mutton Biryani, Paneer Bhurji, Dal Makhani)'
          : regionScope === 'international'
          ? 'Varied International Cuisines (excluding Indian)'
          : 'Mix of National (Indian) and International Global Cuisines';

      const response = await callGeminiWithFallback(ai, (model) => ({
        model,
        contents: `Generate 4 authentic, practical, delicious recipes matching these exact Global Cuisine Explorer filters:
- Cuisine: "${cuisineInstruction}"
- Diet type MUST strictly be: "${dietType === 'All' ? 'Varied (or user preference)' : dietType}"
- Difficulty level: "${difficulty === 'All' ? 'Easy or Medium' : difficulty}"
- Nutrition tag emphasis: "${nutritionTag === 'All' ? 'Balanced' : nutritionTag}"
- Maximum prep time (mins): <= ${maxPrepMins}
- Maximum cost per recipe (INR): <= ${maxBudgetINR}
- Optional search keyword / ingredient: "${searchQuery}"
- Household strict allergies / exclusions (NEVER INCLUDE): ${JSON.stringify(strictExclusions)}
- Language locale: "${language}".`,
        config: {
          ...fastConfigForModel(model),
          systemInstruction:
            'You are Kitchly Global Recipe Curator. Every returned recipe MUST strictly satisfy the requested cuisine, dietType, difficulty, prepTimeMins <= maxPrepMins, and estimatedCostINR <= maxBudgetINR. Give clean 2-6 word titles.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              recipes: {
                type: Type.ARRAY,
                items: RECIPE_SCHEMA,
              },
            },
          },
        },
      }));

      const parsed = safeParseAIJson(response.text);
      const recipes = Array.isArray(parsed.recipes)
        ? parsed.recipes.map((r: Record<string, unknown>) => {
            const cleaned = sanitizeRecipeFromAI(r);
            return {
              ...cleaned,
              cuisine: cuisine !== 'All' ? cuisine : cleaned.cuisine,
              dietType: dietType !== 'All' ? dietType : cleaned.dietType,
              difficulty: difficulty !== 'All' ? difficulty : cleaned.difficulty,
              prepTimeMins: Math.min(Number(maxPrepMins) || 60, cleaned.prepTimeMins),
              estimatedCostINR: Math.min(Number(maxBudgetINR) || 500, cleaned.estimatedCostINR),
            };
          })
        : [];
      res.json({ recipes });
    } catch (err) {
      console.error('Gemini explore-recipes error:', err);
      res.status(503).json({ error: formatFriendlyAIError(err) });
    }
  });

  app.all('/api/*', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  app.use((err: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (req.path.startsWith('/api/')) {
      console.error('API middleware error:', err);
      return res.status(500).json({ error: formatFriendlyAIError(err) });
    }
    return next(err);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(
      express.static(distDir, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('.webmanifest')) {
            res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
            res.setHeader('Cache-Control', 'no-cache');
          } else if (filePath.endsWith(`${path.sep}sw.js`)) {
            res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
          }
        },
      })
    );
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Kitchly server running at http://localhost:${PORT}`);
  });
}

startServer();
