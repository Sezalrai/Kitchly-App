export type LanguageCode =
  | 'en'
  | 'hi'
  | 'bn'
  | 'pa'
  | 'ta'
  | 'te'
  | 'mr'
  | 'gu'
  | 'kn'
  | 'ml'
  | 'or'
  | 'as';

export type CurrencyCode = 'INR' | 'USD' | 'EUR' | 'GBP' | 'AED' | 'SGD';

export type DietType =
  | 'Vegetarian'
  | 'Non-vegetarian'
  | 'Eggetarian'
  | 'Vegan'
  | 'Pescatarian'
  | 'Flexitarian';

export type CuisineType =
  | 'Indian'
  | 'Italian'
  | 'Continental'
  | 'Chinese'
  | 'Korean'
  | 'Japanese'
  | 'Mexican'
  | 'Mediterranean'
  | 'Thai'
  | 'American'
  | 'French'
  | 'Middle Eastern'
  | 'Turkish'
  | 'Spanish';

export type AllergyType =
  | 'Nut allergies'
  | 'Dairy intolerance'
  | 'Gluten intolerance'
  | 'Lactose intolerance'
  | 'Shellfish allergies'
  | 'Soy allergies'
  | 'Egg allergy';

export type DietaryPrefType =
  | 'Gluten-free'
  | 'Dairy-free'
  | 'Low-sodium'
  | 'High-protein'
  | 'Plant-based'
  | 'Zero sugar'
  | 'Low oil'
  | 'Less fat';

export type GoalType =
  | 'Balanced everyday eating'
  | 'Weight management'
  | 'Muscle gain'
  | 'High-protein meals'
  | 'Budget-friendly meals'
  | 'Family meal planning'
  | 'General nutrition improvement';

export type GroceryCategory =
  | 'Vegetables'
  | 'Fruits'
  | 'Dairy'
  | 'Meat and seafood'
  | 'Grains'
  | 'Bakery'
  | 'Spices'
  | 'Beverages'
  | 'Household essentials';

export type StorageLocation = 'Fridge' | 'Freezer' | 'Pantry' | 'Spice Rack';

export type AppScreen =
  | 'welcome'
  | 'auth'
  | 'language'
  | 'onboarding'
  | 'dashboard'
  | 'meal-planner'
  | 'diet-planner'
  | 'cuisine-explorer'
  | 'recipe-detail'
  | 'dont-know'
  | 'cook-with-have'
  | 'grocery-list'
  | 'grocery-wizard'
  | 'price-comparison'
  | 'pantry'
  | 'budget'
  | 'family'
  | 'cook-mode'
  | 'ai-assistant'
  | 'notifications'
  | 'household-profile'
  | 'settings'
  | 'community';

export interface RecipeIngredient {
  name: string;
  quantity: number;
  unit: string;
  category: GroceryCategory;
}

export interface RecipeNutrition {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface Recipe {
  id: string;
  title: string;
  cuisine: CuisineType | string;
  dietType: DietType;
  prepTimeMins: number;
  difficulty: 'Easy' | 'Medium' | 'Chef';
  servings: number;
  estimatedCostINR: number;
  image: string;
  description: string;
  ingredients: RecipeIngredient[];
  instructions: string[];
  nutrition: RecipeNutrition;
  allergens: string[];
  tags: string[];
  mealSlot?: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack' | 'Dessert';
  isFavorite?: boolean;
  isAiGenerated?: boolean;
}

export interface DietPlannerProfile {
  foodPreferences: DietType[];
  cuisines: string[];
  lovedFoods: string[];
  dislikedIngredients: string[];
  avoidedVegetables: string[];
  neverRecommend: string[];
  spiceLevel: 'Mild' | 'Medium' | 'Spicy' | 'Extra Spicy';
  allergies: string[];
  customAllergies: string[];
  dietaryPreferences: string[];
  goals: GoalType[];
  age?: number;
  activityLevel?: 'Sedentary' | 'Light' | 'Moderate' | 'Active';
  calorieTarget?: number;
  mealsPerDay: number;
  breakfastTime: string;
  lunchTime: string;
  dinnerTime: string;
  maxCookingTimeMins: number;
  skillLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  householdSize: number;
  dailyBudget: number;
  weeklyBudget: number;
  monthlyBudget: number;
}

export interface GeneratedDietPlan {
  id: string;
  generatedAt: string;
  summary: string;
  breakfast: Recipe;
  morningSnack: Recipe;
  lunch: Recipe;
  eveningSnack: Recipe;
  dinner: Recipe;
  optionalDessert?: Recipe;
}

export interface WeeklyMealSlot {
  day: string;
  breakfastId: string;
  lunchId: string;
  dinnerId: string;
  snackId: string;
}

export interface PantryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  category: GroceryCategory;
  purchaseDate: string;
  expiryDate: string;
  storageLocation: StorageLocation;
  lowStockThreshold: number;
}

export interface GroceryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  category: GroceryCategory;
  estimatedCostINR: number;
  purchased: boolean;
  source: 'meal-plan' | 'diet-plan' | 'recipe' | 'pantry-restock' | 'manual';
}

export interface FamilyMember {
  id: string;
  name: string;
  role: 'Owner' | 'Partner' | 'Child' | 'Parent' | 'Member';
  foodPreferences: DietType[];
  allergies: string[];
  likes: string[];
  dislikes: string[];
  mealPreferences: string;
  dietGoal: GoalType;
}

export interface CookTask {
  id: string;
  mealSlot: 'Breakfast' | 'Lunch' | 'Dinner' | 'Prep';
  recipeId: string;
  recipeTitle: string;
  scheduledTime: string;
  servings: number;
  notes: string;
  completed: boolean;
  checklistDone: number[];
}

export interface NotificationItem {
  id: string;
  type: 'expiry' | 'low-stock' | 'budget' | 'cook-task' | 'family-conflict';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  targetScreen?: AppScreen;
}

export interface HouseholdUser {
  id: string;
  name: string;
  email: string;
  householdName: string;
  country: string;
  currency: CurrencyCode;
  language: LanguageCode;
  onboarded: boolean;
  cookModePin: string;
}

export interface KitchlyState {
  user: HouseholdUser;
  dietProfile: DietPlannerProfile;
  currentDietPlan: GeneratedDietPlan | null;
  weeklyPlan: WeeklyMealSlot[];
  customRecipes: Recipe[];
  favoriteRecipeIds: string[];
  pantry: PantryItem[];
  groceryList: GroceryItem[];
  familyMembers: FamilyMember[];
  cookTasks: CookTask[];
  notifications: NotificationItem[];
  monthlySpentINR: number;
  estimatedSavingsINR: number;
}

export interface CreatorProfile {
  uid: string;
  displayName: string;
  bio: string;
  specialty: string;
  country: string;
  followersCount: number;
  postsCount: number;
  isPublic: boolean;
  isDemoCreator?: boolean;
}

export interface CommunityRecipePost {
  id: string;
  authorId: string;
  authorName: string;
  authorSpecialty: string;
  title: string;
  story: string;
  cuisine: CuisineType | string;
  dietType: DietType;
  difficulty: 'Easy' | 'Medium' | 'Chef';
  prepTimeMins: number;
  servings: number;
  estimatedCostINR: number;
  image: string;
  ingredients: RecipeIngredient[];
  steps: string[];
  tips: string[];
  tags: string[];
  likesCount: number;
  isPublic: boolean;
  createdAtISO: string;
  isDemoPost?: boolean;
}

