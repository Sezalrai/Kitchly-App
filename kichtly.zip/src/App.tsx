/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { AppShell } from './components/Layout';
import { KitchlyProvider, useKitchly } from './context/KitchlyContext';
import {
  AccountSettingsScreen,
  HouseholdProfileScreen,
  KitchlyAIAssistantScreen,
  NotificationsScreen,
} from './screens/AssistantAndAccount';
import { DashboardScreen } from './screens/DashboardScreen';
import { CommunityScreen } from './screens/CommunityScreen';
import {
  CookWithWhatIHaveScreen,
  DontKnowWhatToEatScreen,
} from './screens/DecisionAndPantryChef';
import { DietPlannerScreen } from './screens/DietPlannerScreen';
import {
  GroceryListScreen,
  PriceComparisonScreen,
} from './screens/GroceryAndComparison';
import { GroceryWizardScreen } from './screens/GroceryWizardScreen';
import {
  CookModeScreen,
  FamilyManagementScreen,
} from './screens/HouseholdAndCookMode';
import {
  GlobalCuisineExplorerScreen,
  RecipeDetailScreen,
  WeeklyMealPlannerScreen,
} from './screens/MealAndRecipeScreens';
import {
  BudgetManagementScreen,
  SmartPantryScreen,
} from './screens/PantryAndBudget';
import { OfflineIndicator } from './components/PWAComponents';
import {
  AuthScreen,
  LanguageSelectionScreen,
  OnboardingScreen,
  WelcomeScreen,
} from './screens/WelcomeAndAuth';

function KitchlyRouter() {
  const { screen, authLoading } = useKitchly();

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#FAF9F5] flex items-center justify-center">
        <div className="text-center space-y-2">
          <div className="font-display text-xl font-bold text-[#1F2421]">Kitchly</div>
          <p className="text-sm text-[#5B625C]">Preparing your kitchen...</p>
        </div>
      </div>
    );
  }

  if (screen === 'welcome') return <WelcomeScreen />;
  if (screen === 'auth') return <AuthScreen />;

  return (
    <AppShell>
      {screen === 'language' && <LanguageSelectionScreen />}
      {screen === 'onboarding' && <OnboardingScreen />}
      {screen === 'dashboard' && <DashboardScreen />}
      {screen === 'meal-planner' && <WeeklyMealPlannerScreen />}
      {screen === 'diet-planner' && <DietPlannerScreen />}
      {screen === 'cuisine-explorer' && <GlobalCuisineExplorerScreen />}
      {screen === 'community' && <CommunityScreen />}
      {screen === 'recipe-detail' && <RecipeDetailScreen />}
      {screen === 'dont-know' && <DontKnowWhatToEatScreen />}
      {screen === 'cook-with-have' && <CookWithWhatIHaveScreen />}
      {screen === 'grocery-list' && <GroceryListScreen />}
      {screen === 'grocery-wizard' && <GroceryWizardScreen />}
      {screen === 'price-comparison' && <PriceComparisonScreen />}
      {screen === 'pantry' && <SmartPantryScreen />}
      {screen === 'budget' && <BudgetManagementScreen />}
      {screen === 'family' && <FamilyManagementScreen />}
      {screen === 'cook-mode' && <CookModeScreen />}
      {screen === 'ai-assistant' && <KitchlyAIAssistantScreen />}
      {screen === 'notifications' && <NotificationsScreen />}
      {screen === 'household-profile' && <HouseholdProfileScreen />}
      {screen === 'settings' && <AccountSettingsScreen />}
    </AppShell>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <KitchlyProvider>
        <KitchlyRouter />
        <OfflineIndicator />
      </KitchlyProvider>
    </ErrorBoundary>
  );
}
