import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

if (import.meta.env.PROD) {
  const updateSW = registerSW({
    immediate: true,
    onNeedRefresh() {
      void updateSW(true);
    },
    onRegisteredSW(_swUrl, registration) {
      if (!registration) return;
      window.addEventListener('focus', () => {
        void registration.update();
      });
    },
  });
} else if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  // Ensure dev preview always loads latest edits cleanly without stale dev-sw cache
  void navigator.serviceWorker.getRegistrations().then((regs) => {
    regs.forEach((r) => {
      void r.unregister();
    });
  });
}

createRoot(document.getElementById('root')!).render(<App />);
