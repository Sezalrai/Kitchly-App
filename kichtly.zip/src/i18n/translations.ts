import { LanguageCode } from '../types/kitchly';

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  nativeName: string;
  speechLocale: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English', speechLocale: 'en-IN' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', speechLocale: 'hi-IN' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', speechLocale: 'bn-IN' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', speechLocale: 'pa-IN' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', speechLocale: 'ta-IN' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', speechLocale: 'te-IN' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', speechLocale: 'mr-IN' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', speechLocale: 'gu-IN' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', speechLocale: 'kn-IN' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', speechLocale: 'ml-IN' },
  { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ', speechLocale: 'or-IN' },
  { code: 'as', name: 'Assamese', nativeName: 'অসমীয়া', speechLocale: 'as-IN' },
];

export type TranslationKeys = {
  tagline: string;
  welcomeGreeting: string;
  dashboard: string;
  dontKnowWhatToEat: string;
  cookWithWhatIHave: string;
  mealPlanner: string;
  dietPlanner: string;
  cuisineExplorer: string;
  groceryList: string;
  priceComparison: string;
  smartPantry: string;
  budget: string;
  family: string;
  cookMode: string;
  aiAssistant: string;
  notifications: string;
  settings: string;
  householdProfile: string;
  breakfast: string;
  lunch: string;
  dinner: string;
  snacks: string;
  weeklyMealPlan: string;
  weeklyGroceryBudget: string;
  availableIngredients: string;
  upcomingExpiry: string;
  estimatedSavings: string;
  ingredients: string;
  instructions: string;
  prepTime: string;
  servings: string;
  calories: string;
  protein: string;
  carbs: string;
  fat: string;
  addToGrocery: string;
  markCompleted: string;
  completed: string;
  savePreferences: string;
  generatePlan: string;
  regenerate: string;
  replaceMeal: string;
  addIngredient: string;
  searchPlaceholder: string;
  signOut: string;
  selectLanguage: string;
  cookModeTitle: string;
  cookModeSubtitle: string;
  noBudgetAccessNote: string;
  voicePromptPlaceholder: string;
  listening: string;
  speakPrompt: string;
  clear: string;
  save: string;
  cancel: string;
  useSoon: string;
  lowStock: string;
  purchased: string;
  toBuy: string;
  comparePrices: string;
  sampleDataNotice: string;
};

const en: TranslationKeys = {
  tagline: 'Your Kitchen. Your Smarter Way.',
  welcomeGreeting: 'Good morning! What are we cooking today?',
  dashboard: 'Dashboard',
  dontKnowWhatToEat: "I Don't Know What to Eat",
  cookWithWhatIHave: 'Cook With What I Have',
  mealPlanner: 'Weekly Meal Planner',
  dietPlanner: 'My Personal Diet Planner',
  cuisineExplorer: 'Global Cuisine Explorer',
  groceryList: 'Grocery Shopping List',
  priceComparison: 'Smart Grocery Comparison',
  smartPantry: 'Smart Kitchen Inventory',
  budget: 'Budget Management',
  family: 'Family & Household',
  cookMode: 'Cook / Maid Mode',
  aiAssistant: 'Kitchly AI',
  notifications: 'Notifications',
  settings: 'Account Settings',
  householdProfile: 'Household Profile',
  breakfast: 'Breakfast',
  lunch: 'Lunch',
  dinner: 'Dinner',
  snacks: 'Recommended Snacks',
  weeklyMealPlan: 'Weekly Meal Plan',
  weeklyGroceryBudget: 'Weekly Grocery Budget',
  availableIngredients: 'Available Kitchen Ingredients',
  upcomingExpiry: 'Upcoming Expiry Reminders',
  estimatedSavings: 'Estimated Grocery Savings',
  ingredients: 'Ingredients',
  instructions: 'Cooking Instructions',
  prepTime: 'Prep Time',
  servings: 'Servings',
  calories: 'Calories',
  protein: 'Protein',
  carbs: 'Carbs',
  fat: 'Fat',
  addToGrocery: 'Add to Grocery List',
  markCompleted: 'Mark as Completed',
  completed: 'Completed',
  savePreferences: 'Save Preferences',
  generatePlan: 'Generate Personal Diet Plan',
  regenerate: 'Regenerate',
  replaceMeal: 'Replace Meal',
  addIngredient: 'Add Ingredient',
  searchPlaceholder: 'Search recipes, cuisines, ingredients...',
  signOut: 'Sign Out',
  selectLanguage: 'Select Language',
  cookModeTitle: 'Daily Cooking Guide',
  cookModeSubtitle: 'Simple step-by-step instructions for today’s meals',
  noBudgetAccessNote: 'Simplified kitchen view — private budgets and billing are hidden.',
  voicePromptPlaceholder: 'Ask Kitchly AI in your language or tap mic...',
  listening: 'Listening...',
  speakPrompt: 'Speak',
  clear: 'Clear',
  save: 'Save',
  cancel: 'Cancel',
  useSoon: 'Use Soon',
  lowStock: 'Low Stock',
  purchased: 'Purchased',
  toBuy: 'To Buy',
  comparePrices: 'Compare Grocery Prices',
  sampleDataNotice: 'Showing clearly labeled sample & estimated prices until partner grocery APIs are connected.',
};

const hi: TranslationKeys = {
  ...en,
  tagline: 'आपकी रसोई। आपका स्मार्ट तरीका।',
  welcomeGreeting: 'सुप्रभात! आज हम क्या पका रहे हैं?',
  dashboard: 'डैशबोर्ड',
  dontKnowWhatToEat: 'समझ नहीं आ रहा क्या खाऊँ',
  cookWithWhatIHave: 'घर में मौजूद सामग्री से पकाएँ',
  mealPlanner: 'साप्ताहिक मील प्लानर',
  dietPlanner: 'मेरा पर्सनल डाइट प्लानर',
  cuisineExplorer: 'ग्लोबल व्यंजन एक्सप्लोरर',
  groceryList: 'किराना खरीदारी सूची',
  priceComparison: 'स्मार्ट किराना तुलना',
  smartPantry: 'स्मार्ट किचन इन्वेंटरी',
  budget: 'बजट प्रबंधन',
  family: 'परिवार और घर',
  cookMode: 'कुक / मेड मोड',
  aiAssistant: 'किचली AI',
  notifications: 'सूचनाएँ',
  settings: 'खाता सेटिंग्स',
  householdProfile: 'पारिवारिक प्रोफ़ाइल',
  breakfast: 'नाश्ता',
  lunch: 'दोपहर का भोजन',
  dinner: 'रात का खाना',
  snacks: 'सुझाए गए स्नैक्स',
  weeklyMealPlan: 'साप्ताहिक भोजन योजना',
  weeklyGroceryBudget: 'साप्ताहिक किराना बजट',
  availableIngredients: 'रसोई में उपलब्ध सामग्री',
  upcomingExpiry: 'समाप्ति अनुस्मारक',
  estimatedSavings: 'अनुमानित किराना बचत',
  ingredients: 'सामग्री',
  instructions: 'बनाने की विधि',
  prepTime: 'तैयारी का समय',
  servings: 'सर्विंग्स',
  calories: 'कैलोरी',
  protein: 'प्रोटीन',
  carbs: 'कार्ब्स',
  fat: 'फैट',
  addToGrocery: 'खरीदारी सूची में जोड़ें',
  markCompleted: 'पूर्ण चिह्नित करें',
  completed: 'पूर्ण',
  savePreferences: 'पसंद सहेजें',
  generatePlan: 'पर्सनल डाइट प्लान बनाएँ',
  regenerate: 'फिर से बनाएँ',
  replaceMeal: 'भोजन बदलें',
  addIngredient: 'सामग्री जोड़ें',
  searchPlaceholder: 'व्यंजन, सामग्री खोजें...',
  signOut: 'साइन आउट',
  selectLanguage: 'भाषा चुनें',
  cookModeTitle: 'दैनिक कुकिंग गाइड',
  cookModeSubtitle: 'आज के भोजन के लिए सरल चरण-दर-चरण निर्देश',
  noBudgetAccessNote: 'सरल रसोई दृश्य — निजी बजट और खाता जानकारी छिपी हुई है।',
  voicePromptPlaceholder: 'किचली AI से पूछें या माइक दबाएँ...',
  listening: 'सुन रहे हैं...',
  speakPrompt: 'बोलें',
  useSoon: 'जल्द उपयोग करें',
  lowStock: 'कम स्टॉक',
  purchased: 'खरीदा गया',
  toBuy: 'खरीदना है',
  comparePrices: 'किराना कीमतें तुलना करें',
};

const bn: TranslationKeys = {
  ...en,
  tagline: 'আপনার রান্নাঘর। আপনার স্মার্ট উপায়।',
  welcomeGreeting: 'সুপ্রভাত! আজ আমরা কী রান্না করছি?',
  dashboard: 'ড্যাশবোর্ড',
  dontKnowWhatToEat: 'কী খাব বুঝতে পারছি না',
  cookWithWhatIHave: 'ঘরে যা আছে তা দিয়ে রাঁধুন',
  mealPlanner: 'সাপ্তাহিক মিল প্ল্যানার',
  dietPlanner: 'আমার পার্সোনাল ডায়েট প্ল্যানার',
  cuisineExplorer: 'গ্লোবাল রেসিপি এক্সপ্লোরার',
  groceryList: 'বাজারের তালিকা',
  priceComparison: 'স্মার্ট গ্রোসারি তুলনা',
  smartPantry: 'স্মার্ট রান্নাঘর ইনভেন্টরি',
  budget: 'বাজেট পরিচালনা',
  family: 'পরিবার ও গৃহস্থালি',
  cookMode: 'কুক / মেইড মোড',
  aiAssistant: 'কিচলি AI',
  notifications: 'বিজ্ঞপ্তি',
  settings: 'অ্যাকাউন্ট সেটিংস',
  breakfast: 'সকালের নাশতা',
  lunch: 'দুপুরের খাবার',
  dinner: 'রাতের খাবার',
  snacks: 'প্রস্তাবিত স্ন্যাকস',
  ingredients: 'উপকরণ',
  instructions: 'রান্নার নির্দেশনা',
  markCompleted: 'সম্পন্ন চিহ্নিত করুন',
  completed: 'সম্পন্ন',
  selectLanguage: 'ভাষা নির্বাচন করুন',
  cookModeTitle: 'দৈনিক রান্নার নির্দেশিকা',
  cookModeSubtitle: 'আজকের খাবারের সহজ ধাপে ধাপে নির্দেশনা',
  noBudgetAccessNote: 'সহজ রান্নাঘর ভিউ — ব্যক্তিগত বাজেট ও অ্যাকাউন্ট তথ্য গোপন রাখা হয়েছে।',
};

const pa: TranslationKeys = {
  ...en,
  tagline: 'ਤੁਹਾਡੀ ਰਸੋਈ। ਤੁਹਾਡਾ ਸਮਾਰਟ ਤਰੀਕਾ।',
  welcomeGreeting: 'ਸ਼ੁਭ ਸਵੇਰ! ਅੱਜ ਅਸੀਂ ਕੀ ਬਣਾ ਰਹੇ ਹਾਂ?',
  dashboard: 'ਡੈਸ਼ਬੋਰਡ',
  dontKnowWhatToEat: 'ਸਮਝ ਨਹੀਂ ਆ ਰਿਹਾ ਕੀ ਖਾਵਾਂ',
  cookWithWhatIHave: 'ਘਰ ਮੌਜੂਦ ਸਮੱਗਰੀ ਨਾਲ ਪਕਾਓ',
  mealPlanner: 'ਹਫ਼ਤਾਵਾਰੀ ਮੀਲ ਪਲੈਨਰ',
  dietPlanner: 'ਮੇਰਾ ਨਿੱਜੀ ਡਾਈਟ ਪਲੈਨਰ',
  cuisineExplorer: 'ਗਲੋਬਲ ਪਕਵਾਨ ਖੋਜੋ',
  groceryList: 'ਕਰਿਆਨੇ ਦੀ ਸੂਚੀ',
  priceComparison: 'ਸਮਾਰਟ ਕੀਮਤ ਤੁਲਨਾ',
  smartPantry: 'ਸਮਾਰਟ ਰਸੋਈ ਸਟਾਕ',
  budget: 'ਬਜਟ ਪ੍ਰਬੰਧਨ',
  family: 'ਪਰਿਵਾਰ ਅਤੇ ਘਰ',
  cookMode: 'ਕੁੱਕ / ਮੇਡ ਮੋਡ',
  aiAssistant: 'ਕਿਚਲੀ AI',
  notifications: 'ਸੂਚਨਾਵਾਂ',
  settings: 'ਖਾਤਾ ਸੈਟਿੰਗਾਂ',
  breakfast: 'ਨਾਸ਼ਤਾ',
  lunch: 'ਦੁਪਹਿਰ ਦਾ ਖਾਣਾ',
  dinner: 'ਰਾਤ ਦਾ ਖਾਣਾ',
  snacks: 'ਸਨੈਕਸ',
  ingredients: 'ਸਮੱਗਰੀ',
  instructions: 'ਬਣਾਉਣ ਦਾ ਤਰੀਕਾ',
  markCompleted: 'ਪੂਰਾ ਹੋਇਆ ਚਿੰਨ੍ਹਿਤ ਕਰੋ',
  completed: 'ਪੂਰਾ ਹੋਇਆ',
  selectLanguage: 'ਭਾਸ਼ਾ ਚੁਣੋ',
  cookModeTitle: 'ਰੋਜ਼ਾਨਾ ਖਾਣਾ ਬਣਾਉਣ ਦੀ ਗਾਈਡ',
  cookModeSubtitle: 'ਅੱਜ ਦੇ ਖਾਣੇ ਲਈ ਆਸਾਨ ਕਦਮ-ਦਰ-ਕਦਮ ਹਦਾਇਤਾਂ',
};

const ta: TranslationKeys = {
  ...en,
  tagline: 'உங்கள் சமையலறை. உங்கள் ஸ்மார்ட் வழி.',
  welcomeGreeting: 'காலை வணக்கம்! இன்று நாம் என்ன சமைக்கிறோம்?',
  dashboard: 'முகப்பு',
  dontKnowWhatToEat: 'என்ன சாப்பிடுவது என்று தெரியவில்லை',
  cookWithWhatIHave: 'உள்ள பொருட்களில் சமைக்கவும்',
  mealPlanner: 'வாராந்திர உணவுத் திட்டம்',
  dietPlanner: 'என் தனிப்பட்ட டயட் திட்டம்',
  cuisineExplorer: 'உலக உணவு வகைகள்',
  groceryList: 'மளிகைப் பட்டியல்',
  priceComparison: 'ஸ்மார்ட் விலை ஒப்பீடு',
  smartPantry: 'ஸ்மார்ட் சமையலறை இருப்பு',
  budget: 'பட்ஜெட் மேலாண்மை',
  family: 'குடும்பம்',
  cookMode: 'சமையல்காரர் முறை',
  aiAssistant: 'கிட்ச்லி AI',
  notifications: 'அறிவிப்புகள்',
  settings: 'அமைப்புகள்',
  breakfast: 'காலை உணவு',
  lunch: 'மதிய உணவு',
  dinner: 'இரவு உணவு',
  snacks: 'சிற்றுண்டிகள்',
  ingredients: 'தேவையான பொருட்கள்',
  instructions: 'செய்முறை',
  markCompleted: 'முடிந்ததாக குறிக்கவும்',
  completed: 'முடிந்தது',
  selectLanguage: 'மொழியைத் தேர்ந்தெடுக்கவும்',
  cookModeTitle: 'தினசரி சமையல் வழிகாட்டி',
  cookModeSubtitle: 'இன்றைய உணவுக்கான எளிய படிப்படியான வழிமுறைகள்',
};

const te: TranslationKeys = {
  ...en,
  tagline: 'మీ వంటగది. మీ స్మార్ట్ మార్గం.',
  welcomeGreeting: 'శుభోదయం! ఈ రోజు మనం ఏం వండుతున్నాము?',
  dashboard: 'డ్యాష్‌బోర్డ్',
  dontKnowWhatToEat: 'ఏం తినాలో తెలియడం లేదు',
  cookWithWhatIHave: 'ఇంట్లో ఉన్న వాటితో వండండి',
  mealPlanner: 'వారపు భోజన ప్రణాళిక',
  dietPlanner: 'నా వ్యక్తిగత డైట్ ప్లానర్',
  cuisineExplorer: 'గ్లోబల్ వంటకాల అన్వేషణ',
  groceryList: 'కిరాణా జాబితా',
  priceComparison: 'స్మార్ట్ ధరల పోలిక',
  smartPantry: 'స్మార్ట్ కిచెన్ నిల్వ',
  budget: 'బడ్జెట్ నిర్వహణ',
  family: 'కుటుంబం',
  cookMode: 'కుక్ / మెయిడ్ మోడ్',
  aiAssistant: 'కిచ్లీ AI',
  notifications: 'నోటిఫికేషన్‌లు',
  settings: 'సెట్టింగ్‌లు',
  breakfast: 'అల్పాహారం',
  lunch: 'మధ్యాహ్న భోజనం',
  dinner: 'రాత్రి భోజనం',
  snacks: 'స్నాక్స్',
  ingredients: 'పదార్థాలు',
  instructions: 'తయారీ విధానం',
  markCompleted: 'పూర్తయినట్లు గుర్తించండి',
  completed: 'పూర్తయింది',
  selectLanguage: 'భాషను ఎంచుకోండి',
  cookModeTitle: 'రోజువారీ వంట గైడ్',
  cookModeSubtitle: 'ఈ రోజు భోజనానికి సులభమైన దశల వారీ సూచనలు',
};

const mr: TranslationKeys = {
  ...en,
  tagline: 'तुमचे स्वयंपाकघर. तुमचा स्मार्ट मार्ग.',
  welcomeGreeting: 'सुप्रभात! आज आपण काय बनवत आहोत?',
  dashboard: 'डॅशबोर्ड',
  dontKnowWhatToEat: 'काय खावे समजत नाहीये',
  cookWithWhatIHave: 'घरातील साहित्यातून बनवा',
  mealPlanner: 'साप्ताहिक जेवण नियोजक',
  dietPlanner: 'माझा वैयक्तिक आहार नियोजक',
  cuisineExplorer: 'जागतिक पाककृती',
  groceryList: 'किराणा यादी',
  priceComparison: 'स्मार्ट किराणा तुलना',
  smartPantry: 'स्मार्ट किचन साठा',
  budget: 'बजेट व्यवस्थापन',
  family: 'कुटुंब व्यवस्थापन',
  cookMode: 'स्वयंपाकी / कुक मोड',
  aiAssistant: 'किचली AI',
  notifications: 'सूचना',
  settings: 'खाते सेटिंग्ज',
  breakfast: 'नाश्ता',
  lunch: 'दुपारचे जेवण',
  dinner: 'रात्रीचे जेवण',
  snacks: 'स्नॅक्स',
  ingredients: 'साहित्य',
  instructions: 'कृती',
  markCompleted: 'पूर्ण झाले म्हणून नोंदवा',
  completed: 'पूर्ण',
  selectLanguage: 'भाषा निवडा',
  cookModeTitle: 'दैनिक स्वयंपाक मार्गदर्शक',
  cookModeSubtitle: 'आजच्या जेवणासाठी सोप्या पायरी-पायरीच्या सूचना',
};

const gu: TranslationKeys = {
  ...en,
  tagline: 'તમારું રસોડું. તમારી સ્માર્ટ રીત.',
  welcomeGreeting: 'સુપ્રભાત! આજે આપણે શું બનાવી રહ્યા છીએ?',
  dashboard: 'ડેશબોર્ડ',
  dontKnowWhatToEat: 'શું ખાવું સમજાતું નથી',
  cookWithWhatIHave: 'ઘરે રહેલી સામગ્રીમાંથી બનાવો',
  mealPlanner: 'સાપ્તાહિક ભોજન પ્લાનર',
  dietPlanner: 'મારો પર્સનલ ડાયટ પ્લાનર',
  cuisineExplorer: 'ગ્લોબલ વાનગીઓ',
  groceryList: 'કરિયાણાની યાદી',
  priceComparison: 'સ્માર્ટ ભાવ સરખામણી',
  smartPantry: 'સ્માર્ટ કિચન સ્ટોક',
  budget: 'બજેટ સંચાલન',
  family: 'પરિવાર અને ઘર',
  cookMode: 'કુક / મેડ મોડ',
  aiAssistant: 'કિચલી AI',
  notifications: 'સૂચનાઓ',
  settings: 'એકાઉન્ટ સેટિંગ્સ',
  breakfast: 'નાસ્તો',
  lunch: 'બપોરનું ભોજન',
  dinner: 'રાત્રિનું ભોજન',
  snacks: 'નાસ્તા',
  ingredients: 'સામગ્રી',
  instructions: 'બનાવવાની રીત',
  markCompleted: 'પૂર્ણ થયું માર્ક કરો',
  completed: 'પૂર્ણ',
  selectLanguage: 'ભાષા પસંદ કરો',
  cookModeTitle: 'દૈનિક રસોઈ માર્ગદર્શિકા',
  cookModeSubtitle: 'આજના ભોજન માટે સરળ સ્ટેપ-બાય-સ્ટેપ સૂચનાઓ',
};

const kn: TranslationKeys = {
  ...en,
  tagline: 'ನಿಮ್ಮ ಅಡುಗೆಮನೆ. ನಿಮ್ಮ ಸ್ಮಾರ್ಟ್ ದಾರಿ.',
  welcomeGreeting: 'ಶುಭೋದಯ! ಇಂದು ನಾವು ಏನು ಅಡುಗೆ ಮಾಡುತ್ತಿದ್ದೇವೆ?',
  dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
  dontKnowWhatToEat: 'ಏನು ತಿನ್ನಬೇಕೆಂದು ಗೊತ್ತಾಗುತ್ತಿಲ್ಲ',
  cookWithWhatIHave: 'ಮನೆಯಲ್ಲಿರುವ ಸಾಮಗ್ರಿಗಳಿಂದ ಅಡುಗೆ ಮಾಡಿ',
  mealPlanner: 'ವಾರದ ಆಹಾರ ಯೋಜಕ',
  dietPlanner: 'ನನ್ನ ವೈಯಕ್ತಿಕ ಡಯಟ್ ಯೋಜಕ',
  cuisineExplorer: 'ಜಾಗತಿಕ ಪಾಕವಿಧಾನಗಳು',
  groceryList: 'ದಿನಸಿ ಪಟ್ಟಿ',
  priceComparison: 'ಸ್ಮಾರ್ಟ್ ಬೆಲೆ ಹೋಲಿಕೆ',
  smartPantry: 'ಸ್ಮಾರ್ಟ್ ಅಡುಗೆಮನೆ ದಾಸ್ತಾನು',
  budget: 'ಬಜೆಟ್ ನಿರ್ವಹಣೆ',
  family: 'ಕುಟುಂಬ',
  cookMode: 'ಅಡುಗೆಯವರ ಮೋಡ್',
  aiAssistant: 'ಕಿಚ್ಲಿ AI',
  notifications: 'ಸೂಚನೆಗಳು',
  settings: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
  breakfast: 'ಬೆಳಗಿನ ತಿಂಡಿ',
  lunch: 'ಮಧ್ಯಾಹ್ನದ ಊಟ',
  dinner: 'ರಾತ್ರಿ ಊಟ',
  snacks: 'ತಿಂಡಿಗಳು',
  ingredients: 'ಪದಾರ್ಥಗಳು',
  instructions: 'ಮಾಡುವ ವಿಧಾನ',
  markCompleted: 'ಪೂರ್ಣಗೊಂಡಿದೆ ಎಂದು ಗುರುತಿಸಿ',
  completed: 'ಪೂರ್ಣಗೊಂಡಿದೆ',
  selectLanguage: 'ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ',
  cookModeTitle: 'ದೈನಂದಿನ ಅಡುಗೆ ಮಾರ್ಗದರ್ಶಿ',
  cookModeSubtitle: 'ಇಂದಿನ ಊಟಕ್ಕೆ ಸರಳ ಹಂತ-ಹಂತದ ಸೂಚನೆಗಳು',
};

const ml: TranslationKeys = {
  ...en,
  tagline: 'നിങ്ങളുടെ അടുക്കള. നിങ്ങളുടെ സ്മാർട്ട് വഴി.',
  welcomeGreeting: 'സുപ്രഭാതം! ഇന്ന് നമ്മൾ എന്താണ് പാചകം ചെയ്യുന്നത്?',
  dashboard: 'ഡാഷ്‌ബോർഡ്',
  dontKnowWhatToEat: 'എന്ത് കഴിക്കണമെന്ന് അറിയില്ല',
  cookWithWhatIHave: 'വീട്ടിലുള്ളത് വെച്ച് പാചകം ചെയ്യൂ',
  mealPlanner: 'പ്രതിവാര മീൽ പ്ലാനർ',
  dietPlanner: 'എന്റെ ഡയറ്റ് പ്ലാനർ',
  cuisineExplorer: 'ആഗോള വിഭവങ്ങൾ',
  groceryList: 'പലചരക്ക് ലിസ്റ്റ്',
  priceComparison: 'സ്മാർട്ട് വില താരതമ്യം',
  smartPantry: 'സ്മാർട്ട് കിച്ചൺ സ്റ്റോക്ക്',
  budget: 'ബജറ്റ്',
  family: 'കുടുംബം',
  cookMode: 'കുക്ക് / മെയ്ഡ് മോഡ്',
  aiAssistant: 'കിച്ലി AI',
  notifications: 'അറിയിപ്പുകൾ',
  settings: 'സെറ്റിംഗുകൾ',
  breakfast: 'പ്രഭാതഭക്ഷണം',
  lunch: 'ഉച്ചഭക്ഷണം',
  dinner: 'അത്താഴം',
  snacks: 'ലഘുഭക്ഷണം',
  ingredients: 'ചേരുവകൾ',
  instructions: 'തയ്യാറാക്കുന്ന വിധം',
  markCompleted: 'പൂർത്തിയായതായി അടയാളപ്പെടുത്തുക',
  completed: 'പൂർത്തിയായി',
  selectLanguage: 'ഭാഷ തിരഞ്ഞെടുക്കുക',
  cookModeTitle: 'ദൈനംദിന പാചക സഹായി',
  cookModeSubtitle: 'ഇന്നത്തെ ഭക്ഷണത്തിനുള്ള ലളിതമായ നിർദ്ദേശങ്ങൾ',
};

const orLang: TranslationKeys = {
  ...en,
  tagline: 'ଆପଣଙ୍କ ରୋଷେଇ ଘର। ଆପଣଙ୍କ ସ୍ମାର୍ଟ ଉପାୟ।',
  welcomeGreeting: 'ଶୁଭ ସକାଳ! ଆଜି ଆମେ କଣ ରାନ୍ଧିବା?',
  dashboard: 'ଡ୍ୟାସବୋର୍ଡ',
  dontKnowWhatToEat: 'କଣ ଖାଇବି ଜାଣିପାରୁନି',
  cookWithWhatIHave: 'ଘରେ ଥିବା ସାମଗ୍ରୀରେ ରାନ୍ଧନ୍ତୁ',
  mealPlanner: 'ସାପ୍ତାହିକ ମିଲ୍ ପ୍ଲାନର୍',
  dietPlanner: 'ମୋର ବ୍ୟକ୍ତିଗତ ଡାଏଟ୍ ପ୍ଲାନର୍',
  cuisineExplorer: 'ବିଶ୍ୱ ରୋଷେଇ',
  groceryList: 'କିରାଣା ତାଲିକା',
  priceComparison: 'ସ୍ମାର୍ଟ ଦର ତୁଳନା',
  smartPantry: 'ସ୍ମାର୍ଟ ରୋଷେଇ ଷ୍ଟକ୍',
  budget: 'ବଜେଟ୍ ପରିଚାଳନା',
  family: 'ପରିବାର',
  cookMode: 'କୁକ୍ ମୋଡ୍',
  aiAssistant: 'କିଚଲି AI',
  notifications: 'ସୂଚନା',
  settings: 'ସେଟିଂସ୍',
  breakfast: 'ଜଳଖିଆ',
  lunch: 'ମଧ୍ୟାହ୍ନ ଭୋଜନ',
  dinner: 'ରାତ୍ରି ଭୋଜନ',
  snacks: 'ସ୍ନାକ୍ସ',
  ingredients: 'ସାମଗ୍ରୀ',
  instructions: 'ରାନ୍ଧିବା ପ୍ରଣାଳୀ',
  markCompleted: 'ସମ୍ପୂର୍ଣ୍ଣ ଚିହ୍ନଟ କରନ୍ତୁ',
  completed: 'ସମ୍ପୂର୍ଣ୍ଣ',
  selectLanguage: 'ଭାଷା ବାଛନ୍ତୁ',
  cookModeTitle: 'ଦୈନିକ ରୋଷେଇ ଗାଇଡ୍',
  cookModeSubtitle: 'ଆଜିର ଖାଦ୍ୟ ପାଇଁ ସହଜ ନିର୍ଦ୍ଦେଶାବଳୀ',
};

const asLang: TranslationKeys = {
  ...en,
  tagline: 'আপোনাৰ পাকঘৰ। আপোনাৰ স্মাৰ্ট উপায়।',
  welcomeGreeting: 'সুপ্ৰভাত! আজি আমি কি ৰান্ধিম?',
  dashboard: 'ডেশ্ববৰ্ড',
  dontKnowWhatToEat: 'কি খাম বুজি পোৱা নাই',
  cookWithWhatIHave: 'ঘৰত থকা সামগ্ৰীৰে ৰান্ধক',
  mealPlanner: 'সাপ্তাহিক খাদ্য তালিকা',
  dietPlanner: 'মোৰ ব্যক্তিগত ডায়েট প্লেনাৰ',
  cuisineExplorer: 'বিশ্ব ৰন্ধন-প্ৰণালী',
  groceryList: 'বজাৰৰ তালিকা',
  priceComparison: 'স্মাৰ্ট মূল্য তুলনা',
  smartPantry: 'স্মাৰ্ট পাকঘৰৰ ভঁৰাল',
  budget: 'বাজেট পৰিচালনা',
  family: 'পৰিয়াল',
  cookMode: 'ৰান্ধনী ম’ড',
  aiAssistant: 'কিচলি AI',
  notifications: 'জাননী',
  settings: 'ছেটিংছ',
  breakfast: 'ৰাতিপুৱাৰ আহাৰ',
  lunch: 'দুপৰীয়াৰ আহাৰ',
  dinner: 'ৰাতিৰ আহাৰ',
  snacks: 'জলপান',
  ingredients: 'উপকৰণ',
  instructions: 'ৰন্ধন প্ৰণালী',
  markCompleted: 'সম্পূৰ্ণ হিচাপে চিহ্নিত কৰক',
  completed: 'সম্পূৰ্ণ',
  selectLanguage: 'ভাষা বাছনি কৰক',
  cookModeTitle: 'দৈনিক ৰন্ধন নিৰ্দেশনা',
  cookModeSubtitle: 'আজিৰ আহাৰৰ বাবে সহজ নিৰ্দেশনা',
};

export const TRANSLATIONS: Record<LanguageCode, TranslationKeys> = {
  en,
  hi,
  bn,
  pa,
  ta,
  te,
  mr,
  gu,
  kn,
  ml,
  or: orLang,
  as: asLang,
};

export const CURRENCY_RATES: Record<string, { symbol: string; rateFromINR: number; label: string }> = {
  INR: { symbol: '₹', rateFromINR: 1, label: 'INR (₹)' },
  USD: { symbol: '$', rateFromINR: 0.012, label: 'USD ($)' },
  EUR: { symbol: '€', rateFromINR: 0.011, label: 'EUR (€)' },
  GBP: { symbol: '£', rateFromINR: 0.0094, label: 'GBP (£)' },
  AED: { symbol: 'AED ', rateFromINR: 0.044, label: 'AED' },
  SGD: { symbol: 'S$', rateFromINR: 0.016, label: 'SGD (S$)' },
};

export function formatCurrency(amountINR: number, currency: string = 'INR'): string {
  const cfg = CURRENCY_RATES[currency] || CURRENCY_RATES.INR;
  const converted = amountINR * cfg.rateFromINR;
  const formatted = currency === 'INR' ? Math.round(converted).toLocaleString('en-IN') : converted.toFixed(2);
  return `${cfg.symbol}${formatted}`;
}
