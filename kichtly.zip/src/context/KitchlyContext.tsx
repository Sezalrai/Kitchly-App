import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, resolveGoogleRedirectResult, signInWithGoogle, signOutFirebase } from '../firebase';
import { createFreshUserKitchlyState, createInitialKitchlyState } from '../data/defaultState';
import { INITIAL_RECIPES } from '../data/recipes';
import { TRANSLATIONS, TranslationKeys } from '../i18n/translations';
import {
  bootstrapUserInFirestore,
  deleteFamilyMemberFS,
  deleteGroceryItemFS,
  deletePantryItemFS,
  resetHouseholdDataFS,
  saveDietPlanFS,
  saveWeeklyPlanFS,
  subscribeHouseholdState,
  updateHouseholdFieldsFS,
  upsertCookTaskFS,
  upsertFamilyMemberFS,
  upsertGroceryItemFS,
  upsertNotificationFS,
  upsertPantryItemFS,
  upsertRecipeFS,
} from '../services/firestoreSync';
import {
  AppScreen,
  CookTask,
  CurrencyCode,
  DietPlannerProfile,
  FamilyMember,
  GeneratedDietPlan,
  GroceryCategory,
  GroceryItem,
  KitchlyState,
  LanguageCode,
  NotificationItem,
  PantryItem,
  Recipe,
  WeeklyMealSlot,
} from '../types/kitchly';

interface KitchlyContextValue {
  state: KitchlyState;
  t: TranslationKeys;
  firebaseUser: User | null;
  authLoading: boolean;
  isCloudSynced: boolean;
  sessionMode: 'cloud' | 'guest' | 'demo' | null;
  screen: AppScreen;
  setScreen: (s: AppScreen) => void;
  selectedRecipe: Recipe | null;
  openRecipe: (r: Recipe) => void;
  allRecipes: Recipe[];
  toast: string | null;
  showToast: (msg: string) => void;

  // Auth & session
  handleGoogleSignIn: () => Promise<void>;
  enterDemoMode: () => void;
  enterGuestKitchen: () => void;
  handleSignOut: () => Promise<void>;
  resetToFreshAccount: () => Promise<void>;

  // AI handoff
  pendingAssistantPrompt: string | null;
  askAssistantWithPrompt: (prompt: string) => void;
  clearPendingAssistantPrompt: () => void;

  // Preferences & profile
  setLanguage: (lang: LanguageCode) => void;
  setCurrency: (currency: CurrencyCode, country?: string) => void;
  updateHouseholdSettings: (patch: { householdName?: string; country?: string; currency?: CurrencyCode; language?: LanguageCode; cookModePin?: string; onboarded?: boolean }) => void;
  updateDietProfile: (profile: DietPlannerProfile, markOnboarded?: boolean) => void;

  // Plans & recipes
  setDietPlan: (plan: GeneratedDietPlan) => void;
  updateWeeklySlot: (day: string, slot: 'breakfastId' | 'lunchId' | 'dinnerId' | 'snackId', recipeId: string) => void;
  setWeeklyPlanBulk: (slots: WeeklyMealSlot[], extraRecipes?: Recipe[]) => void;
  autoFillWeeklyPlan: () => number;
  addCustomRecipe: (recipe: Recipe) => void;
  toggleFavoriteRecipe: (recipe: Recipe) => void;

  // Pantry & grocery
  savePantryItem: (item: PantryItem) => void;
  removePantryItem: (id: string) => void;
  saveGroceryItem: (item: GroceryItem) => void;
  toggleGroceryPurchased: (id: string) => void;
  removeGroceryItem: (id: string) => void;
  generateGroceryFromWeeklyPlan: () => number;
  addRecipeIngredientsToGrocery: (recipe: Recipe, servingsMultiplier?: number) => number;
  movePurchasedToPantry: () => number;

  // Family & cook mode
  saveFamilyMember: (member: FamilyMember) => void;
  removeFamilyMember: (id: string) => void;
  saveCookTask: (task: CookTask) => void;
  assignRecipeToCookMode: (recipe: Recipe, slot: 'Breakfast' | 'Lunch' | 'Dinner' | 'Prep', notes?: string) => void;

  // Notifications
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  excludeIngredientFromAI: (ingredient: string) => void;
}

const KitchlyContext = createContext<KitchlyContextValue | null>(null);

const SHORTCUT_SCREENS: AppScreen[] = [
  'dashboard',
  'diet-planner',
  'meal-planner',
  'cuisine-explorer',
  'community',
  'dont-know',
  'cook-with-have',
  'grocery-list',
  'grocery-wizard',
  'price-comparison',
  'pantry',
  'budget',
  'family',
  'cook-mode',
  'ai-assistant',
  'settings',
];

function getRequestedShortcutScreen(): AppScreen | null {
  if (typeof window === 'undefined') return null;
  const param = new URLSearchParams(window.location.search).get('screen') as AppScreen | null;
  if (param && SHORTCUT_SCREENS.includes(param)) return param;
  return null;
}

const LOCAL_STATE_KEY = 'kitchly_local_state_v1';
const SESSION_MODE_KEY = 'kitchly_session_mode_v1';
const LAST_SCREEN_KEY = 'kitchly_last_screen_v1';
const CLOUD_CACHE_PREFIX = 'kitchly_cloud_cache_v1_';

function loadStoredLocalSession(): {
  mode: 'guest' | 'demo' | null;
  state: KitchlyState | null;
  lastScreen: AppScreen | null;
} {
  if (typeof window === 'undefined') return { mode: null, state: null, lastScreen: null };
  try {
    const mode = window.localStorage.getItem(SESSION_MODE_KEY) as 'guest' | 'demo' | null;
    const rawState = window.localStorage.getItem(LOCAL_STATE_KEY);
    const savedScreen = window.localStorage.getItem(LAST_SCREEN_KEY) as AppScreen | null;
    const parsedState = rawState ? (JSON.parse(rawState) as KitchlyState) : null;
    const validMode = mode === 'guest' || mode === 'demo' ? mode : null;
    const validScreen =
      savedScreen && SHORTCUT_SCREENS.includes(savedScreen) ? savedScreen : null;
    return { mode: validMode, state: parsedState, lastScreen: validScreen };
  } catch {
    return { mode: null, state: null, lastScreen: null };
  }
}

function loadCachedCloudState(uid: string): KitchlyState | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(`${CLOUD_CACHE_PREFIX}${uid}`);
    return raw ? (JSON.parse(raw) as KitchlyState) : null;
  } catch {
    return null;
  }
}

export function KitchlyProvider({ children }: { children: React.ReactNode }) {
  const initialStored = useMemo(() => loadStoredLocalSession(), []);
  const [state, setState] = useState<KitchlyState>(() =>
    initialStored.mode && initialStored.state
      ? initialStored.state
      : createInitialKitchlyState()
  );
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [localMode, setLocalMode] = useState<'guest' | 'demo' | null>(initialStored.mode);
  const [screen, setScreen] = useState<AppScreen>(() => {
    const shortcut = getRequestedShortcutScreen();
    if (initialStored.mode) {
      return shortcut || initialStored.lastScreen || 'dashboard';
    }
    return 'welcome';
  });
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [pendingAssistantPrompt, setPendingAssistantPrompt] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast((prev) => (prev === msg ? null : prev));
    }, 3400);
  };

  // Scroll to top cleanly whenever switching screens
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'auto' });
    }
  }, [screen]);

  // Persist local/guest/demo session state & current screen just like a native app (Blinkit/Zepto)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      if (firebaseUser) {
        window.localStorage.setItem(`${CLOUD_CACHE_PREFIX}${firebaseUser.uid}`, JSON.stringify(state));
      } else if (localMode) {
        window.localStorage.setItem(SESSION_MODE_KEY, localMode);
        window.localStorage.setItem(LOCAL_STATE_KEY, JSON.stringify(state));
      }
      if (SHORTCUT_SCREENS.includes(screen)) {
        window.localStorage.setItem(LAST_SCREEN_KEY, screen);
      }
    } catch {
      // Ignore storage quota errors cleanly
    }
  }, [state, firebaseUser, localMode, screen]);

  useEffect(() => {
    let unsubFirestore: (() => void) | null = null;
    let mounted = true;
    void resolveGoogleRedirectResult();

    // Never leave any user stuck on a loading screen if offline or slow network
    const authTimeout = window.setTimeout(() => {
      if (mounted) setAuthLoading(false);
    }, 2500);

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      window.clearTimeout(authTimeout);
      if (unsubFirestore) {
        unsubFirestore();
        unsubFirestore = null;
      }
      setFirebaseUser(user);
      if (user) {
        setLocalMode(null);
        const cached = loadCachedCloudState(user.uid);
        setState(
          cached ||
            createFreshUserKitchlyState({
              id: user.uid,
              name: user.displayName || user.email?.split('@')[0] || 'My Kitchen',
              email: user.email || '',
              onboarded: false,
            })
        );
        const shortcut = getRequestedShortcutScreen();
        if (cached) {
          setScreen((curr) =>
            curr === 'welcome' || curr === 'auth'
              ? shortcut || (cached.user.onboarded ? 'dashboard' : 'onboarding')
              : curr
          );
        }
        setAuthLoading(false);

        try {
          const { onboarded } = await bootstrapUserInFirestore(user);
          if (!mounted) return;
          unsubFirestore = subscribeHouseholdState(user.uid, user, (updater) => {
            setState((prev) => updater(prev));
          });
          setScreen((curr) =>
            curr === 'welcome' || curr === 'auth'
              ? shortcut || (onboarded ? 'dashboard' : 'onboarding')
              : curr
          );
        } catch (err) {
          console.warn('Firestore bootstrap/sync fallback:', err);
          if (!cached) {
            setScreen((curr) =>
              curr === 'welcome' || curr === 'auth' ? shortcut || 'dashboard' : curr
            );
          }
        }
      } else {
        setAuthLoading(false);
      }
    });

    return () => {
      mounted = false;
      window.clearTimeout(authTimeout);
      unsubAuth();
      if (unsubFirestore) unsubFirestore();
    };
  }, []);

  const isCloudSynced = Boolean(firebaseUser);
  const sessionMode: 'cloud' | 'guest' | 'demo' | null = firebaseUser
    ? 'cloud'
    : localMode;
  const t = TRANSLATIONS[state.user.language] || TRANSLATIONS.en;

  const allRecipes = useMemo(() => {
    const map = new Map<string, Recipe>();
    for (const r of INITIAL_RECIPES) map.set(r.id, r);
    for (const r of state.customRecipes) map.set(r.id, r);
    if (state.currentDietPlan) {
      const dp = state.currentDietPlan;
      [dp.breakfast, dp.morningSnack, dp.lunch, dp.eveningSnack, dp.dinner, dp.optionalDessert].forEach((r) => {
        if (r) map.set(r.id, r);
      });
    }
    return Array.from(map.values()).map((r) => ({
      ...r,
      isFavorite: state.favoriteRecipeIds.includes(r.id),
    }));
  }, [state.customRecipes, state.currentDietPlan, state.favoriteRecipeIds]);

  const handleGoogleSignIn = async () => {
    try {
      const res = await signInWithGoogle();
      if (!res.redirected) {
        showToast('Signed in with Google. Household synced to Cloud Firestore.');
      }
    } catch (err) {
      const code = (err as { code?: string } | null)?.code || '';
      if (code === 'auth/unauthorized-domain') {
        showToast('Google Sign-In is restricted on this domain. Use "Start Fresh Kitchen" below — everything saves locally!');
      } else if (code === 'auth/popup-closed-by-user') {
        showToast('Sign-in popup was closed. Try again or start a Fresh Guest Kitchen.');
      } else {
        const msg = err instanceof Error ? err.message : 'Google Sign-In failed.';
        showToast(msg);
      }
    }
  };

  const enterDemoMode = () => {
    setLocalMode('demo');
    const demoState = createInitialKitchlyState();
    setState(demoState);
    try {
      window.localStorage.setItem(SESSION_MODE_KEY, 'demo');
      window.localStorage.setItem(LOCAL_STATE_KEY, JSON.stringify(demoState));
    } catch {
      // ignore storage errors
    }
    setScreen(getRequestedShortcutScreen() || 'dashboard');
  };

  const enterGuestKitchen = () => {
    setLocalMode('guest');
    if (localMode === 'guest' && state.user.id.startsWith('guest-')) {
      setScreen(getRequestedShortcutScreen() || (state.user.onboarded ? 'dashboard' : 'onboarding'));
      return;
    }
    const fresh = createFreshUserKitchlyState({
      id: `guest-${Date.now().toString(36)}`,
      name: 'My Kitchen',
      email: '',
      onboarded: false,
    });
    setState(fresh);
    try {
      window.localStorage.setItem(SESSION_MODE_KEY, 'guest');
      window.localStorage.setItem(LOCAL_STATE_KEY, JSON.stringify(fresh));
    } catch {
      // ignore storage errors
    }
    setScreen(getRequestedShortcutScreen() || 'onboarding');
    showToast('Started your own personal kitchen — all changes save automatically on this device!');
  };

  const handleSignOut = async () => {
    if (firebaseUser) {
      await signOutFirebase();
    }
    setLocalMode(null);
    try {
      window.localStorage.removeItem(SESSION_MODE_KEY);
      window.localStorage.removeItem(LOCAL_STATE_KEY);
      window.localStorage.removeItem(LAST_SCREEN_KEY);
    } catch {
      // ignore
    }
    setState(createInitialKitchlyState());
    setScreen('welcome');
  };

  const resetToFreshAccount = async () => {
    const fresh = createFreshUserKitchlyState({
      id: firebaseUser?.uid || state.user.id,
      name: firebaseUser?.displayName || state.user.name,
      email: firebaseUser?.email || state.user.email,
      onboarded: false,
    });
    if (!firebaseUser) {
      setLocalMode('guest');
    }
    setState(fresh);
    if (firebaseUser) {
      await resetHouseholdDataFS(firebaseUser.uid, firebaseUser);
    } else {
      try {
        window.localStorage.setItem(SESSION_MODE_KEY, 'guest');
        window.localStorage.setItem(LOCAL_STATE_KEY, JSON.stringify(fresh));
      } catch {
        // ignore
      }
    }
    setScreen('onboarding');
    showToast('Started a fresh kitchen! Let’s set up your preferences and budget.');
  };

  const askAssistantWithPrompt = (prompt: string) => {
    setPendingAssistantPrompt(prompt);
    setScreen('ai-assistant');
  };

  const clearPendingAssistantPrompt = () => {
    setPendingAssistantPrompt(null);
  };

  const openRecipe = (r: Recipe) => {
    setSelectedRecipe(r);
    setScreen('recipe-detail');
  };

  const setLanguage = (language: LanguageCode) => {
    setState((prev) => ({ ...prev, user: { ...prev.user, language } }));
    if (firebaseUser) {
      updateHouseholdFieldsFS(firebaseUser.uid, { language }).catch((e) => showToast(String(e)));
    }
  };

  const setCurrency = (currency: CurrencyCode, country?: string) => {
    setState((prev) => ({
      ...prev,
      user: { ...prev.user, currency, country: country || prev.user.country },
    }));
    if (firebaseUser) {
      updateHouseholdFieldsFS(firebaseUser.uid, {
        currency,
        ...(country ? { country } : {}),
      }).catch((e) => showToast(String(e)));
    }
  };

  const updateHouseholdSettings = (
    patch: Partial<{
      householdName: string;
      country: string;
      currency: CurrencyCode;
      language: LanguageCode;
      cookModePin: string;
      onboarded: boolean;
    }>
  ) => {
    setState((prev) => ({ ...prev, user: { ...prev.user, ...patch } }));
    if (firebaseUser) {
      updateHouseholdFieldsFS(firebaseUser.uid, patch).catch((e) => showToast(String(e)));
    }
  };

  const updateDietProfile = (dietProfile: DietPlannerProfile, markOnboarded = false) => {
    setState((prev) => ({
      ...prev,
      dietProfile,
      user: { ...prev.user, onboarded: markOnboarded ? true : prev.user.onboarded },
    }));
    if (firebaseUser) {
      updateHouseholdFieldsFS(
        firebaseUser.uid,
        markOnboarded ? { dietProfile, onboarded: true } : { dietProfile }
      ).catch((e) => showToast(String(e)));
    }
  };

  const setDietPlan = (plan: GeneratedDietPlan) => {
    setState((prev) => ({ ...prev, currentDietPlan: plan }));
    if (firebaseUser) {
      saveDietPlanFS(firebaseUser.uid, plan).catch((e) => showToast(String(e)));
    }
  };

  const updateWeeklySlot = (
    day: string,
    slot: 'breakfastId' | 'lunchId' | 'dinnerId' | 'snackId',
    recipeId: string
  ) => {
    setState((prev) => {
      const weekOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      const baseDays: WeeklyMealSlot[] =
        prev.weeklyPlan.length > 0
          ? prev.weeklyPlan
          : weekOrder.map((d) => ({
              day: d,
              breakfastId: '',
              lunchId: '',
              dinnerId: '',
              snackId: '',
            }));
      const exists = baseDays.some((d) => d.day === day);
      const updated = exists
        ? baseDays.map((d) => (d.day === day ? { ...d, [slot]: recipeId } : d))
        : [
            ...baseDays,
            { day, breakfastId: '', lunchId: '', dinnerId: '', snackId: '', [slot]: recipeId },
          ];
      if (firebaseUser) {
        saveWeeklyPlanFS(firebaseUser.uid, updated).catch((e) => console.warn('Weekly plan sync deferred:', e));
      }
      return { ...prev, weeklyPlan: updated };
    });
  };

  const setWeeklyPlanBulk = (slots: WeeklyMealSlot[], extraRecipes: Recipe[] = []) => {
    setState((prev) => {
      const existingIds = new Set(prev.customRecipes.map((r) => r.id));
      const newCustoms = extraRecipes.filter((r) => !existingIds.has(r.id));
      return {
        ...prev,
        customRecipes: newCustoms.length > 0 ? [...newCustoms, ...prev.customRecipes] : prev.customRecipes,
        weeklyPlan: slots,
      };
    });
    if (firebaseUser) {
      extraRecipes.forEach((rec) => {
        upsertRecipeFS(firebaseUser.uid, rec, state.favoriteRecipeIds.includes(rec.id)).catch(() => {});
      });
      saveWeeklyPlanFS(firebaseUser.uid, slots).catch((e) => console.warn('Weekly plan sync deferred:', e));
    }
  };

  const autoFillWeeklyPlan = (): number => {
    const allergies = [...state.dietProfile.allergies, ...state.dietProfile.customAllergies].map((a) => a.toLowerCase());
    const dislikes = [...state.dietProfile.dislikedIngredients, ...state.dietProfile.neverRecommend].map((d) => d.toLowerCase());
    const prefs = state.dietProfile.foodPreferences;
    const isVegOnly = prefs.length > 0 && prefs.every((p) => p === 'Vegetarian' || p === 'Vegan');
    const isVeganOnly = prefs.length > 0 && prefs.every((p) => p === 'Vegan');

    const safePool = allRecipes.filter((r) => {
      if (r.allergens.some((a) => allergies.includes(a.toLowerCase()))) return false;
      if (dislikes.some((d) => r.title.toLowerCase().includes(d) || r.ingredients.some((i) => i.name.toLowerCase().includes(d)))) {
        return false;
      }
      if (isVeganOnly && r.dietType !== 'Vegan') return false;
      if (isVegOnly && !['Vegetarian', 'Vegan'].includes(r.dietType)) return false;
      return true;
    });

    const pool = safePool.length >= 4 ? safePool : allRecipes;
    const breakfasts = pool.filter((r) => r.mealSlot === 'Breakfast' || r.prepTimeMins <= 20);
    const snacks = pool.filter((r) => r.mealSlot === 'Snack' || r.prepTimeMins <= 20);
    const mains = pool.filter((r) => r.mealSlot === 'Lunch' || r.mealSlot === 'Dinner' || !r.mealSlot || r.prepTimeMins > 15);

    const pick = (arr: Recipe[], idx: number): string =>
      (arr.length > 0 ? arr[idx % arr.length] : pool[idx % pool.length])?.id || '';

    const weekOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const filled: WeeklyMealSlot[] = weekOrder.map((day, idx) => ({
      day,
      breakfastId: pick(breakfasts, idx),
      lunchId: pick(mains, idx * 2),
      dinnerId: pick(mains, idx * 2 + 1),
      snackId: pick(snacks, idx),
    }));

    setState((prev) => ({ ...prev, weeklyPlan: filled }));
    if (firebaseUser) {
      saveWeeklyPlanFS(firebaseUser.uid, filled).catch((e) => showToast(String(e)));
    }
    showToast('Auto-filled a full 7-day meal schedule matching your preferences!');
    return filled.length;
  };

  const addCustomRecipe = (recipe: Recipe) => {
    setState((prev) => {
      const exists = prev.customRecipes.some((r) => r.id === recipe.id);
      if (exists) return prev;
      return { ...prev, customRecipes: [recipe, ...prev.customRecipes] };
    });
    if (firebaseUser) {
      upsertRecipeFS(firebaseUser.uid, recipe, state.favoriteRecipeIds.includes(recipe.id)).catch((e) =>
        console.warn('Recipe sync queued/deferred:', e)
      );
    }
  };

  const toggleFavoriteRecipe = (recipe: Recipe) => {
    const currentlyFav = state.favoriteRecipeIds.includes(recipe.id);
    const nextFav = !currentlyFav;
    setState((prev) => ({
      ...prev,
      favoriteRecipeIds: nextFav
        ? [...prev.favoriteRecipeIds, recipe.id]
        : prev.favoriteRecipeIds.filter((id) => id !== recipe.id),
    }));
    if (firebaseUser) {
      upsertRecipeFS(firebaseUser.uid, recipe, nextFav).catch((e) =>
        console.warn('Favorite sync deferred:', e)
      );
    }
    showToast(nextFav ? `Saved "${recipe.title}" to favorites.` : `Removed "${recipe.title}" from favorites.`);
  };

  const savePantryItem = (item: PantryItem) => {
    setState((prev) => {
      const idx = prev.pantry.findIndex((p) => p.id === item.id);
      const next = idx >= 0 ? prev.pantry.map((p) => (p.id === item.id ? item : p)) : [item, ...prev.pantry];
      return { ...prev, pantry: next };
    });
    if (firebaseUser) {
      upsertPantryItemFS(firebaseUser.uid, item).catch((e) =>
        console.warn('Pantry sync deferred:', e)
      );
    }
  };

  const removePantryItem = (id: string) => {
    setState((prev) => ({ ...prev, pantry: prev.pantry.filter((p) => p.id !== id) }));
    if (firebaseUser) {
      deletePantryItemFS(firebaseUser.uid, id).catch((e) =>
        console.warn('Pantry delete deferred:', e)
      );
    }
  };

  const saveGroceryItem = (item: GroceryItem) => {
    setState((prev) => {
      const idx = prev.groceryList.findIndex((g) => g.id === item.id);
      const next = idx >= 0 ? prev.groceryList.map((g) => (g.id === item.id ? item : g)) : [item, ...prev.groceryList];
      return { ...prev, groceryList: next };
    });
    if (firebaseUser) {
      upsertGroceryItemFS(firebaseUser.uid, item).catch((e) =>
        console.warn('Grocery sync deferred:', e)
      );
    }
  };

  const toggleGroceryPurchased = (id: string) => {
    const found = state.groceryList.find((g) => g.id === id);
    if (!found) return;
    const updated = { ...found, purchased: !found.purchased };
    saveGroceryItem(updated);
  };

  const removeGroceryItem = (id: string) => {
    setState((prev) => ({ ...prev, groceryList: prev.groceryList.filter((g) => g.id !== id) }));
    if (firebaseUser) {
      deleteGroceryItemFS(firebaseUser.uid, id).catch((e) =>
        console.warn('Grocery delete deferred:', e)
      );
    }
  };

  const addRecipeIngredientsToGrocery = (recipe: Recipe, servingsMultiplier = 1): number => {
    const pantryNames = state.pantry.map((p) => p.name.toLowerCase());
    let added = 0;

    recipe.ingredients.forEach((ing) => {
      const inPantry = pantryNames.some(
        (pn) => pn.includes(ing.name.toLowerCase()) || ing.name.toLowerCase().includes(pn)
      );
      if (inPantry) return;

      const existing = state.groceryList.find((g) => g.name.toLowerCase() === ing.name.toLowerCase() && !g.purchased);
      const qty = Math.round(ing.quantity * servingsMultiplier * 10) / 10;
      if (existing) {
        saveGroceryItem({ ...existing, quantity: Math.round((existing.quantity + qty) * 10) / 10 });
      } else {
        saveGroceryItem({
          id: `groc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          name: ing.name,
          quantity: qty,
          unit: ing.unit,
          category: ing.category as GroceryCategory,
          estimatedCostINR: Math.max(30, Math.round(recipe.estimatedCostINR / Math.max(1, recipe.ingredients.length))),
          purchased: false,
          source: 'recipe',
        });
      }
      added++;
    });

    showToast(added > 0 ? `Added ${added} missing ingredient(s) to grocery list.` : 'All ingredients are already in your pantry or list!');
    return added;
  };

  const generateGroceryFromWeeklyPlan = (): number => {
    const recipeMap = new Map<string, Recipe>(allRecipes.map((r) => [r.id, r]));
    const pantryNames = state.pantry.map((p) => p.name.toLowerCase());
    const householdMult = Math.max(1, state.dietProfile.householdSize / 2);
    const aggregated = new Map<string, GroceryItem>();

    state.weeklyPlan.forEach((day: WeeklyMealSlot) => {
      [day.breakfastId, day.lunchId, day.dinnerId, day.snackId].forEach((rid) => {
        const rec = recipeMap.get(rid);
        if (!rec) return;
        rec.ingredients.forEach((ing) => {
          const lower = ing.name.toLowerCase();
          const inPantry = pantryNames.some((pn) => pn.includes(lower) || lower.includes(pn));
          if (inPantry) return;
          const prev = aggregated.get(lower);
          const scaledQty = Math.round(ing.quantity * householdMult * 10) / 10;
          if (prev) {
            prev.quantity = Math.round((prev.quantity + scaledQty) * 10) / 10;
          } else {
            aggregated.set(lower, {
              id: `groc-wk-${lower.replace(/[^a-z0-9]/g, '')}-${Date.now().toString().slice(-4)}`,
              name: ing.name,
              quantity: scaledQty,
              unit: ing.unit,
              category: ing.category as GroceryCategory,
              estimatedCostINR: 65,
              purchased: false,
              source: 'meal-plan',
            });
          }
        });
      });
    });

    let added = 0;
    aggregated.forEach((item) => {
      const exists = state.groceryList.some((g) => g.name.toLowerCase() === item.name.toLowerCase() && !g.purchased);
      if (!exists) {
        saveGroceryItem(item);
        added++;
      }
    });
    showToast(
      added > 0
        ? `Generated ${added} missing item(s) scaled for ${state.dietProfile.householdSize} people.`
        : 'Your grocery list already covers this week’s missing ingredients.'
    );
    return added;
  };

  const movePurchasedToPantry = (): number => {
    const purchasedItems = state.groceryList.filter((g) => g.purchased);
    if (purchasedItems.length === 0) return 0;

    const today = new Date();
    const expiry = new Date();
    expiry.setDate(today.getDate() + 10);
    const purchaseDate = today.toISOString().split('T')[0];
    const expiryDate = expiry.toISOString().split('T')[0];

    purchasedItems.forEach((g) => {
      savePantryItem({
        id: `pan-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        name: g.name,
        quantity: g.quantity,
        unit: g.unit,
        category: g.category,
        purchaseDate,
        expiryDate,
        storageLocation: g.category === 'Dairy' || g.category === 'Meat and seafood' || g.category === 'Vegetables' ? 'Fridge' : 'Pantry',
        lowStockThreshold: 1,
      });
      removeGroceryItem(g.id);
    });
    showToast(`Moved ${purchasedItems.length} purchased item(s) into Smart Kitchen Inventory.`);
    return purchasedItems.length;
  };

  const saveFamilyMember = (member: FamilyMember) => {
    setState((prev) => {
      const exists = prev.familyMembers.some((m) => m.id === member.id);
      const next = exists
        ? prev.familyMembers.map((m) => (m.id === member.id ? member : m))
        : [...prev.familyMembers, member];
      return { ...prev, familyMembers: next };
    });
    if (firebaseUser) {
      upsertFamilyMemberFS(firebaseUser.uid, member).catch((e) => showToast(String(e)));
    }
  };

  const removeFamilyMember = (id: string) => {
    setState((prev) => ({ ...prev, familyMembers: prev.familyMembers.filter((m) => m.id !== id) }));
    if (firebaseUser) {
      deleteFamilyMemberFS(firebaseUser.uid, id).catch((e) => showToast(String(e)));
    }
  };

  const saveCookTask = (task: CookTask) => {
    setState((prev) => {
      const exists = prev.cookTasks.some((ct) => ct.id === task.id);
      const next = exists ? prev.cookTasks.map((ct) => (ct.id === task.id ? task : ct)) : [...prev.cookTasks, task];
      return { ...prev, cookTasks: next };
    });
    if (firebaseUser) {
      upsertCookTaskFS(firebaseUser.uid, task).catch((e) => showToast(String(e)));
    }
  };

  const assignRecipeToCookMode = (
    recipe: Recipe,
    slot: 'Breakfast' | 'Lunch' | 'Dinner' | 'Prep',
    notes = ''
  ) => {
    addCustomRecipe(recipe);
    const task: CookTask = {
      id: `cook-${slot.toLowerCase()}-${Date.now().toString().slice(-4)}`,
      mealSlot: slot,
      recipeId: recipe.id,
      recipeTitle: recipe.title,
      scheduledTime: slot === 'Breakfast' ? '08:15 AM' : slot === 'Lunch' ? '01:00 PM' : '07:45 PM',
      servings: state.dietProfile.householdSize || recipe.servings,
      notes: notes || `Prepared per household preferences (${state.dietProfile.spiceLevel} spice).`,
      completed: false,
      checklistDone: [],
    };
    saveCookTask(task);
    showToast(`Assigned "${recipe.title}" to Cook / Maid Mode (${slot}).`);
  };

  const markNotificationRead = (id: string) => {
    const found = state.notifications.find((n) => n.id === id);
    if (!found) return;
    const updated: NotificationItem = { ...found, read: true };
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => (n.id === id ? updated : n)),
    }));
    if (firebaseUser) {
      upsertNotificationFS(firebaseUser.uid, updated).catch((e) => showToast(String(e)));
    }
  };

  const markAllNotificationsRead = () => {
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => ({ ...n, read: true })),
    }));
    if (firebaseUser) {
      state.notifications.forEach((n) => {
        if (!n.read) upsertNotificationFS(firebaseUser.uid, { ...n, read: true }).catch(() => {});
      });
    }
  };

  const excludeIngredientFromAI = (ingredient: string) => {
    const clean = ingredient.trim();
    if (!clean) return;
    if (state.dietProfile.neverRecommend.some((x) => x.toLowerCase() === clean.toLowerCase())) return;
    const updatedProfile: DietPlannerProfile = {
      ...state.dietProfile,
      neverRecommend: [...state.dietProfile.neverRecommend, clean],
    };
    updateDietProfile(updatedProfile);
    showToast(`Excluded "${clean}" from all future recommendations.`);
  };

  return (
    <KitchlyContext.Provider
      value={{
        state,
        t,
        firebaseUser,
        authLoading,
        isCloudSynced,
        sessionMode,
        screen,
        setScreen,
        selectedRecipe,
        openRecipe,
        allRecipes,
        toast,
        showToast,
        handleGoogleSignIn,
        enterDemoMode,
        enterGuestKitchen,
        handleSignOut,
        resetToFreshAccount,
        pendingAssistantPrompt,
        askAssistantWithPrompt,
        clearPendingAssistantPrompt,
        setLanguage,
        setCurrency,
        updateHouseholdSettings,
        updateDietProfile,
        setDietPlan,
        updateWeeklySlot,
        setWeeklyPlanBulk,
        autoFillWeeklyPlan,
        addCustomRecipe,
        toggleFavoriteRecipe,
        savePantryItem,
        removePantryItem,
        saveGroceryItem,
        toggleGroceryPurchased,
        removeGroceryItem,
        generateGroceryFromWeeklyPlan,
        addRecipeIngredientsToGrocery,
        movePurchasedToPantry,
        saveFamilyMember,
        removeFamilyMember,
        saveCookTask,
        assignRecipeToCookMode,
        markNotificationRead,
        markAllNotificationsRead,
        excludeIngredientFromAI,
      }}
    >
      {children}
    </KitchlyContext.Provider>
  );
}

export function useKitchly() {
  const ctx = useContext(KitchlyContext);
  if (!ctx) throw new Error('useKitchly must be used inside KitchlyProvider');
  return ctx;
}
