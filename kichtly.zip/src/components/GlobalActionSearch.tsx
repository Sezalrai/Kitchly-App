import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  Bell,
  CalendarDays,
  ChefHat,
  Compass,
  Globe,
  HeartHandshake,
  Home,
  LayoutDashboard,
  ListChecks,
  MessageSquare,
  Package,
  Scale,
  Search,
  Settings,
  ShoppingCart,
  Sparkles,
  Users,
  UtensilsCrossed,
  Wallet,
  X,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { formatCurrency } from '../i18n/translations';
import { AppScreen } from '../types/kitchly';

interface ActionEntry {
  id: string;
  screen: AppScreen;
  title: string;
  description: string;
  category: 'Plan' | 'Shop' | 'Kitchen' | 'Household' | 'Settings';
  keywords: string;
  icon: React.ComponentType<{ className?: string }>;
  featured?: boolean;
}

const APP_ACTIONS: ActionEntry[] = [
  {
    id: 'act-grocery-wizard',
    screen: 'grocery-wizard',
    title: 'Build Guided Grocery & Meal Trip',
    description: 'Plan meals & shop Blinkit, Zepto, Instamart, Walmart within budget',
    category: 'Shop',
    keywords: 'trip builder wizard basket blinkit zepto swiggy instamart bigbasket walmart target dmart budget plan groceries',
    icon: ListChecks,
    featured: true,
  },
  {
    id: 'act-diet-planner',
    screen: 'diet-planner',
    title: 'Personal Diet Planner',
    description: 'Set allergies, dislikes, calories, protein & generate daily meals',
    category: 'Plan',
    keywords: 'diet plan nutrition calories protein vegetarian vegan keto goals allergies schedule sort filter',
    icon: ChefHat,
    featured: true,
  },
  {
    id: 'act-meal-planner',
    screen: 'meal-planner',
    title: 'Weekly Meal Planner',
    description: 'Organize Monday–Sunday breakfast, lunch, dinner & snacks',
    category: 'Plan',
    keywords: 'weekly meal schedule calendar monday tuesday wednesday thursday friday saturday sunday sort filter',
    icon: CalendarDays,
    featured: true,
  },
  {
    id: 'act-price-comparison',
    screen: 'price-comparison',
    title: 'Compare Store Prices & Shop Direct',
    description: 'Compare prices & open Blinkit, Zepto, Instamart, BigBasket, Amazon',
    category: 'Shop',
    keywords: 'price compare cheap split basket blinkit zepto instamart bigbasket amazon walmart order shop buy catalog',
    icon: Scale,
    featured: true,
  },
  {
    id: 'act-grocery-list',
    screen: 'grocery-list',
    title: 'Grocery Cart & Store Catalog',
    description: 'Check off shopping items, add staples, or buy online',
    category: 'Shop',
    keywords: 'cart grocery shopping list buy staples vegetables milk eggs bread add item',
    icon: ShoppingCart,
    featured: true,
  },
  {
    id: 'act-cook-with-have',
    screen: 'cook-with-have',
    title: 'Cook With What I Have',
    description: 'Match recipes to leftover ingredients already in your kitchen',
    category: 'Kitchen',
    keywords: 'leftover ingredients fridge pantry chef cook now available',
    icon: UtensilsCrossed,
    featured: true,
  },
  {
    id: 'act-dont-know',
    screen: 'dont-know',
    title: "I Don't Know What to Eat",
    description: 'Get fast AI meal picks based on your current mood',
    category: 'Plan',
    keywords: 'surprise hungry mood quick comforting healthy dinner lunch idea',
    icon: Sparkles,
  },
  {
    id: 'act-cuisine-explorer',
    screen: 'cuisine-explorer',
    title: 'Explore Global Cuisines & Recipes',
    description: 'Browse Indian, Italian, Korean, Mexican & 14+ cuisines',
    category: 'Plan',
    keywords: 'recipes cuisine explorer indian italian korean chinese thai mexican filter difficulty prep',
    icon: Compass,
  },
  {
    id: 'act-community',
    screen: 'community',
    title: 'Kitchen Community — Share Recipes & Follow Cooks',
    description: 'Post recipes (like homemade momos), share steps, like & follow creators',
    category: 'Household',
    keywords: 'community social share recipe post momo follow like steps learn cook creator feed',
    icon: HeartHandshake,
    featured: true,
  },
  {
    id: 'act-pantry',
    screen: 'pantry',
    title: 'Manage Smart Pantry & Expiries',
    description: 'Track Fridge, Freezer, Pantry & Spice Rack stock levels',
    category: 'Kitchen',
    keywords: 'pantry fridge freezer spice rack expiry stock inventory restock',
    icon: Package,
  },
  {
    id: 'act-budget',
    screen: 'budget',
    title: 'Set Grocery Budget & Currency',
    description: 'Adjust daily, weekly & monthly spending limits (₹300+)',
    category: 'Shop',
    keywords: 'budget spending money limit inr usd daily weekly monthly expense',
    icon: Wallet,
  },
  {
    id: 'act-family',
    screen: 'family',
    title: 'Family Members & Preferences',
    description: 'Manage household eaters, kids, diets & allergy alerts',
    category: 'Household',
    keywords: 'family members kids parents spouse allergy conflict diet preferences',
    icon: Users,
  },
  {
    id: 'act-cook-mode',
    screen: 'cook-mode',
    title: 'Open Cook / Maid Mode',
    description: 'Step-by-step kitchen instructions translated into 12 languages',
    category: 'Kitchen',
    keywords: 'cook mode maid chef steps checklist instructions hindi kitchen translate',
    icon: ChefHat,
  },
  {
    id: 'act-ai-assistant',
    screen: 'ai-assistant',
    title: 'Ask Kitchly AI Assistant',
    description: 'Chat for substitutes, recipes, storage tips, or app help',
    category: 'Kitchen',
    keywords: 'ai chat assistant help ask recipe substitute tip nutrition',
    icon: MessageSquare,
  },
  {
    id: 'act-dashboard',
    screen: 'dashboard',
    title: 'Go to Dashboard Home',
    description: 'View today’s meals, budget bar & expiry alerts',
    category: 'Household',
    keywords: 'home overview dashboard today summary',
    icon: LayoutDashboard,
  },
  {
    id: 'act-language',
    screen: 'language',
    title: 'Change App Language',
    description: 'Switch between English, Hindi, Bengali, Tamil, Telugu & 12 languages',
    category: 'Settings',
    keywords: 'language hindi bengali punjabi tamil telugu marathi gujarati kannada malayalam odia assamese translate',
    icon: Globe,
  },
  {
    id: 'act-notifications',
    screen: 'notifications',
    title: 'View Alerts & Notifications',
    description: 'Check expiring pantry items, budget warnings & cook tasks',
    category: 'Household',
    keywords: 'notifications alerts warnings expiry low stock',
    icon: Bell,
  },
  {
    id: 'act-household-profile',
    screen: 'household-profile',
    title: 'Edit Household Profile',
    description: 'Update kitchen name, country & currency',
    category: 'Settings',
    keywords: 'household name country profile account',
    icon: Home,
  },
  {
    id: 'act-settings',
    screen: 'settings',
    title: 'Account Settings & Reset Kitchen',
    description: 'Manage cloud sync, Cook Mode PIN, PWA install, or start fresh',
    category: 'Settings',
    keywords: 'settings pin install app reset fresh clear sign out logout account',
    icon: Settings,
  },
];

interface SearchResultItem {
  key: string;
  group: 'Actions' | 'Recipes' | 'Pantry & Cart' | 'AI';
  title: string;
  subtitle: string;
  badge: string;
  icon: React.ComponentType<{ className?: string }>;
  onSelect: () => void;
}

export function GlobalActionSearch() {
  const {
    state,
    allRecipes,
    setScreen,
    openRecipe,
    askAssistantWithPrompt,
  } = useKitchly();

  const [query, setQuery] = useState('');
  const [desktopOpen, setDesktopOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const desktopInputRef = useRef<HTMLInputElement>(null);
  const mobileInputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut: Cmd/Ctrl + K opens global search
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (window.innerWidth >= 768) {
          setDesktopOpen(true);
          setTimeout(() => desktopInputRef.current?.focus(), 20);
        } else {
          setMobileOpen(true);
          setTimeout(() => mobileInputRef.current?.focus(), 20);
        }
      } else if (e.key === 'Escape') {
        setDesktopOpen(false);
        setMobileOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Click outside closes desktop dropdown
  useEffect(() => {
    const onMouseDown = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setDesktopOpen(false);
      }
    };
    document.addEventListener('mousedown', onMouseDown);
    return () => document.removeEventListener('mousedown', onMouseDown);
  }, []);

  const closeAll = () => {
    setDesktopOpen(false);
    setMobileOpen(false);
    setQuery('');
    setActiveIndex(0);
  };

  const results: SearchResultItem[] = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list: SearchResultItem[] = [];

    if (!q) {
      APP_ACTIONS.filter((a) => a.featured).forEach((act) => {
        list.push({
          key: act.id,
          group: 'Actions',
          title: act.title,
          subtitle: act.description,
          badge: act.category,
          icon: act.icon,
          onSelect: () => {
            setScreen(act.screen);
            closeAll();
          },
        });
      });
      return list;
    }

    const terms = q.split(/\s+/).filter(Boolean);

    // 1. Score matching app actions
    const scoredActions = APP_ACTIONS.map((act) => {
      const titleL = act.title.toLowerCase();
      const descL = act.description.toLowerCase();
      const kwL = act.keywords.toLowerCase();
      let score = 0;
      for (const term of terms) {
        if (titleL.includes(term)) score += 6;
        if (titleL.startsWith(term)) score += 4;
        if (kwL.includes(term)) score += 3;
        if (descL.includes(term)) score += 2;
      }
      const allTermsHit = terms.every(
        (t) => titleL.includes(t) || kwL.includes(t) || descL.includes(t)
      );
      if (allTermsHit) score += 5;
      return { act, score };
    })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 6);

    scoredActions.forEach(({ act }) => {
      list.push({
        key: act.id,
        group: 'Actions',
        title: act.title,
        subtitle: act.description,
        badge: act.category,
        icon: act.icon,
        onSelect: () => {
          setScreen(act.screen);
          closeAll();
        },
      });
    });

    // 2. Matching recipes
    const matchedRecipes = allRecipes
      .filter((r) => {
        const hay = `${r.title} ${r.cuisine} ${r.dietType} ${r.ingredients.map((i) => i.name).join(' ')}`.toLowerCase();
        return terms.every((t) => hay.includes(t));
      })
      .slice(0, 4);

    matchedRecipes.forEach((rec) => {
      list.push({
        key: `rec-${rec.id}`,
        group: 'Recipes',
        title: rec.title,
        subtitle: `${rec.cuisine} · ${rec.prepTimeMins}m · ${formatCurrency(rec.estimatedCostINR, state.user.currency)}`,
        badge: 'Recipe',
        icon: ChefHat,
        onSelect: () => {
          openRecipe(rec);
          closeAll();
        },
      });
    });

    // 3. Matching pantry or grocery items
    const matchedPantry = state.pantry
      .filter((p) => terms.every((t) => `${p.name} ${p.storageLocation} ${p.category}`.toLowerCase().includes(t)))
      .slice(0, 3);
    matchedPantry.forEach((p) => {
      list.push({
        key: `pan-${p.id}`,
        group: 'Pantry & Cart',
        title: p.name,
        subtitle: `In ${p.storageLocation} (${p.quantity} ${p.unit})`,
        badge: 'Pantry',
        icon: Package,
        onSelect: () => {
          setScreen('pantry');
          closeAll();
        },
      });
    });

    const matchedGrocery = state.groceryList
      .filter((g) => terms.every((t) => `${g.name} ${g.category}`.toLowerCase().includes(t)))
      .slice(0, 3);
    matchedGrocery.forEach((g) => {
      list.push({
        key: `groc-${g.id}`,
        group: 'Pantry & Cart',
        title: g.name,
        subtitle: `${g.purchased ? 'Purchased' : 'In cart'} · ${g.quantity} ${g.unit}`,
        badge: 'Cart',
        icon: ShoppingCart,
        onSelect: () => {
          setScreen('grocery-list');
          closeAll();
        },
      });
    });

    // 4. Ask Kitchly AI fallback
    list.push({
      key: 'ask-ai',
      group: 'AI',
      title: `Ask Kitchly AI: "${query.trim()}"`,
      subtitle: 'Get instant recipe ideas, kitchen guidance, or app help',
      badge: 'AI',
      icon: Sparkles,
      onSelect: () => {
        askAssistantWithPrompt(query.trim());
        closeAll();
      },
    });

    return list;
  }, [query, allRecipes, state.pantry, state.groceryList, state.user.currency, setScreen, openRecipe, askAssistantWithPrompt]);

  useEffect(() => {
    setActiveIndex(0);
  }, [query, results.length]);

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((prev) => (results.length ? (prev + 1) % results.length : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((prev) => (results.length ? (prev - 1 + results.length) % results.length : 0));
    } else if (e.key === 'Enter' && results[activeIndex]) {
      e.preventDefault();
      results[activeIndex].onSelect();
    } else if (e.key === 'Escape') {
      setDesktopOpen(false);
      setMobileOpen(false);
    }
  };

  const renderResultRows = () => {
    let lastGroup = '';
    return results.map((item, idx) => {
      const Icon = item.icon;
      const showGroup = item.group !== lastGroup;
      lastGroup = item.group;
      const active = idx === activeIndex;

      return (
        <React.Fragment key={item.key}>
          {showGroup && (
            <div className="px-3 pt-2.5 pb-1 text-[11px] font-semibold text-[#5B625C] tracking-tight">
              {item.group === 'Actions' && !query.trim() ? 'Quick actions — what would you like to do?' : item.group}
            </div>
          )}
          <button
            type="button"
            onMouseEnter={() => setActiveIndex(idx)}
            onClick={item.onSelect}
            className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between gap-3 text-left transition-colors ${
              active ? 'bg-[#F3F1EA]' : 'hover:bg-[#FAF9F5]'
            }`}
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  item.group === 'AI'
                    ? 'bg-[#FDF2EC] text-[#D97736]'
                    : 'bg-[#4A7C59]/10 text-[#4A7C59]'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-[#1F2421] truncate">{item.title}</p>
                <p className="text-xs text-[#5B625C] truncate">{item.subtitle}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-medium text-[#5B625C] px-2 py-0.5 rounded-md bg-white border border-[#E6E3DA]">
                {item.badge}
              </span>
              <ArrowRight className={`w-3.5 h-3.5 ${active ? 'text-[#4A7C59]' : 'text-[#9BA19B]'}`} />
            </div>
          </button>
        </React.Fragment>
      );
    });
  };

  return (
    <>
      {/* Desktop & Tablet Inline Search Bar */}
      <div ref={containerRef} className="hidden md:block relative flex-1 min-w-[210px] lg:min-w-[260px] max-w-md mx-1 lg:mx-2">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-[#5B625C] absolute left-3 pointer-events-none" />
          <input
            ref={desktopInputRef}
            type="text"
            aria-label="Search what you want to do in Kitchly"
            value={query}
            onFocus={() => setDesktopOpen(true)}
            onChange={(e) => {
              setQuery(e.target.value);
              setDesktopOpen(true);
            }}
            onKeyDown={handleInputKeyDown}
            placeholder="Search actions, recipes, pantry..."
            className="w-full h-10 pl-9 pr-8 xl:pr-14 rounded-xl bg-white border border-[#E6E3DA] text-sm text-[#1F2421] placeholder:text-[#7D847E] focus:outline-none focus:ring-2 focus:ring-[#4A7C59]"
          />
          {query ? (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                desktopInputRef.current?.focus();
              }}
              aria-label="Clear search"
              className="absolute right-2.5 p-1 rounded-md text-[#5B625C] hover:text-[#1F2421]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <kbd className="hidden xl:inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono text-[#5B625C] bg-[#F3F1EA] border border-[#E6E3DA] rounded absolute right-2.5 pointer-events-none">
              ⌘K
            </kbd>
          )}
        </div>

        {desktopOpen && (
          <div
            role="listbox"
            className="absolute left-0 right-0 mt-2 bg-white border border-[#E6E3DA] rounded-2xl shadow-xl p-2 max-h-[420px] overflow-y-auto z-50"
          >
            {renderResultRows()}
          </div>
        )}
      </div>

      {/* Mobile Compact Search Trigger */}
      <button
        type="button"
        onClick={() => {
          setMobileOpen(true);
          setTimeout(() => mobileInputRef.current?.focus(), 40);
        }}
        aria-label="Search actions and recipes"
        className="md:hidden min-h-[40px] px-2.5 rounded-lg bg-white border border-[#E6E3DA] inline-flex items-center gap-1.5 text-xs font-medium text-[#5B625C] hover:text-[#1F2421]"
      >
        <Search className="w-4 h-4 text-[#4A7C59]" />
        <span className="hidden sm:inline">Search...</span>
      </button>

      {/* Mobile Search Overlay */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/45 backdrop-blur-sm flex flex-col p-3 pt-4">
          <div className="bg-white border border-[#E6E3DA] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-3 border-b border-[#EFECE3] flex items-center gap-2">
              <Search className="w-4 h-4 text-[#4A7C59] shrink-0" />
              <input
                ref={mobileInputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleInputKeyDown}
                placeholder="Search what you want to do, recipes, items..."
                className="flex-1 h-9 text-sm text-[#1F2421] placeholder:text-[#7D847E] focus:outline-none"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  aria-label="Clear search"
                  className="p-1.5 rounded-lg text-[#5B625C]"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={closeAll}
                className="px-2.5 py-1.5 rounded-lg bg-[#F3F1EA] text-xs font-semibold text-[#1F2421]"
              >
                Close
              </button>
            </div>
            <div className="p-2 overflow-y-auto space-y-0.5">{renderResultRows()}</div>
          </div>
        </div>
      )}
    </>
  );
}
