import React, { useEffect, useState } from 'react';
import { Utensils } from 'lucide-react';

export function KitchlyLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="inline-flex items-center gap-2.5 select-none whitespace-nowrap shrink-0">
      <svg
        width="30"
        height="30"
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        <rect width="32" height="32" rx="9" fill="#4A7C59" />
        <path
          d="M10 9V23M10 16L18 9M12.5 13.8L18.5 23"
          stroke="#FAF9F5"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="22.5" cy="11.5" r="2.2" fill="#E89149" />
      </svg>
      {!compact && (
        <span className="font-display text-[22px] font-semibold tracking-normal text-[#1F2421] leading-none">
          Kitchly
        </span>
      )}
    </div>
  );
}

export function FoodImage({
  src,
  alt,
  className = 'w-full h-48 object-cover',
}: {
  src?: string;
  alt: string;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  if (!src || failed) {
    return (
      <div
        className={`${className} bg-gradient-to-br from-[#EFECE3] via-[#E5E0D3] to-[#DCE4DC] flex flex-col items-center justify-center p-4 text-center`}
        role="img"
        aria-label={alt}
      >
        <Utensils className="w-7 h-7 text-[#4A7C59] mb-1.5" />
        <span className="text-xs font-medium text-[#5B625C] line-clamp-2">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
