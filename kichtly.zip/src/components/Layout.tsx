import React, { useState } from 'react';
import {
  Bell,
  CalendarDays,
  ChefHat,
  Compass,
  Globe,
  HeartHandshake,
  Home,
  LayoutDashboard,
  ListChecks,
  Menu,
  MessageSquare,
  Package,
  Scale,
  Settings,
  ShoppingCart,
  Sparkles,
  Users,
  UtensilsCrossed,
  Wallet,
  X,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { SUPPORTED_LANGUAGES } from '../i18n/translations';
import { AppScreen, LanguageCode } from '../types/kitchly';
import { KitchlyLogo } from './Logo';
import { PWAInstallButton } from './PWAComponents';
import { GlobalActionSearch } from './GlobalActionSearch';

interface NavItem {
  id: AppScreen;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { state, t, screen, setScreen, setLanguage, isCloudSynced, sessionMode, toast } = useKitchly();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const unreadCount = state.notifications.filter((n) => !n.read).length;

  const navGroups: { title: string; items: NavItem[] }[] = [
    {
      title: 'Today',
      items: [
        { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
        { id: 'dont-know', label: t.dontKnowWhatToEat, icon: Sparkles },
        { id: 'cook-with-have', label: t.cookWithWhatIHave, icon: UtensilsCrossed },
      ],
    },
    {
      title: 'Planning & Discovery',
      items: [
        { id: 'diet-planner', label: t.dietPlanner, icon: ChefHat },
        { id: 'meal-planner', label: t.mealPlanner, icon: CalendarDays },
        { id: 'cuisine-explorer', label: t.cuisineExplorer, icon: Compass },
        { id: 'community', label: 'Kitchen Community', icon: HeartHandshake },
      ],
    },
    {
      title: 'Kitchen & Shopping',
      items: [
        { id: 'grocery-wizard', label: 'Grocery Trip Builder', icon: ListChecks },
        { id: 'grocery-list', label: t.groceryList, icon: ShoppingCart },
        { id: 'price-comparison', label: t.priceComparison, icon: Scale },
        { id: 'pantry', label: t.smartPantry, icon: Package },
        { id: 'budget', label: t.budget, icon: Wallet },
      ],
    },
    {
      title: 'Household',
      items: [
        { id: 'family', label: t.family, icon: Users },
        { id: 'cook-mode', label: t.cookMode, icon: ChefHat },
        { id: 'ai-assistant', label: t.aiAssistant, icon: MessageSquare },
        { id: 'household-profile', label: t.householdProfile, icon: Home },
        { id: 'settings', label: t.settings, icon: Settings },
      ],
    },
  ];

  // Simplified distraction-free header for Cook / Maid Mode
  if (screen === 'cook-mode') {
    return (
      <div className="min-h-screen bg-[#FAF9F5] text-[#1F2421] overflow-x-clip">
        <header className="sticky top-0 z-30 pt-[env(safe-area-inset-top)] bg-[#FAF9F5]/95 backdrop-blur-md border-b border-[#E6E3DA] px-4 lg:px-8">
          <div className="h-14 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <button
                onClick={() => setScreen('dashboard')}
                className="text-sm font-medium text-[#4A7C59] hover:text-[#3D684A] whitespace-nowrap shrink-0 min-h-[40px] flex items-center"
              >
                ← Exit Cook Mode
              </button>
              <span className="text-[#D4CFC2] hidden sm:inline" aria-hidden="true">|</span>
              <div className="hidden sm:block">
                <KitchlyLogo />
              </div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <label htmlFor="cook-lang" className="sr-only">
                {t.selectLanguage}
              </label>
              <select
                id="cook-lang"
                value={state.user.language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                className="h-10 px-2.5 sm:px-3 rounded-lg bg-white border border-[#E6E3DA] text-sm font-medium text-[#1F2421] focus:outline-none focus:ring-2 focus:ring-[#4A7C59]"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName} ({l.name})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </header>
        <main className="max-w-5xl mx-auto px-4 lg:px-8 py-6 pb-[calc(4rem+env(safe-area-inset-bottom))]">{children}</main>
        {toast && <ToastBanner message={toast} />}
      </div>
    );
  }

  const activeScreenTitle =
    navGroups.flatMap((g) => g.items).find((i) => i.id === screen)?.label ||
    (screen === 'notifications'
      ? t.notifications
      : screen === 'recipe-detail'
      ? 'Recipe Details'
      : screen === 'grocery-wizard'
      ? 'Grocery Trip Builder'
      : screen === 'language'
      ? t.selectLanguage
      : t.dashboard);

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-[#1F2421] flex overflow-x-clip">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-[#F3F1EA] border-r border-[#E6E3DA]">
        <div className="h-16 px-5 flex items-center justify-between border-b border-[#E6E3DA]">
          <button onClick={() => setScreen('dashboard')} className="text-left focus:outline-none">
            <KitchlyLogo />
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-6" aria-label="Main navigation">
          {navGroups.map((group) => (
            <div key={group.title}>
              <p className="px-3 mb-1.5 text-xs font-medium text-[#5B625C] tracking-tight">
                {group.title}
              </p>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = screen === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setScreen(item.id)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors text-left ${
                        active
                          ? 'bg-[#4A7C59] text-white'
                          : 'text-[#1F2421] hover:bg-[#E7E3D7]'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-white' : 'text-[#5B625C]'}`} />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
        <div className="p-4 border-t border-[#E6E3DA] bg-[#EFECE3]/70 space-y-2.5">
          <PWAInstallButton variant="sidebar" />
          <button
            onClick={() => setScreen('household-profile')}
            className="w-full text-left flex items-center justify-between gap-2 group"
          >
            <div className="min-w-0">
              <p className="text-sm font-semibold text-[#1F2421] truncate group-hover:text-[#4A7C59]">
                {state.user.householdName}
              </p>
              <p className="text-xs text-[#5B625C] truncate">
                {isCloudSynced ? 'Cloud Synced' : sessionMode === 'guest' ? 'Local Kitchen (Saved)' : 'Demo Kitchen'} · {state.user.currency}
              </p>
            </div>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Top Bar (3-zone contract + safe-area top) */}
        <header className="sticky top-0 z-30 pt-[env(safe-area-inset-top)] bg-[#FAF9F5]/95 backdrop-blur-md border-b border-[#E6E3DA] px-3 sm:px-4 lg:px-6 xl:px-8">
          <div className="h-14 lg:h-16 flex items-center justify-between gap-2 lg:gap-4">
            <div className="flex items-center gap-2 sm:gap-2.5 min-w-0 shrink">
              <div className="lg:hidden shrink-0">
                <button onClick={() => setScreen('dashboard')} className="focus:outline-none">
                  <KitchlyLogo compact />
                </button>
              </div>
              <h1 className="font-display text-sm sm:text-base lg:text-lg font-semibold text-[#1F2421] truncate max-w-[115px] sm:max-w-[175px] xl:max-w-[230px]">
                {activeScreenTitle}
              </h1>
            </div>

            <GlobalActionSearch />

            <div className="flex items-center gap-1 sm:gap-1.5 lg:gap-2.5 xl:gap-3.5 shrink-0">
              <div className="hidden sm:flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-[#5B625C] hidden xl:block" aria-hidden="true" />
                <select
                  aria-label={t.selectLanguage}
                  value={state.user.language}
                  onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                  className="h-9 px-2 xl:px-2.5 rounded-lg bg-white border border-[#E6E3DA] text-xs font-medium text-[#1F2421] focus:outline-none focus:ring-2 focus:ring-[#4A7C59]"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.nativeName}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={() => setScreen('notifications')}
                aria-label={t.notifications}
                className="relative min-h-[40px] min-w-[38px] sm:min-w-[40px] flex items-center justify-center rounded-lg hover:bg-[#EFECE3] transition-colors"
              >
                <Bell className="w-4 h-4 text-[#1F2421]" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 text-[10px] font-mono font-bold text-[#D97736]">
                    {unreadCount}
                  </span>
                )}
              </button>

              <PWAInstallButton variant="compact" />

              <button
                onClick={() => setScreen('ai-assistant')}
                title={t.aiAssistant}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 xl:px-3.5 py-2 rounded-lg bg-[#4A7C59] text-white text-xs font-medium hover:bg-[#3D684A] transition-colors whitespace-nowrap shrink-0"
              >
                <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                <span className="hidden xl:inline">{t.aiAssistant}</span>
                <span className="xl:hidden">AI</span>
              </button>
            </div>
          </div>
        </header>

        {/* Viewport */}
        <main className="flex-1 max-w-6xl w-full mx-auto px-3.5 sm:px-4 lg:px-8 py-5 sm:py-6 pb-[calc(5.25rem+env(safe-area-inset-bottom))] lg:pb-12">
          {children}
        </main>
      </div>

      {/* Mobile Fixed Bottom Navigation (safe-area aware) */}
      <nav
        aria-label="Mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 pb-[env(safe-area-inset-bottom)] bg-[#FAF9F5]/95 backdrop-blur-md border-t border-[#E6E3DA]"
      >
        <div className="h-[58px] grid grid-cols-5 items-center">
          {[
            { id: 'dashboard' as AppScreen, label: 'Home', icon: LayoutDashboard },
            { id: 'diet-planner' as AppScreen, label: 'Diet', icon: ChefHat },
            { id: 'grocery-list' as AppScreen, label: 'Shop', icon: ShoppingCart },
            { id: 'ai-assistant' as AppScreen, label: 'AI', icon: MessageSquare },
          ].map((item) => {
            const Icon = item.icon;
            const active = screen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setScreen(item.id)}
                className={`relative h-full flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
                  active ? 'text-[#4A7C59] font-semibold' : 'text-[#5B625C]'
                }`}
              >
                {active && (
                  <span className="absolute top-0 w-8 h-0.5 rounded-full bg-[#4A7C59]" aria-hidden="true" />
                )}
                <Icon className="w-4 h-4" />
                <span className="truncate max-w-[60px]">{item.label}</span>
              </button>
            );
          })}
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="h-full flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium text-[#5B625C]"
          >
            <Menu className="w-4 h-4" />
            <span>More</span>
          </button>
        </div>
      </nav>

      {/* Mobile Drawer for All Screens */}
      {mobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex justify-end"
          onClick={(e) => {
            if (e.target === e.currentTarget) setMobileMenuOpen(false);
          }}
        >
          <div className="w-80 max-w-[88vw] bg-[#FAF9F5] h-full overflow-y-auto p-5 pt-[calc(1.25rem+env(safe-area-inset-top))] pb-[calc(1.5rem+env(safe-area-inset-bottom))] border-l border-[#E6E3DA]">
            <div className="flex items-center justify-between mb-5">
              <KitchlyLogo />
              <button
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close menu"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg hover:bg-[#EFECE3]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mb-4">
              <label className="block text-xs font-medium text-[#5B625C] mb-1">
                {t.selectLanguage}
              </label>
              <select
                value={state.user.language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                className="w-full h-11 px-3 rounded-lg bg-white border border-[#E6E3DA] text-sm"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName} ({l.name})
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-4">
              <PWAInstallButton variant="sidebar" />
            </div>
            <div className="space-y-5">
              {navGroups.map((group) => (
                <div key={group.title}>
                  <p className="text-xs font-medium text-[#5B625C] mb-1.5">{group.title}</p>
                  <div className="space-y-1">
                    {group.items.map((item) => {
                      const Icon = item.icon;
                      const active = screen === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setScreen(item.id);
                            setMobileMenuOpen(false);
                          }}
                          className={`w-full min-h-[44px] flex items-center gap-3 px-3 rounded-lg text-sm font-medium ${
                            active ? 'bg-[#4A7C59] text-white' : 'text-[#1F2421] hover:bg-[#EFECE3]'
                          }`}
                        >
                          <Icon className="w-4 h-4 shrink-0" />
                          <span className="truncate">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {toast && <ToastBanner message={toast} />}
    </div>
  );
}

function ToastBanner({ message }: { message: string }) {
  return (
    <div
      role="status"
      className="fixed bottom-[calc(4.5rem+env(safe-area-inset-bottom))] lg:bottom-6 right-4 lg:right-6 z-50 max-w-sm bg-[#1F2421] text-[#FAF9F5] px-4 py-3 rounded-xl shadow-lg text-sm font-medium"
    >
      {message}
    </div>
  );
}
