import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, Copy, Download, ExternalLink, MoreVertical, Share, Share2, Smartphone, WifiOff, X } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export function PWAInstallButton({
  variant = 'compact',
}: {
  variant?: 'compact' | 'card' | 'sidebar';
}) {
  const {
    isInstallable,
    isInstalled,
    isIOS,
    isNonSafariIOS,
    isAndroid,
    isInIframe,
    promptFeedback,
    clearPromptFeedback,
    install,
  } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  // Suppress when already running in standalone installed PWA mode
  if (isInstalled) {
    return null;
  }

  const handlePress = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) {
        setShowGuide(true);
      }
      return;
    }
    setShowGuide(true);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(window.location.origin);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore clipboard failures on restricted contexts
    }
  };

  const handleShareUrl = async () => {
    const shareUrl = typeof window !== 'undefined' ? window.location.origin : '';
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: 'Kitchly — Meal & Grocery App',
          text: 'Plan meals, build 1-day calorie diets, and shop smarter groceries on Kitchly.',
          url: shareUrl,
        });
        return;
      } catch {
        // Fallback to copy
      }
    }
    await handleCopyUrl();
  };

  const label = isInstallable
    ? 'Install App'
    : isIOS
    ? 'Install on iOS'
    : 'Install App';

  const modal =
    showGuide && typeof document !== 'undefined'
      ? createPortal(
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="pwa-guide-title"
            className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm sm:p-4"
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setShowGuide(false);
                clearPromptFeedback();
              }
            }}
          >
            <div className="w-full sm:max-w-md max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-[#FAF9F5] border border-[#E6E3DA] p-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] sm:pb-6 shadow-2xl space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold text-[#4A7C59] mb-0.5">USE KITCHLY LIKE A MOBILE APP</p>
                  <h3 id="pwa-guide-title" className="font-display text-lg font-bold text-[#1F2421]">
                    {isIOS ? 'Add Kitchly to iPhone / iPad' : 'Install Kitchly on Your Device'}
                  </h3>
                </div>
                <button
                  onClick={() => {
                    setShowGuide(false);
                    clearPromptFeedback();
                  }}
                  aria-label="Close install instructions"
                  className="p-2 rounded-xl hover:bg-[#EFECE3] text-[#5B625C]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {promptFeedback && (
                <div className="rounded-xl bg-[#FDF2EC] border border-[#D97736]/30 px-3.5 py-2.5 text-xs text-[#9A4A18]">
                  {promptFeedback}
                </div>
              )}

              {(isInIframe || isIOS || isAndroid) && (
                <div className="rounded-xl bg-[#4A7C59]/10 border border-[#4A7C59]/25 p-3.5 space-y-2.5">
                  <p className="text-xs text-[#1F2421] leading-relaxed">
                    {isInIframe
                      ? 'Embedded preview frames block direct app installation. Open Kitchly in a full browser tab on your phone or computer to install:'
                      : isNonSafariIOS
                      ? 'Apple iOS only supports Home Screen app installation from Safari (Chrome & in-app browsers on iPhone do not expose Add to Home Screen). Copy this link and open it in Safari:'
                      : isIOS
                      ? 'You can install Kitchly right now from Safari as a full-screen home screen app:'
                      : 'Make sure you opened Kitchly in a full Chrome/Edge tab (not an in-app preview), then install directly or via browser menu:'}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <a
                      href={typeof window !== 'undefined' ? window.location.origin : '/'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Open in New Tab</span>
                    </a>
                    <button
                      type="button"
                      onClick={handleCopyUrl}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white border border-[#E6E3DA] text-[#1F2421] text-xs font-semibold hover:bg-[#F3F1EA] transition-colors"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-[#4A7C59]" />
                          <span>Link Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-[#5B625C]" />
                          <span>Copy App Link</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={handleShareUrl}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white border border-[#E6E3DA] text-[#1F2421] text-xs font-semibold hover:bg-[#F3F1EA] transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5 text-[#4A7C59]" />
                      <span>Share</span>
                    </button>
                  </div>
                </div>
              )}

              {isIOS ? (
                <ol className="space-y-3 text-sm text-[#1F2421] bg-white border border-[#E6E3DA] rounded-xl p-4">
                  <li className="flex items-start gap-2.5">
                    <span className="font-mono text-xs font-bold text-[#4A7C59] mt-0.5">1.</span>
                    <span>
                      {isNonSafariIOS
                        ? 'Paste the copied link into Apple Safari (not Chrome).'
                        : 'Make sure you are viewing Kitchly in Safari (outside any preview frame).'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="font-mono text-xs font-bold text-[#4A7C59] mt-0.5">2.</span>
                    <span>
                      Tap{' '}
                      <span className="inline-flex items-center gap-1 font-semibold">
                        Share <Share className="w-3.5 h-3.5 text-[#4A7C59]" />
                      </span>{' '}
                      at the bottom of Safari, scroll down, and tap <strong>Add to Home Screen</strong>.
                    </span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="font-mono text-xs font-bold text-[#4A7C59] mt-0.5">3.</span>
                    <span>
                      Tap <strong>Add</strong> — Kitchly opens full-screen without browser bars, just like Blinkit.
                    </span>
                  </li>
                </ol>
              ) : (
                <div className="space-y-3 text-sm text-[#1F2421] bg-white border border-[#E6E3DA] rounded-xl p-4">
                  <ul className="space-y-2.5 text-xs text-[#1F2421] leading-relaxed">
                    <li>
                      <strong className="inline-flex items-center gap-1">
                        Android (Chrome / Samsung Internet):
                      </strong>{' '}
                      Open the standalone link above in Chrome, then tap the top-right{' '}
                      <MoreVertical className="w-3.5 h-3.5 inline text-[#4A7C59]" /> menu →{' '}
                      <strong>Add to home screen</strong> → <strong>Install</strong>.
                    </li>
                    <li>
                      <strong>Desktop (Chrome / Edge):</strong> Click the <strong>Install icon</strong> on the right side of the address bar, or <strong>⋮ → Cast, save, and share → Install page as app</strong>.
                    </li>
                    <li>
                      <strong>iPhone / iPad (Safari):</strong> Tap <strong>Share</strong> →{' '}
                      <strong>Add to Home Screen</strong>.
                    </li>
                  </ul>
                </div>
              )}

              <button
                onClick={() => {
                  setShowGuide(false);
                  clearPromptFeedback();
                }}
                className="w-full py-3 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A]"
              >
                Got it
              </button>
            </div>
          </div>,
          document.body
        )
      : null;

  return (
    <>
      {variant === 'card' ? (
        <button
          onClick={handlePress}
          className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>{label}</span>
        </button>
      ) : variant === 'sidebar' ? (
        <button
          onClick={handlePress}
          className="w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-[#4A7C59] bg-[#4A7C59]/10 hover:bg-[#4A7C59]/15 transition-colors text-left"
        >
          <Smartphone className="w-4 h-4 shrink-0" />
          <span className="truncate">{label}</span>
        </button>
      ) : (
        <button
          onClick={handlePress}
          title="Install Kitchly on your device"
          className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-lg border border-[#E6E3DA] bg-white text-[#1F2421] text-xs font-semibold hover:bg-[#F3F1EA] transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5 text-[#4A7C59]" />
          <span className="hidden sm:inline">{label}</span>
          <span className="sm:hidden">Install</span>
        </button>
      )}
      {modal}
    </>
  );
}

const DISMISS_KEY = 'kitchly_install_banner_dismissed_v1';

export function MobileAppInstallBanner() {
  const { isInstalled } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    try {
      setDismissed(window.localStorage.getItem(DISMISS_KEY) === '1');
    } catch {
      setDismissed(false);
    }
  }, []);

  if (isInstalled || dismissed) return null;

  const handleDismiss = () => {
    setDismissed(true);
    try {
      window.localStorage.setItem(DISMISS_KEY, '1');
    } catch {
      // ignore storage errors
    }
  };

  return (
    <div className="bg-[#F3F1EA] border border-[#E6E3DA] rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div className="flex items-start sm:items-center gap-3 min-w-0">
        <div className="w-10 h-10 rounded-xl bg-[#4A7C59] text-white flex items-center justify-center shrink-0">
          <Smartphone className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <p className="font-display text-sm font-bold text-[#1F2421]">
            Install Kitchly App for Mobile & Desktop
          </p>
          <p className="text-xs text-[#5B625C] leading-snug mt-0.5">
            Launch full-screen from your home screen with offline recipes, quick grocery cart & instant shopping.
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
        <PWAInstallButton variant="card" />
        <button
          type="button"
          onClick={handleDismiss}
          aria-label="Dismiss install banner"
          className="p-2 rounded-xl text-[#5B625C] hover:bg-[#E6E3DA]/60"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed top-[calc(3.9rem+env(safe-area-inset-top))] right-3 lg:top-auto lg:bottom-6 lg:left-4 lg:right-auto z-50 flex items-center gap-2 rounded-xl bg-[#D97736] px-3.5 py-2 text-xs font-semibold text-white shadow-lg"
    >
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>Offline Mode — Using cached recipes & kitchen data.</span>
    </div>
  );
}
