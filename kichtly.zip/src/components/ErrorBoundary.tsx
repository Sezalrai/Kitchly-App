import React from 'react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, errorMessage: error.message || 'An unexpected error occurred.' };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('Kitchly ErrorBoundary caught error:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#FAF9F5] text-[#1F2421] flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-white border border-[#E6E3DA] rounded-2xl p-8">
            <h1 className="font-display text-2xl font-bold text-[#1F2421] mb-2">
              Something went wrong in Kitchly
            </h1>
            <p className="text-sm text-[#5B625C] mb-4 leading-relaxed">
              {this.state.errorMessage}
            </p>
            <button
              onClick={() => this.setState({ hasError: false, errorMessage: '' })}
              className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A] transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
