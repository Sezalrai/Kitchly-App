import { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  Unsubscribe,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  CookTask,
  DietPlannerProfile,
  FamilyMember,
  GeneratedDietPlan,
  GroceryItem,
  KitchlyState,
  NotificationItem,
  PantryItem,
  Recipe,
  WeeklyMealSlot,
} from '../types/kitchly';
import { createFreshUserKitchlyState } from '../data/defaultState';

export function sanitizeId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 100);
  return cleaned || `id-${Date.now()}`;
}

function stripUndefined<T>(val: T): T {
  if (Array.isArray(val)) {
    return val.map((item) => stripUndefined(item)) as unknown as T;
  }
  if (val !== null && typeof val === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(val as Record<string, unknown>)) {
      if (v !== undefined) out[k] = stripUndefined(v);
    }
    return out as T;
  }
  return val;
}

export async function bootstrapUserInFirestore(
  firebaseUser: User
): Promise<{ isNewUser: boolean; onboarded: boolean }> {
  const uid = firebaseUser.uid;
  const userRef = doc(db, 'users', uid);
  const householdRef = doc(db, 'households', uid);

  let userExists = false;
  try {
    const userSnap = await getDoc(userRef);
    userExists = userSnap.exists();
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `users/${uid}`);
  }

  if (!userExists) {
    try {
      await setDoc(userRef, {
        uid,
        displayName: (firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Kitchly User').slice(0, 100),
        email: (firebaseUser.email || 'user@kitchly.app').slice(0, 200),
        householdId: uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
    }
  }

  let hhExists = false;
  let hhOnboarded = false;
  let isLegacyDemoClone = false;
  try {
    const hhSnap = await getDoc(householdRef);
    hhExists = hhSnap.exists();
    if (hhExists) {
      const hhData = hhSnap.data();
      hhOnboarded = Boolean(hhData?.onboarded);
      isLegacyDemoClone = hhData?.householdName === 'Kitchly Demo Kitchen';
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `households/${uid}`);
  }

  if (hhExists && isLegacyDemoClone) {
    await resetHouseholdDataFS(uid, firebaseUser);
    return { isNewUser: true, onboarded: false };
  }

  if (!hhExists) {
    try {
      const fresh = createFreshUserKitchlyState({
        id: uid,
        name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'My Kitchen',
        email: firebaseUser.email || '',
        onboarded: false,
      });

      // Create root household document with empty spend/budgets so new users start clean
      await setDoc(householdRef, {
        ownerId: uid,
        householdName: fresh.user.householdName.slice(0, 120),
        country: fresh.user.country,
        currency: fresh.user.currency,
        language: fresh.user.language,
        onboarded: false,
        cookModePin: fresh.user.cookModePin,
        monthlySpentINR: 0,
        estimatedSavingsINR: 0,
        dietProfile: stripUndefined(fresh.dietProfile as unknown as Record<string, unknown>),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Create only the signed-in owner profile in family subcollection (no demo cart/pantry/plans)
      if (fresh.familyMembers[0]) {
        await upsertFamilyMemberFS(uid, fresh.familyMembers[0]);
      }

      return { isNewUser: true, onboarded: false };
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `households/${uid}`);
    }
  }

  return { isNewUser: false, onboarded: hhOnboarded };
}

export function subscribeHouseholdState(
  uid: string,
  firebaseUser: User,
  onUpdate: (updater: (prev: KitchlyState) => KitchlyState) => void
): Unsubscribe {
  const unsubs: Unsubscribe[] = [];

  const hhPath = `households/${uid}`;
  unsubs.push(
    onSnapshot(
      doc(db, 'households', uid),
      (snap) => {
        if (!snap.exists()) return;
        const d = snap.data();
        onUpdate((prev) => ({
          ...prev,
          user: {
            ...prev.user,
            id: uid,
            name: firebaseUser.displayName || prev.user.name,
            email: firebaseUser.email || prev.user.email,
            householdName: String(d.householdName || prev.user.householdName),
            country: String(d.country || prev.user.country),
            currency: d.currency || prev.user.currency,
            language: d.language || prev.user.language,
            onboarded: Boolean(d.onboarded),
            cookModePin: String(d.cookModePin || prev.user.cookModePin),
          },
          monthlySpentINR: Number(d.monthlySpentINR ?? prev.monthlySpentINR),
          estimatedSavingsINR: Number(d.estimatedSavingsINR ?? prev.estimatedSavingsINR),
          dietProfile: (d.dietProfile as DietPlannerProfile) || prev.dietProfile,
        }));
      },
      (err) => console.warn(`Firestore listener warning (${hhPath}):`, err)
    )
  );

  // Pantry
  const pantryPath = `households/${uid}/pantry`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'households', uid, 'pantry'), where('ownerId', '==', uid)),
      (snap) => {
        const items: PantryItem[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            name: String(d.name),
            quantity: Number(d.quantity),
            unit: String(d.unit),
            category: d.category,
            purchaseDate: String(d.purchaseDate),
            expiryDate: String(d.expiryDate),
            storageLocation: d.storageLocation,
            lowStockThreshold: Number(d.lowStockThreshold),
          };
        });
        onUpdate((prev) => ({ ...prev, pantry: items }));
      },
      (err) => console.warn(`Firestore listener warning (${pantryPath}):`, err)
    )
  );

  // Grocery
  const groceryPath = `households/${uid}/grocery`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'households', uid, 'grocery'), where('ownerId', '==', uid)),
      (snap) => {
        const items: GroceryItem[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            name: String(d.name),
            quantity: Number(d.quantity),
            unit: String(d.unit),
            category: d.category,
            estimatedCostINR: Number(d.estimatedCostINR),
            purchased: Boolean(d.purchased),
            source: d.source,
          };
        });
        onUpdate((prev) => ({ ...prev, groceryList: items }));
      },
      (err) => console.warn(`Firestore listener warning (${groceryPath}):`, err)
    )
  );

  // Family
  const familyPath = `households/${uid}/family`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'households', uid, 'family'), where('ownerId', '==', uid)),
      (snap) => {
        const members: FamilyMember[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            name: String(d.name),
            role: d.role,
            foodPreferences: d.foodPreferences || [],
            allergies: d.allergies || [],
            likes: d.likes || [],
            dislikes: d.dislikes || [],
            mealPreferences: String(d.mealPreferences || ''),
            dietGoal: d.dietGoal,
          };
        });
        onUpdate((prev) => ({ ...prev, familyMembers: members }));
      },
      (err) => console.warn(`Firestore listener warning (${familyPath}):`, err)
    )
  );

  // Cook Tasks
  const cookPath = `households/${uid}/cookTasks`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'households', uid, 'cookTasks'), where('ownerId', '==', uid)),
      (snap) => {
        const tasks: CookTask[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            mealSlot: d.mealSlot,
            recipeId: String(d.recipeId),
            recipeTitle: String(d.recipeTitle),
            scheduledTime: String(d.scheduledTime),
            servings: Number(d.servings),
            notes: String(d.notes || ''),
            completed: Boolean(d.completed),
            checklistDone: Array.isArray(d.checklistDone) ? d.checklistDone : [],
          };
        });
        onUpdate((prev) => ({ ...prev, cookTasks: tasks }));
      },
      (err) => console.warn(`Firestore listener warning (${cookPath}):`, err)
    )
  );

  // Plans (weekly + diet)
  const plansPath = `households/${uid}/plans`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'households', uid, 'plans'), where('ownerId', '==', uid)),
      (snap) => {
        let weeklyDays: WeeklyMealSlot[] = [];
        let dietPlan: GeneratedDietPlan | null = null;
        snap.docs.forEach((docSnap) => {
          const d = docSnap.data();
          if (d.planKind === 'weekly-plan' && Array.isArray(d.payload?.days)) {
            weeklyDays = d.payload.days as WeeklyMealSlot[];
          } else if (d.planKind === 'diet-plan' && d.payload?.plan) {
            dietPlan = d.payload.plan as GeneratedDietPlan;
          }
        });
        onUpdate((prev) => ({
          ...prev,
          weeklyPlan: weeklyDays,
          currentDietPlan: dietPlan,
        }));
      },
      (err) => console.warn(`Firestore listener warning (${plansPath}):`, err)
    )
  );

  // Saved / AI Recipes
  const recipesPath = `households/${uid}/recipes`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'households', uid, 'recipes'), where('ownerId', '==', uid)),
      (snap) => {
        const customRecipes: Recipe[] = [];
        const favoriteRecipeIds: string[] = [];
        snap.docs.forEach((docSnap) => {
          const d = docSnap.data();
          if (d.isFavorite) favoriteRecipeIds.push(docSnap.id);
          if (d.isAiGenerated) {
            customRecipes.push({
              id: docSnap.id,
              title: String(d.title),
              cuisine: String(d.cuisine),
              dietType: d.dietType,
              prepTimeMins: Number(d.prepTimeMins),
              difficulty: d.difficulty,
              servings: Number(d.servings),
              estimatedCostINR: Number(d.estimatedCostINR),
              image: String(d.image),
              description: String(d.description || ''),
              isFavorite: Boolean(d.isFavorite),
              isAiGenerated: Boolean(d.isAiGenerated),
              nutrition: d.nutrition,
              ingredients: d.ingredients || [],
              instructions: d.instructions || [],
              allergens: d.allergens || [],
              tags: d.tags || [],
            });
          }
        });
        onUpdate((prev) => ({ ...prev, customRecipes, favoriteRecipeIds }));
      },
      (err) => console.warn(`Firestore listener warning (${recipesPath}):`, err)
    )
  );

  // Notifications
  const notifPath = `households/${uid}/notifications`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'households', uid, 'notifications'), where('ownerId', '==', uid)),
      (snap) => {
        const notifications: NotificationItem[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            type: d.type,
            title: String(d.title),
            message: String(d.message),
            timestamp: String(d.timestamp),
            read: Boolean(d.read),
            targetScreen: d.targetScreen || undefined,
          };
        });
        onUpdate((prev) => ({ ...prev, notifications }));
      },
      (err) => console.warn(`Firestore listener warning (${notifPath}):`, err)
    )
  );

  return () => {
    unsubs.forEach((u) => u());
  };
}

export async function updateHouseholdFieldsFS(
  uid: string,
  fields: Partial<{
    householdName: string;
    country: string;
    currency: string;
    language: string;
    onboarded: boolean;
    cookModePin: string;
    dietProfile: DietPlannerProfile;
    monthlySpentINR: number;
    estimatedSavingsINR: number;
  }>
) {
  const path = `households/${uid}`;
  try {
    const cleanFields = stripUndefined(fields);
    await updateDoc(doc(db, 'households', uid), {
      ...cleanFields,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function upsertPantryItemFS(uid: string, item: PantryItem) {
  const id = sanitizeId(item.id);
  const path = `households/${uid}/pantry/${id}`;
  try {
    const ref = doc(db, 'households', uid, 'pantry', id);
    const snap = await getDoc(ref);
    const payload = {
      ownerId: uid,
      name: item.name.slice(0, 120),
      quantity: Math.max(0, Number(item.quantity) || 0),
      unit: item.unit.slice(0, 30),
      category: item.category.slice(0, 50),
      purchaseDate: item.purchaseDate.slice(0, 30),
      expiryDate: item.expiryDate.slice(0, 30),
      storageLocation: item.storageLocation,
      lowStockThreshold: Math.max(0, Number(item.lowStockThreshold) || 0),
      updatedAt: serverTimestamp(),
    };
    if (snap.exists()) {
      await updateDoc(ref, payload);
    } else {
      await setDoc(ref, { ...payload, createdAt: serverTimestamp() });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deletePantryItemFS(uid: string, itemId: string) {
  const id = sanitizeId(itemId);
  try {
    await deleteDoc(doc(db, 'households', uid, 'pantry', id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `households/${uid}/pantry/${id}`);
  }
}

export async function upsertGroceryItemFS(uid: string, item: GroceryItem) {
  const id = sanitizeId(item.id);
  const path = `households/${uid}/grocery/${id}`;
  try {
    const ref = doc(db, 'households', uid, 'grocery', id);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        name: item.name.slice(0, 120),
        quantity: Math.max(0.1, Number(item.quantity) || 1),
        unit: item.unit.slice(0, 30),
        category: item.category.slice(0, 50),
        estimatedCostINR: Math.max(0, Number(item.estimatedCostINR) || 0),
        purchased: Boolean(item.purchased),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        ownerId: uid,
        name: item.name.slice(0, 120),
        quantity: Math.max(0.1, Number(item.quantity) || 1),
        unit: item.unit.slice(0, 30),
        category: item.category.slice(0, 50),
        estimatedCostINR: Math.max(0, Number(item.estimatedCostINR) || 0),
        purchased: Boolean(item.purchased),
        source: item.source,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteGroceryItemFS(uid: string, itemId: string) {
  const id = sanitizeId(itemId);
  try {
    await deleteDoc(doc(db, 'households', uid, 'grocery', id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `households/${uid}/grocery/${id}`);
  }
}

export async function upsertFamilyMemberFS(uid: string, member: FamilyMember) {
  const id = sanitizeId(member.id);
  const path = `households/${uid}/family/${id}`;
  try {
    const ref = doc(db, 'households', uid, 'family', id);
    const snap = await getDoc(ref);
    const fields = {
      name: member.name.slice(0, 80),
      role: member.role,
      foodPreferences: member.foodPreferences.slice(0, 10),
      allergies: member.allergies.slice(0, 15),
      likes: member.likes.slice(0, 20),
      dislikes: member.dislikes.slice(0, 20),
      mealPreferences: member.mealPreferences.slice(0, 240),
      dietGoal: member.dietGoal.slice(0, 80),
      updatedAt: serverTimestamp(),
    };
    if (snap.exists()) {
      await updateDoc(ref, fields);
    } else {
      await setDoc(ref, { ...fields, ownerId: uid, createdAt: serverTimestamp() });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteFamilyMemberFS(uid: string, memberId: string) {
  const id = sanitizeId(memberId);
  try {
    await deleteDoc(doc(db, 'households', uid, 'family', id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `households/${uid}/family/${id}`);
  }
}

export async function upsertCookTaskFS(uid: string, task: CookTask) {
  const id = sanitizeId(task.id);
  const path = `households/${uid}/cookTasks/${id}`;
  try {
    const ref = doc(db, 'households', uid, 'cookTasks', id);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        mealSlot: task.mealSlot,
        recipeId: task.recipeId.slice(0, 128),
        recipeTitle: task.recipeTitle.slice(0, 160),
        scheduledTime: task.scheduledTime.slice(0, 40),
        servings: Math.max(1, Math.min(30, Number(task.servings) || 2)),
        notes: task.notes.slice(0, 500),
        completed: Boolean(task.completed),
        checklistDone: task.checklistDone.slice(0, 30),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        ownerId: uid,
        mealSlot: task.mealSlot,
        recipeId: task.recipeId.slice(0, 128),
        recipeTitle: task.recipeTitle.slice(0, 160),
        scheduledTime: task.scheduledTime.slice(0, 40),
        servings: Math.max(1, Math.min(30, Number(task.servings) || 2)),
        notes: task.notes.slice(0, 500),
        completed: Boolean(task.completed),
        checklistDone: task.checklistDone.slice(0, 30),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function saveWeeklyPlanFS(uid: string, days: WeeklyMealSlot[]) {
  const path = `households/${uid}/plans/weekly-plan`;
  try {
    const ref = doc(db, 'households', uid, 'plans', 'weekly-plan');
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, { payload: { days }, updatedAt: serverTimestamp() });
    } else {
      await setDoc(ref, {
        ownerId: uid,
        planKind: 'weekly-plan',
        payload: { days },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function saveDietPlanFS(uid: string, plan: GeneratedDietPlan) {
  const path = `households/${uid}/plans/diet-plan`;
  try {
    const cleanPlan = stripUndefined(plan);
    const ref = doc(db, 'households', uid, 'plans', 'diet-plan');
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, { payload: { plan: cleanPlan }, updatedAt: serverTimestamp() });
    } else {
      await setDoc(ref, {
        ownerId: uid,
        planKind: 'diet-plan',
        payload: { plan: cleanPlan },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function upsertRecipeFS(uid: string, recipe: Recipe, isFavorite: boolean) {
  const id = sanitizeId(recipe.id);
  const path = `households/${uid}/recipes/${id}`;
  try {
    const ref = doc(db, 'households', uid, 'recipes', id);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        isFavorite,
        servings: Math.max(1, Number(recipe.servings) || 2),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        ownerId: uid,
        title: recipe.title.slice(0, 160),
        cuisine: String(recipe.cuisine).slice(0, 60),
        dietType: String(recipe.dietType).slice(0, 40),
        prepTimeMins: Math.max(1, Number(recipe.prepTimeMins) || 20),
        difficulty: recipe.difficulty,
        servings: Math.max(1, Number(recipe.servings) || 2),
        estimatedCostINR: Math.max(0, Number(recipe.estimatedCostINR) || 100),
        image: (() => {
          const raw = (recipe.image || '/src/assets/images/meal_asian_noodles_1795377616512.jpg').trim();
          if (raw.startsWith('data:image/')) {
            return raw.length <= 280000 ? raw : '/src/assets/images/meal_asian_noodles_1795377616512.jpg';
          }
          if (raw.startsWith('http://') || raw.startsWith('https://') || raw.startsWith('/')) {
            return raw.slice(0, 500);
          }
          return '/src/assets/images/meal_asian_noodles_1795377616512.jpg';
        })(),
        description: recipe.description.slice(0, 600),
        isFavorite,
        isAiGenerated: Boolean(recipe.isAiGenerated),
        nutrition: recipe.nutrition,
        ingredients: recipe.ingredients.slice(0, 35),
        instructions: recipe.instructions.slice(0, 30),
        allergens: recipe.allergens.slice(0, 15),
        tags: recipe.tags.slice(0, 15),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function upsertNotificationFS(uid: string, notif: NotificationItem) {
  const id = sanitizeId(notif.id);
  const path = `households/${uid}/notifications/${id}`;
  try {
    const ref = doc(db, 'households', uid, 'notifications', id);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, { read: Boolean(notif.read), updatedAt: serverTimestamp() });
    } else {
      await setDoc(ref, {
        ownerId: uid,
        type: notif.type,
        title: notif.title.slice(0, 140),
        message: notif.message.slice(0, 400),
        timestamp: notif.timestamp.slice(0, 60),
        read: Boolean(notif.read),
        targetScreen: (notif.targetScreen || '').slice(0, 60),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function resetHouseholdDataFS(uid: string, firebaseUser: User): Promise<void> {
  const fresh = createFreshUserKitchlyState({
    id: uid,
    name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'My Kitchen',
    email: firebaseUser.email || '',
    onboarded: false,
  });

  const subcollections = ['pantry', 'grocery', 'cookTasks', 'notifications', 'plans', 'recipes', 'family'] as const;
  for (const sub of subcollections) {
    const path = `households/${uid}/${sub}`;
    try {
      const snap = await getDocs(query(collection(db, 'households', uid, sub), where('ownerId', '==', uid)));
      await Promise.all(snap.docs.map((docSnap) => deleteDoc(docSnap.ref)));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  }

  try {
    await updateHouseholdFieldsFS(uid, {
      householdName: fresh.user.householdName,
      country: fresh.user.country,
      currency: fresh.user.currency,
      language: fresh.user.language,
      onboarded: false,
      dietProfile: fresh.dietProfile,
    });
    await updateHouseholdFieldsFS(uid, {
      monthlySpentINR: 0,
      estimatedSavingsINR: 0,
    });
    if (fresh.familyMembers[0]) {
      await upsertFamilyMemberFS(uid, fresh.familyMembers[0]);
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `households/${uid}`);
  }
}

