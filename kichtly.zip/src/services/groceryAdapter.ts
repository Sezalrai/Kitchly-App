import { GroceryCategory, GroceryItem } from '../types/kitchly';

export type PriceDataSource = 'sample' | 'estimated' | 'live_api';

export interface GroceryPlatformConfig {
  id: string;
  name: string;
  region: 'India' | 'Global';
  deliveryTimeLabel: string;
  baseDeliveryFeeINR: number;
  freeDeliveryMinOrderINR: number;
  minOrderINR: number;
  handlingFeeINR: number;
  storeHomeUrl: string;
  buildSearchUrl: (query: string) => string;
  apiStatus: 'requires_credentials' | 'connected';
  requiredCredentialHint: string;
}

export interface StoreCatalogProduct {
  id: string;
  name: string;
  brand: string;
  packSize: string;
  quantity: number;
  unit: string;
  category: GroceryCategory;
  region: 'India' | 'Global';
  mrpINR: number;
  multipliers: Record<string, number>;
}

export interface PlatformProductOffer {
  platformId: string;
  platformName: string;
  productName: string;
  brand: string;
  packSize: string;
  equivalentUnits: number;
  mrpINR: number;
  priceINR: number;
  discountPct: number;
  inStock: boolean;
  searchUrl: string;
  dataSource: PriceDataSource;
}

export interface ProductComparisonRow {
  groceryItem: GroceryItem;
  offers: PlatformProductOffer[];
  cheapestOffer: PlatformProductOffer | null;
  savingsVsHighestINR: number;
  alternativeProduct?: string;
}

export interface CompleteBasketSummary {
  platform: GroceryPlatformConfig;
  itemsSubtotalINR: number;
  deliveryFeeINR: number;
  handlingFeeINR: number;
  minOrderTopUpNeededINR: number;
  totalPayableINR: number;
  unavailableCount: number;
  isCheapest: boolean;
  dataSource: PriceDataSource;
}

export interface SmartSplitPlan {
  recommended: boolean;
  singleBestPlatform: CompleteBasketSummary;
  splitPlatforms: {
    platform: GroceryPlatformConfig;
    items: { item: GroceryItem; offer: PlatformProductOffer }[];
    subtotalINR: number;
    deliveryFeeINR: number;
    handlingFeeINR: number;
    totalINR: number;
  }[];
  splitGrandTotalINR: number;
  netSavingsAfterFeesINR: number;
  reason: string;
}

export const INDIA_PLATFORMS: GroceryPlatformConfig[] = [
  {
    id: 'blinkit',
    name: 'Blinkit',
    region: 'India',
    deliveryTimeLabel: '10–15 mins',
    baseDeliveryFeeINR: 25,
    freeDeliveryMinOrderINR: 299,
    minOrderINR: 99,
    handlingFeeINR: 5,
    storeHomeUrl: 'https://blinkit.com/',
    buildSearchUrl: (q) => `https://blinkit.com/s/?q=${encodeURIComponent(q)}`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'BLINKIT_PARTNER_API_KEY',
  },
  {
    id: 'zepto',
    name: 'Zepto',
    region: 'India',
    deliveryTimeLabel: '10–14 mins',
    baseDeliveryFeeINR: 29,
    freeDeliveryMinOrderINR: 249,
    minOrderINR: 99,
    handlingFeeINR: 7,
    storeHomeUrl: 'https://www.zeptonow.com/',
    buildSearchUrl: (q) => `https://www.zeptonow.com/search?query=${encodeURIComponent(q)}`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'ZEPTO_MERCHANT_TOKEN',
  },
  {
    id: 'instamart',
    name: 'Swiggy Instamart',
    region: 'India',
    deliveryTimeLabel: '12–18 mins',
    baseDeliveryFeeINR: 30,
    freeDeliveryMinOrderINR: 349,
    minOrderINR: 99,
    handlingFeeINR: 6,
    storeHomeUrl: 'https://www.swiggy.com/instamart',
    buildSearchUrl: (q) =>
      `https://www.swiggy.com/instamart/search?custom_back=true&query=${encodeURIComponent(q)}`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'SWIGGY_CATALOG_API_KEY',
  },
  {
    id: 'bigbasket',
    name: 'BigBasket',
    region: 'India',
    deliveryTimeLabel: 'Same-day / 2 hrs',
    baseDeliveryFeeINR: 20,
    freeDeliveryMinOrderINR: 499,
    minOrderINR: 199,
    handlingFeeINR: 0,
    storeHomeUrl: 'https://www.bigbasket.com/',
    buildSearchUrl: (q) => `https://www.bigbasket.com/ps/?q=${encodeURIComponent(q)}`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'BIGBASKET_PARTNER_KEY',
  },
];

export const EXTRA_STORE_SEARCH_URLS: Record<string, { home: string; build: (q: string) => string; delivery: string }> = {
  'dmart ready': {
    home: 'https://www.dmart.in/',
    build: (q) => `https://www.dmart.in/search?searchTerm=${encodeURIComponent(q)}`,
    delivery: 'Next-day pickup & delivery',
  },
  'reliance fresh': {
    home: 'https://www.jiomart.com/',
    build: (q) => `https://www.jiomart.com/search/${encodeURIComponent(q)}`,
    delivery: 'Same-day JioMart',
  },
  walmart: {
    home: 'https://www.walmart.com/cp/groceries/976759',
    build: (q) => `https://www.walmart.com/search?q=${encodeURIComponent(q)}`,
    delivery: '1–2 hr delivery',
  },
  costco: {
    home: 'https://www.costco.com/grocery-household.html',
    build: (q) => `https://www.costco.com/CatalogSearch?keyword=${encodeURIComponent(q)}`,
    delivery: 'Same-day warehouse',
  },
  kroger: {
    home: 'https://www.kroger.com/',
    build: (q) => `https://www.kroger.com/search?query=${encodeURIComponent(q)}`,
    delivery: '1–2 hr pickup/delivery',
  },
  aldi: {
    home: 'https://new.aldi.us/',
    build: (q) => `https://new.aldi.us/results?q=${encodeURIComponent(q)}`,
    delivery: 'Instacart / Pickup',
  },
  target: {
    home: 'https://www.target.com/c/grocery/-/N-5xt1a',
    build: (q) => `https://www.target.com/s?searchTerm=${encodeURIComponent(q)}`,
    delivery: '2-hr Drive Up',
  },
  "trader joe's": {
    home: 'https://www.traderjoes.com/home/products',
    build: (q) => `https://www.traderjoes.com/home/search?q=${encodeURIComponent(q)}`,
    delivery: 'In-store browse',
  },
  'whole foods': {
    home: 'https://www.wholefoodsmarket.com/',
    build: (q) => `https://www.amazon.com/s?k=${encodeURIComponent(q)}&i=wholefoods`,
    delivery: '2-hr Prime delivery',
  },
};

export const GLOBAL_PLATFORMS: GroceryPlatformConfig[] = [
  {
    id: 'instacart',
    name: 'Instacart',
    region: 'Global',
    deliveryTimeLabel: '45–60 mins',
    baseDeliveryFeeINR: 320,
    freeDeliveryMinOrderINR: 2900,
    minOrderINR: 850,
    handlingFeeINR: 120,
    storeHomeUrl: 'https://www.instacart.com/',
    buildSearchUrl: (q) => `https://www.instacart.com/store/s?k=${encodeURIComponent(q)}`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'INSTACART_CONNECT_API_KEY',
  },
  {
    id: 'amazon-fresh',
    name: 'Amazon Fresh',
    region: 'Global',
    deliveryTimeLabel: '2-hour window',
    baseDeliveryFeeINR: 250,
    freeDeliveryMinOrderINR: 4200,
    minOrderINR: 1200,
    handlingFeeINR: 0,
    storeHomeUrl: 'https://www.amazon.com/alm/storefront?almBrandId=QW1hem9uIEZyZXNo',
    buildSearchUrl: (q) => `https://www.amazon.com/s?k=${encodeURIComponent(q)}&i=amazonfresh`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'AMAZON_SP_API_CREDENTIALS',
  },
  {
    id: 'walmart',
    name: 'Walmart Grocery',
    region: 'Global',
    deliveryTimeLabel: '1–2 hours',
    baseDeliveryFeeINR: 290,
    freeDeliveryMinOrderINR: 2900,
    minOrderINR: 1000,
    handlingFeeINR: 0,
    storeHomeUrl: 'https://www.walmart.com/cp/groceries/976759',
    buildSearchUrl: (q) => `https://www.walmart.com/search?q=${encodeURIComponent(q)}`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'WALMART_MARKETPLACE_KEY',
  },
  {
    id: 'target',
    name: 'Target',
    region: 'Global',
    deliveryTimeLabel: 'Same-day / 2 hrs',
    baseDeliveryFeeINR: 220,
    freeDeliveryMinOrderINR: 2900,
    minOrderINR: 850,
    handlingFeeINR: 0,
    storeHomeUrl: 'https://www.target.com/c/grocery/-/N-5xt1a',
    buildSearchUrl: (q) => `https://www.target.com/s?searchTerm=${encodeURIComponent(q)}`,
    apiStatus: 'requires_credentials',
    requiredCredentialHint: 'TARGET_RED_CIRCLE_PARTNER_KEY',
  },
];

export const ALL_PLATFORMS: GroceryPlatformConfig[] = [...INDIA_PLATFORMS, ...GLOBAL_PLATFORMS];

export function findPlatformConfigByName(storeName: string): GroceryPlatformConfig | undefined {
  const lower = storeName.toLowerCase().trim();
  return ALL_PLATFORMS.find(
    (p) =>
      p.id === lower ||
      p.name.toLowerCase() === lower ||
      p.name.toLowerCase().includes(lower) ||
      lower.includes(p.id)
  );
}

export function getStoreHomeUrl(storeName: string): string {
  const matched = findPlatformConfigByName(storeName);
  if (matched) return matched.storeHomeUrl;
  const extra = EXTRA_STORE_SEARCH_URLS[storeName.toLowerCase().trim()];
  if (extra) return extra.home;
  return `https://www.google.com/search?q=${encodeURIComponent(`${storeName} grocery delivery`)}`;
}

export function getStoreItemSearchUrl(storeName: string, itemName: string): string {
  const matched = findPlatformConfigByName(storeName);
  if (matched) return matched.buildSearchUrl(itemName);
  const extra = EXTRA_STORE_SEARCH_URLS[storeName.toLowerCase().trim()];
  if (extra) return extra.build(itemName);
  return `https://www.google.com/search?q=${encodeURIComponent(`${itemName} buy on ${storeName}`)}`;
}

// Deterministic realistic store catalog offerings so users can browse & add store items directly to cart
export const STORE_BROWSE_CATALOG: StoreCatalogProduct[] = [
  // India quick-commerce & supermarket staples
  {
    id: 'cat-in-paneer',
    name: 'Amul Fresh Malai Paneer',
    brand: 'Amul',
    packSize: '200 g',
    quantity: 200,
    unit: 'g',
    category: 'Dairy',
    region: 'India',
    mrpINR: 95,
    multipliers: { blinkit: 0.96, zepto: 0.94, instamart: 0.97, bigbasket: 0.92 },
  },
  {
    id: 'cat-in-milk',
    name: 'Amul Taaza Toned Fresh Milk',
    brand: 'Amul',
    packSize: '1 L Tetra',
    quantity: 1,
    unit: 'L',
    category: 'Dairy',
    region: 'India',
    mrpINR: 74,
    multipliers: { blinkit: 0.97, zepto: 0.95, instamart: 0.98, bigbasket: 0.93 },
  },
  {
    id: 'cat-in-curd',
    name: 'Mother Dairy Classic Dahi',
    brand: 'Mother Dairy',
    packSize: '400 g cup',
    quantity: 400,
    unit: 'g',
    category: 'Dairy',
    region: 'India',
    mrpINR: 50,
    multipliers: { blinkit: 0.96, zepto: 0.92, instamart: 0.96, bigbasket: 0.9 },
  },
  {
    id: 'cat-in-eggs',
    name: 'Eggoz Farm Fresh White Eggs',
    brand: 'Eggoz',
    packSize: '10 pcs',
    quantity: 10,
    unit: 'pcs',
    category: 'Dairy',
    region: 'India',
    mrpINR: 115,
    multipliers: { blinkit: 0.89, zepto: 0.86, instamart: 0.91, bigbasket: 0.84 },
  },
  {
    id: 'cat-in-tomato',
    name: 'Fresh Hybrid Tomatoes',
    brand: 'Farm Produce',
    packSize: '500 g',
    quantity: 500,
    unit: 'g',
    category: 'Vegetables',
    region: 'India',
    mrpINR: 48,
    multipliers: { blinkit: 0.85, zepto: 0.79, instamart: 0.88, bigbasket: 0.75 },
  },
  {
    id: 'cat-in-onion',
    name: 'Nashik Red Onions',
    brand: 'Farm Produce',
    packSize: '1 kg',
    quantity: 1,
    unit: 'kg',
    category: 'Vegetables',
    region: 'India',
    mrpINR: 64,
    multipliers: { blinkit: 0.89, zepto: 0.84, instamart: 0.88, bigbasket: 0.78 },
  },
  {
    id: 'cat-in-potato',
    name: 'Agra Jyoti Potatoes',
    brand: 'Farm Produce',
    packSize: '1 kg',
    quantity: 1,
    unit: 'kg',
    category: 'Vegetables',
    region: 'India',
    mrpINR: 52,
    multipliers: { blinkit: 0.88, zepto: 0.82, instamart: 0.86, bigbasket: 0.79 },
  },
  {
    id: 'cat-in-spinach',
    name: 'Hydroponic Baby Spinach (Palak)',
    brand: 'Fresh Greens',
    packSize: '250 g',
    quantity: 250,
    unit: 'g',
    category: 'Vegetables',
    region: 'India',
    mrpINR: 45,
    multipliers: { blinkit: 0.87, zepto: 0.84, instamart: 0.9, bigbasket: 0.8 },
  },
  {
    id: 'cat-in-atta',
    name: 'Aashirvaad Shudh Chakki Atta',
    brand: 'Aashirvaad',
    packSize: '5 kg',
    quantity: 5,
    unit: 'kg',
    category: 'Grains',
    region: 'India',
    mrpINR: 285,
    multipliers: { blinkit: 0.91, zepto: 0.88, instamart: 0.92, bigbasket: 0.85 },
  },
  {
    id: 'cat-in-rice',
    name: 'Daawat Rozana Super Basmati Rice',
    brand: 'Daawat',
    packSize: '1 kg',
    quantity: 1,
    unit: 'kg',
    category: 'Grains',
    region: 'India',
    mrpINR: 155,
    multipliers: { blinkit: 0.9, zepto: 0.87, instamart: 0.93, bigbasket: 0.83 },
  },
  {
    id: 'cat-in-dal',
    name: 'Tata Sampann Unpolished Toor Dal',
    brand: 'Tata Sampann',
    packSize: '1 kg',
    quantity: 1,
    unit: 'kg',
    category: 'Grains',
    region: 'India',
    mrpINR: 195,
    multipliers: { blinkit: 0.92, zepto: 0.89, instamart: 0.94, bigbasket: 0.86 },
  },
  {
    id: 'cat-in-oats',
    name: 'Quaker Rolled Oats Pouch',
    brand: 'Quaker',
    packSize: '1 kg',
    quantity: 1,
    unit: 'kg',
    category: 'Grains',
    region: 'India',
    mrpINR: 215,
    multipliers: { blinkit: 0.86, zepto: 0.84, instamart: 0.89, bigbasket: 0.81 },
  },
  {
    id: 'cat-in-bread',
    name: 'Harvest Gold 100% Whole Wheat Bread',
    brand: 'Harvest Gold',
    packSize: '400 g',
    quantity: 400,
    unit: 'g',
    category: 'Bakery',
    region: 'India',
    mrpINR: 55,
    multipliers: { blinkit: 0.98, zepto: 0.95, instamart: 0.98, bigbasket: 0.93 },
  },
  {
    id: 'cat-in-banana',
    name: 'Robusta Bananas',
    brand: 'Fresh Fruits',
    packSize: '6 pcs',
    quantity: 6,
    unit: 'pcs',
    category: 'Fruits',
    region: 'India',
    mrpINR: 49,
    multipliers: { blinkit: 0.88, zepto: 0.84, instamart: 0.9, bigbasket: 0.82 },
  },
  {
    id: 'cat-in-peas',
    name: 'Safal Frozen Green Peas',
    brand: 'Safal',
    packSize: '500 g',
    quantity: 500,
    unit: 'g',
    category: 'Vegetables',
    region: 'India',
    mrpINR: 120,
    multipliers: { blinkit: 0.91, zepto: 0.88, instamart: 0.93, bigbasket: 0.85 },
  },
  {
    id: 'cat-in-oil',
    name: 'Fortune Sunlite Refined Sunflower Oil',
    brand: 'Fortune',
    packSize: '1 L pouch',
    quantity: 1,
    unit: 'L',
    category: 'Spices',
    region: 'India',
    mrpINR: 160,
    multipliers: { blinkit: 0.92, zepto: 0.89, instamart: 0.94, bigbasket: 0.87 },
  },

  // Global supermarket staples
  {
    id: 'cat-gl-eggs',
    name: 'Organic Pasture-Raised Eggs',
    brand: 'Vital Farms / Store',
    packSize: '12 count',
    quantity: 12,
    unit: 'pcs',
    category: 'Dairy',
    region: 'Global',
    mrpINR: 450,
    multipliers: { instacart: 0.96, 'amazon-fresh': 0.92, walmart: 0.84, target: 0.89 },
  },
  {
    id: 'cat-gl-milk',
    name: 'Organic Whole Milk',
    brand: 'Horizon / Great Value',
    packSize: '0.5 gal (1.89 L)',
    quantity: 1.9,
    unit: 'L',
    category: 'Dairy',
    region: 'Global',
    mrpINR: 390,
    multipliers: { instacart: 0.97, 'amazon-fresh': 0.91, walmart: 0.83, target: 0.88 },
  },
  {
    id: 'cat-gl-spinach',
    name: 'Organic Baby Spinach Clam-Shell',
    brand: 'Earthbound Farm',
    packSize: '5 oz (142 g)',
    quantity: 142,
    unit: 'g',
    category: 'Vegetables',
    region: 'Global',
    mrpINR: 290,
    multipliers: { instacart: 0.95, 'amazon-fresh': 0.9, walmart: 0.85, target: 0.87 },
  },
  {
    id: 'cat-gl-chicken',
    name: 'Boneless Skinless Chicken Breast',
    brand: 'Perdue / Good & Gather',
    packSize: '1.5 lb (680 g)',
    quantity: 680,
    unit: 'g',
    category: 'Meat and seafood',
    region: 'Global',
    mrpINR: 580,
    multipliers: { instacart: 0.96, 'amazon-fresh': 0.91, walmart: 0.86, target: 0.9 },
  },
  {
    id: 'cat-gl-avocado',
    name: 'Hass Avocados Bag',
    brand: 'Fresh Produce',
    packSize: '4 count',
    quantity: 4,
    unit: 'pcs',
    category: 'Fruits',
    region: 'Global',
    mrpINR: 380,
    multipliers: { instacart: 0.95, 'amazon-fresh': 0.89, walmart: 0.82, target: 0.88 },
  },
  {
    id: 'cat-gl-sourdough',
    name: 'Artisan Sliced Sourdough Bread',
    brand: 'Bakery Fresh',
    packSize: '20 oz loaf',
    quantity: 560,
    unit: 'g',
    category: 'Bakery',
    region: 'Global',
    mrpINR: 340,
    multipliers: { instacart: 0.94, 'amazon-fresh': 0.9, walmart: 0.85, target: 0.89 },
  },
  {
    id: 'cat-gl-yogurt',
    name: 'Greek Strained Plain Yogurt',
    brand: 'Chobani / Fage',
    packSize: '32 oz tub',
    quantity: 900,
    unit: 'g',
    category: 'Dairy',
    region: 'Global',
    mrpINR: 460,
    multipliers: { instacart: 0.95, 'amazon-fresh': 0.9, walmart: 0.86, target: 0.88 },
  },
  {
    id: 'cat-gl-rice',
    name: 'Aged Jasmine & Basmati Rice',
    brand: 'Royal / Mahatma',
    packSize: '2 lb bag',
    quantity: 900,
    unit: 'g',
    category: 'Grains',
    region: 'Global',
    mrpINR: 330,
    multipliers: { instacart: 0.94, 'amazon-fresh': 0.89, walmart: 0.82, target: 0.87 },
  },
];

// Deterministic realistic sample price matrix keyed by normalized item keywords
const SAMPLE_CATALOG: Record<
  string,
  {
    brand: string;
    packSize: string;
    alternative: string;
    mrpINR: number;
    multipliers: Record<string, number>;
  }
> = {
  rice: {
    brand: 'Daawat / Royal',
    packSize: '1 kg',
    alternative: 'Daily Value Basmati 1 kg',
    mrpINR: 165,
    multipliers: { blinkit: 0.94, zepto: 0.91, instamart: 0.96, bigbasket: 0.84, instacart: 0.95, 'amazon-fresh': 0.9, walmart: 0.86, target: 0.9 },
  },
  eggs: {
    brand: 'Farm Fresh Brown',
    packSize: '12 pcs',
    alternative: 'Cage-Free White Eggs 12 pcs',
    mrpINR: 120,
    multipliers: { blinkit: 0.9, zepto: 0.88, instamart: 0.93, bigbasket: 0.85, instacart: 0.98, 'amazon-fresh': 0.92, walmart: 0.87, target: 0.88 },
  },
  tomato: {
    brand: 'Fresh Hybrid Produce',
    packSize: '500 g',
    alternative: 'Vine Ripened Tomatoes 500 g',
    mrpINR: 48,
    multipliers: { blinkit: 0.88, zepto: 0.82, instamart: 0.9, bigbasket: 0.78, instacart: 0.95, 'amazon-fresh': 0.9, walmart: 0.84, target: 0.86 },
  },
  onion: {
    brand: 'Nashik Red Grade A',
    packSize: '1 kg',
    alternative: 'Organic Red Onions 1 kg',
    mrpINR: 62,
    multipliers: { blinkit: 0.92, zepto: 0.85, instamart: 0.89, bigbasket: 0.81, instacart: 0.94, 'amazon-fresh': 0.89, walmart: 0.83, target: 0.86 },
  },
  milk: {
    brand: 'Amul / Organic Valley',
    packSize: '1 L',
    alternative: 'Toned Fresh Milk 1 L',
    mrpINR: 72,
    multipliers: { blinkit: 0.97, zepto: 0.94, instamart: 0.98, bigbasket: 0.92, instacart: 0.96, 'amazon-fresh': 0.93, walmart: 0.88, target: 0.9 },
  },
  avocado: {
    brand: 'Imported Hass',
    packSize: '1 pc (~200g)',
    alternative: 'Indian Coorg Avocado 1 pc',
    mrpINR: 145,
    multipliers: { blinkit: 0.86, zepto: 0.81, instamart: 0.92, bigbasket: 0.89, instacart: 0.94, 'amazon-fresh': 0.88, walmart: 0.82, target: 0.85 },
  },
  quinoa: {
    brand: 'True Elements',
    packSize: '500 g',
    alternative: 'Organic White Quinoa 500 g',
    mrpINR: 240,
    multipliers: { blinkit: 0.92, zepto: 0.95, instamart: 0.88, bigbasket: 0.79, instacart: 0.93, 'amazon-fresh': 0.87, walmart: 0.85, target: 0.9 },
  },
  paneer: {
    brand: 'Amul Fresh Malai',
    packSize: '200 g',
    alternative: 'Mother Dairy Malai Paneer 200 g',
    mrpINR: 95,
    multipliers: { blinkit: 0.95, zepto: 0.92, instamart: 0.96, bigbasket: 0.9, instacart: 0.95, 'amazon-fresh': 0.91, walmart: 0.89, target: 0.92 },
  },
  feta: {
    brand: 'Dlecta / Dodoni',
    packSize: '150 g',
    alternative: 'Paneer Crumbles 200 g (Local swap)',
    mrpINR: 220,
    multipliers: { blinkit: 0.91, zepto: 0.89, instamart: 0.95, bigbasket: 0.86, instacart: 0.94, 'amazon-fresh': 0.9, walmart: 0.88, target: 0.92 },
  },
  tofu: {
    brand: 'Murginns Soy Tofu',
    packSize: '200 g',
    alternative: 'Organic Extra-Firm Tofu 200 g',
    mrpINR: 110,
    multipliers: { blinkit: 0.88, zepto: 0.84, instamart: 0.91, bigbasket: 0.82, instacart: 0.95, 'amazon-fresh': 0.89, walmart: 0.84, target: 0.86 },
  },
  chicken: {
    brand: 'Licious / FreshCut',
    packSize: '500 g',
    alternative: 'Skinless Boneless Thighs 500 g',
    mrpINR: 260,
    multipliers: { blinkit: 0.93, zepto: 0.89, instamart: 0.87, bigbasket: 0.91, instacart: 0.96, 'amazon-fresh': 0.92, walmart: 0.86, target: 0.89 },
  },
  oats: {
    brand: 'Quaker / Saffola',
    packSize: '500 g',
    alternative: 'Steel Cut Oats 500 g',
    mrpINR: 130,
    multipliers: { blinkit: 0.88, zepto: 0.85, instamart: 0.91, bigbasket: 0.82, instacart: 0.94, 'amazon-fresh': 0.9, walmart: 0.84, target: 0.88 },
  },
  spinach: {
    brand: 'Fresh Greens',
    packSize: '250 g',
    alternative: 'Organic Baby Spinach 200 g',
    mrpINR: 42,
    multipliers: { blinkit: 0.88, zepto: 0.84, instamart: 0.91, bigbasket: 0.8, instacart: 0.95, 'amazon-fresh': 0.9, walmart: 0.84, target: 0.88 },
  },
  bread: {
    brand: 'Harvest Gold / English Oven',
    packSize: '400 g',
    alternative: 'Multigrain Whole Wheat Loaf',
    mrpINR: 55,
    multipliers: { blinkit: 0.96, zepto: 0.93, instamart: 0.97, bigbasket: 0.91, instacart: 0.94, 'amazon-fresh': 0.9, walmart: 0.85, target: 0.89 },
  },
  cheese: {
    brand: 'Amul / Britannia',
    packSize: '200 g',
    alternative: 'Mozzarella & Cheddar Shreds',
    mrpINR: 145,
    multipliers: { blinkit: 0.93, zepto: 0.9, instamart: 0.95, bigbasket: 0.88, instacart: 0.94, 'amazon-fresh': 0.89, walmart: 0.84, target: 0.88 },
  },
  pasta: {
    brand: 'Borges / Barilla',
    packSize: '500 g',
    alternative: 'Whole Wheat Durum Pasta 500 g',
    mrpINR: 175,
    multipliers: { blinkit: 0.89, zepto: 0.86, instamart: 0.92, bigbasket: 0.84, instacart: 0.95, 'amazon-fresh': 0.9, walmart: 0.83, target: 0.88 },
  },
};

function hashItemPlatform(name: string, platformId: string): number {
  let hash = 0;
  const str = `${name.toLowerCase()}:${platformId}`;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) % 997;
  }
  return hash;
}

export function getPlatformsForRegion(country: string): GroceryPlatformConfig[] {
  return country.toLowerCase() === 'india' ? INDIA_PLATFORMS : GLOBAL_PLATFORMS;
}

export function generateProductComparisons(
  items: GroceryItem[],
  platforms: GroceryPlatformConfig[]
): ProductComparisonRow[] {
  return items.map((item) => {
    const lower = item.name.toLowerCase();
    const matchedKey = Object.keys(SAMPLE_CATALOG).find((k) => lower.includes(k));
    const entry = matchedKey ? SAMPLE_CATALOG[matchedKey] : null;
    const baseMrp = entry ? entry.mrpINR : Math.max(40, item.estimatedCostINR * 1.12);

    const offers: PlatformProductOffer[] = platforms.map((platform) => {
      const hash = hashItemPlatform(item.name, platform.id);
      const mult = entry?.multipliers[platform.id] ?? 0.82 + (hash % 18) / 100;
      const priceINR = Math.max(15, Math.round(baseMrp * mult));
      const mrpINR = Math.max(priceINR, Math.round(baseMrp));
      const discountPct = mrpINR > priceINR ? Math.round(((mrpINR - priceINR) / mrpINR) * 100) : 0;
      const inStock = hash % 19 !== 0;

      return {
        platformId: platform.id,
        platformName: platform.name,
        productName: item.name,
        brand: entry ? entry.brand : 'House Select',
        packSize: entry ? entry.packSize : `${item.quantity} ${item.unit}`,
        equivalentUnits: 1,
        mrpINR,
        priceINR,
        discountPct,
        inStock,
        searchUrl: platform.buildSearchUrl(item.name),
        dataSource: entry ? 'sample' : 'estimated',
      };
    });

    const available = offers.filter((o) => o.inStock);
    const sorted = [...available].sort((a, b) => a.priceINR - b.priceINR);
    const cheapestOffer = sorted[0] ?? null;
    const highestPrice = sorted.length > 0 ? sorted[sorted.length - 1].priceINR : 0;

    return {
      groceryItem: item,
      offers,
      cheapestOffer,
      savingsVsHighestINR: cheapestOffer ? Math.max(0, highestPrice - cheapestOffer.priceINR) : 0,
      alternativeProduct: entry?.alternative,
    };
  });
}

export function computeCompleteBaskets(
  comparisons: ProductComparisonRow[],
  platforms: GroceryPlatformConfig[]
): CompleteBasketSummary[] {
  const summaries: CompleteBasketSummary[] = platforms.map((platform) => {
    let itemsSubtotalINR = 0;
    let unavailableCount = 0;
    let hasEstimated = false;

    for (const row of comparisons) {
      const offer = row.offers.find((o) => o.platformId === platform.id);
      if (!offer || !offer.inStock) {
        unavailableCount++;
      } else {
        itemsSubtotalINR += offer.priceINR;
        if (offer.dataSource === 'estimated') hasEstimated = true;
      }
    }

    const deliveryFeeINR =
      itemsSubtotalINR === 0 || itemsSubtotalINR >= platform.freeDeliveryMinOrderINR
        ? 0
        : platform.baseDeliveryFeeINR;
    const handlingFeeINR = itemsSubtotalINR === 0 ? 0 : platform.handlingFeeINR;
    const minOrderTopUpNeededINR =
      itemsSubtotalINR > 0 && itemsSubtotalINR < platform.minOrderINR
        ? platform.minOrderINR - itemsSubtotalINR
        : 0;
    const totalPayableINR = itemsSubtotalINR + deliveryFeeINR + handlingFeeINR;

    return {
      platform,
      itemsSubtotalINR,
      deliveryFeeINR,
      handlingFeeINR,
      minOrderTopUpNeededINR,
      totalPayableINR,
      unavailableCount,
      isCheapest: false,
      dataSource: hasEstimated ? 'estimated' : 'sample',
    };
  });

  const valid = summaries
    .filter((s) => s.itemsSubtotalINR > 0)
    .sort((a, b) => a.unavailableCount - b.unavailableCount || a.totalPayableINR - b.totalPayableINR);
  if (valid[0]) {
    valid[0].isCheapest = true;
  }
  return summaries.sort((a, b) => a.totalPayableINR - b.totalPayableINR);
}

export function computeSmartSplitShopping(
  comparisons: ProductComparisonRow[],
  platforms: GroceryPlatformConfig[],
  baskets: CompleteBasketSummary[]
): SmartSplitPlan | null {
  if (comparisons.length === 0 || baskets.length === 0) return null;
  const singleBest = [...baskets].sort((a, b) => a.totalPayableINR - b.totalPayableINR)[0];

  const bucketMap = new Map<
    string,
    { platform: GroceryPlatformConfig; items: { item: GroceryItem; offer: PlatformProductOffer }[] }
  >();

  for (const row of comparisons) {
    if (!row.cheapestOffer) continue;
    const plat = platforms.find((p) => p.id === row.cheapestOffer!.platformId);
    if (!plat) continue;
    const current = bucketMap.get(plat.id) ?? { platform: plat, items: [] };
    current.items.push({ item: row.groceryItem, offer: row.cheapestOffer });
    bucketMap.set(plat.id, current);
  }

  let entries = Array.from(bucketMap.values()).sort((a, b) => b.items.length - a.items.length);
  if (entries.length > 2) {
    const primary = entries.slice(0, 2);
    const overflow = entries.slice(2).flatMap((e) => e.items);
    for (const extra of overflow) {
      const row = comparisons.find((c) => c.groceryItem.id === extra.item.id);
      const o0 = row?.offers.find((o) => o.platformId === primary[0].platform.id && o.inStock);
      const o1 = row?.offers.find((o) => o.platformId === primary[1].platform.id && o.inStock);
      if (o0 && (!o1 || o0.priceINR <= o1.priceINR)) {
        primary[0].items.push({ item: extra.item, offer: o0 });
      } else if (o1) {
        primary[1].items.push({ item: extra.item, offer: o1 });
      }
    }
    entries = primary;
  }

  const splitPlatforms = entries.map((entry) => {
    const subtotalINR = entry.items.reduce((acc, x) => acc + x.offer.priceINR, 0);
    const deliveryFeeINR =
      subtotalINR >= entry.platform.freeDeliveryMinOrderINR ? 0 : entry.platform.baseDeliveryFeeINR;
    const handlingFeeINR = entry.platform.handlingFeeINR;
    return {
      platform: entry.platform,
      items: entry.items,
      subtotalINR,
      deliveryFeeINR,
      handlingFeeINR,
      totalINR: subtotalINR + deliveryFeeINR + handlingFeeINR,
    };
  });

  const splitGrandTotalINR = splitPlatforms.reduce((acc, p) => acc + p.totalINR, 0);
  const netSavingsAfterFeesINR = singleBest.totalPayableINR - splitGrandTotalINR;
  const recommended = splitPlatforms.length > 1 && netSavingsAfterFeesINR > 0;

  return {
    recommended,
    singleBestPlatform: singleBest,
    splitPlatforms,
    splitGrandTotalINR,
    netSavingsAfterFeesINR,
    reason: recommended
      ? `Splitting across ${splitPlatforms.map((s) => s.platform.name).join(' & ')} saves net money even after factoring delivery & handling fees.`
      : `Ordering the complete basket from ${singleBest.platform.name} is more economical once extra delivery fees are included.`,
  };
}
