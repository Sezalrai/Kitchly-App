import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  increment,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Unsubscribe,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { IMAGES } from '../data/recipes';
import { CommunityRecipePost, CreatorProfile, DietType, RecipeIngredient } from '../types/kitchly';
import { sanitizeId } from './firestoreSync';

export const STARTER_COMMUNITY_CREATORS: CreatorProfile[] = [
  {
    uid: 'demo-creator-pema',
    displayName: 'Pema Sherpa',
    bio: 'Home dumpling maker sharing mountain comfort food, momo folding tricks, and fiery chutneys.',
    specialty: 'Himalayan Momos & Noodles',
    country: 'India',
    followersCount: 148,
    postsCount: 2,
    isPublic: true,
    isDemoCreator: true,
  },
  {
    uid: 'demo-creator-meera',
    displayName: 'Meera Iyer',
    bio: 'Weekday 20-minute tiffins, fermented batters, and budget-smart South Indian cooking.',
    specialty: 'Quick Tiffins & Bowls',
    country: 'India',
    followersCount: 94,
    postsCount: 1,
    isPublic: true,
    isDemoCreator: true,
  },
  {
    uid: 'demo-creator-minjun',
    displayName: 'Min-Jun Park',
    bio: 'Pantry sauces, fermented sides, and cozy noodle soups anyone can master on a weeknight.',
    specialty: 'Korean Home Cooking',
    country: 'United States',
    followersCount: 112,
    postsCount: 1,
    isPublic: true,
    isDemoCreator: true,
  },
];

export const STARTER_COMMUNITY_POSTS: CommunityRecipePost[] = [
  {
    id: 'demo-post-himalayan-momos',
    authorId: 'demo-creator-pema',
    authorName: 'Pema Sherpa',
    authorSpecialty: 'Himalayan Momos & Noodles',
    title: 'Juicy Steamed Veg & Paneer Momos with Spicy Chutney',
    story:
      'I love making momos on weekends! The secret to juicy, restaurant-style momos is squeezing excess water gently from the cabbage (save that water to knead the dough!), adding 1 tbsp warm oil into the filling, and rolling edges thinner than the center before pleating.',
    cuisine: 'Asian',
    dietType: 'Vegetarian',
    difficulty: 'Medium',
    prepTimeMins: 40,
    servings: 4,
    estimatedCostINR: 160,
    image: IMAGES.asian,
    ingredients: [
      { name: 'All-Purpose Flour (Maida)', quantity: 2, unit: 'cups', category: 'Grains' },
      { name: 'Finely Shredded Cabbage', quantity: 250, unit: 'g', category: 'Vegetables' },
      { name: 'Crumbled Paneer', quantity: 150, unit: 'g', category: 'Dairy' },
      { name: 'Spring Onions & Coriander', quantity: 60, unit: 'g', category: 'Vegetables' },
      { name: 'Fresh Ginger & Garlic (Minced)', quantity: 2, unit: 'tbsp', category: 'Spices' },
      { name: 'Soy Sauce & Black Pepper', quantity: 1, unit: 'tbsp', category: 'Spices' },
      { name: 'Ripe Tomatoes & Dried Red Chilies', quantity: 3, unit: 'pcs', category: 'Vegetables' },
    ],
    steps: [
      'Knead flour with a pinch of salt and cool water into a stiff, smooth dough. Cover with a damp cloth and rest for 20 minutes.',
      'Salt shredded cabbage for 5 minutes, then squeeze out extra moisture lightly so the wrappers stay crisp.',
      'Mix cabbage, crumbled paneer, ginger, garlic, spring onions, soy sauce, black pepper, and 1 tbsp warm oil to lock in juiciness.',
      'Divide dough into small marble-sized balls and roll each into a 3.5-inch circle, keeping the center slightly thicker than the edges.',
      'Spoon 1 tbsp filling into the center, lift one edge, and pleat around in small folds to seal into classic crescent or round potli momos.',
      'Grease your steamer plate, arrange momos with space between them, and steam over briskly boiling water for 10–12 minutes until glossy.',
      'Blanch tomatoes and dried chilies, then blend with raw garlic, salt, and lemon juice for classic spicy momo chutney.',
    ],
    tips: [
      'Keep rolled dough balls covered so the edges do not dry out before pleating.',
      'Never over-steam beyond 12 minutes or the wrapper turns chewy.',
    ],
    tags: ['Momos', 'Step-by-Step', 'Weekend Favorite', 'Street Food'],
    likesCount: 86,
    isPublic: true,
    createdAtISO: '2026-11-20T14:30:00.000Z',
    isDemoPost: true,
  },
  {
    id: 'demo-post-jhol-momo',
    authorId: 'demo-creator-pema',
    authorName: 'Pema Sherpa',
    authorSpecialty: 'Himalayan Momos & Noodles',
    title: 'Warm Sesame Tomato Jhol Momo (Soup Dumplings)',
    story:
      'For chilly evenings, pour warm roasted-sesame & tomato jhol broth over freshly steamed momos. You can prepare the jhol in 10 minutes while your momos steam!',
    cuisine: 'Asian',
    dietType: 'Vegan',
    difficulty: 'Easy',
    prepTimeMins: 25,
    servings: 3,
    estimatedCostINR: 130,
    image: IMAGES.thai,
    ingredients: [
      { name: 'Steamed Veg Momos (Fresh or Frozen)', quantity: 18, unit: 'pcs', category: 'Grains' },
      { name: 'Roasted White Sesame Seeds', quantity: 3, unit: 'tbsp', category: 'Spices' },
      { name: 'Tomatoes', quantity: 4, unit: 'pcs', category: 'Vegetables' },
      { name: 'Garlic Cloves & Ginger', quantity: 6, unit: 'pcs', category: 'Spices' },
      { name: 'Fresh Cilantro', quantity: 1, unit: 'bunch', category: 'Vegetables' },
    ],
    steps: [
      'Dry-roast sesame seeds in a pan for 2 minutes until nutty and golden.',
      'Simmer chopped tomatoes, ginger, garlic, and red chili in 1.5 cups water until tomatoes collapse cleanly.',
      'Cool slightly and blend everything with roasted sesame seeds, turmeric, salt, and fresh cilantro into a silky pourable broth.',
      'Pour hot jhol over steamed momos in a deep bowl and finish with chopped scallions and lime.',
    ],
    tips: [
      'A squeeze of fresh lime right before serving brightens the nutty sesame broth.',
    ],
    tags: ['Jhol Momo', 'Vegan', 'Soup Bowl'],
    likesCount: 54,
    isPublic: true,
    createdAtISO: '2026-11-18T11:00:00.000Z',
    isDemoPost: true,
  },
  {
    id: 'demo-post-crispy-poha-cutlet',
    authorId: 'demo-creator-meera',
    authorName: 'Meera Iyer',
    authorSpecialty: 'Quick Tiffins & Bowls',
    title: 'Budget-Friendly Poha & Herb Crispy Tikkis',
    story:
      'Costs under ₹70 for the whole family! Rinsed poha binds boiled potatoes and leftover veggies without needing breadcrumbs or deep frying.',
    cuisine: 'Indian',
    dietType: 'Vegan',
    difficulty: 'Easy',
    prepTimeMins: 20,
    servings: 4,
    estimatedCostINR: 70,
    image: IMAGES.indian,
    ingredients: [
      { name: 'Thick Poha (Flattened Rice)', quantity: 1, unit: 'cup', category: 'Grains' },
      { name: 'Boiled Potatoes', quantity: 2, unit: 'pcs', category: 'Vegetables' },
      { name: 'Green Peas & Grated Carrot', quantity: 100, unit: 'g', category: 'Vegetables' },
      { name: 'Chaat Masala & Roasted Cumin', quantity: 1, unit: 'tsp', category: 'Spices' },
    ],
    steps: [
      'Rinse poha twice in a strainer and let soften for 5 minutes until crumbly.',
      'Mash boiled potatoes with softened poha, veggies, cumin, chaat masala, green chili, and salt.',
      'Shape into flat patties and pan-sear on a tawa with 1 tsp oil per side until crisp golden.',
    ],
    tips: ['Do not soak poha in standing water—rinsing in a colander keeps tikkis super crisp.'],
    tags: ['Budget-friendly', 'Vegan', 'Quick'],
    likesCount: 63,
    isPublic: true,
    createdAtISO: '2026-11-17T08:45:00.000Z',
    isDemoPost: true,
  },
  {
    id: 'demo-post-kimchi-udon',
    authorId: 'demo-creator-minjun',
    authorName: 'Min-Jun Park',
    authorSpecialty: 'Korean Home Cooking',
    title: '15-Minute Creamy Gochujang Garlic Noodles',
    story:
      'One pan, zero hassle, big savory-spicy flavor. Great way to use half a jar of kimchi and spring onions from the fridge.',
    cuisine: 'Korean',
    dietType: 'Vegetarian',
    difficulty: 'Easy',
    prepTimeMins: 15,
    servings: 2,
    estimatedCostINR: 150,
    image: IMAGES.italian,
    ingredients: [
      { name: 'Wheat or Udon Noodles', quantity: 200, unit: 'g', category: 'Grains' },
      { name: 'Gochujang (or Chili Garlic Paste)', quantity: 1.5, unit: 'tbsp', category: 'Spices' },
      { name: 'Garlic Cloves', quantity: 4, unit: 'pcs', category: 'Spices' },
      { name: 'Soy Sauce & Sesame Oil', quantity: 1, unit: 'tbsp', category: 'Spices' },
      { name: 'Scallions & Spinach', quantity: 100, unit: 'g', category: 'Vegetables' },
    ],
    steps: [
      'Boil noodles until tender, saving ½ cup starchy cooking water before draining.',
      'Sauté sliced garlic and scallion whites in sesame oil for 45 seconds until fragrant.',
      'Whisk in gochujang, soy sauce, and noodle water to form a glossy glaze.',
      'Toss noodles and spinach for 1 minute until coated cleanly, then top with toasted sesame.',
    ],
    tips: ['Starchy pasta/noodle water emulsifies chili paste into a silky restaurant glaze without cream.'],
    tags: ['15-Min Meal', 'High-flavor', 'Quick'],
    likesCount: 72,
    isPublic: true,
    createdAtISO: '2026-11-15T18:20:00.000Z',
    isDemoPost: true,
  },
];

export interface PublishPostInput {
  title: string;
  story: string;
  cuisine: string;
  dietType: DietType;
  difficulty: 'Easy' | 'Medium' | 'Chef';
  prepTimeMins: number;
  servings: number;
  estimatedCostINR: number;
  image: string;
  ingredients: RecipeIngredient[];
  steps: string[];
  tips: string[];
  tags: string[];
}

export interface CommunityFeedCallbacks {
  onCreators: (creators: CreatorProfile[]) => void;
  onPosts: (posts: CommunityRecipePost[]) => void;
  onLikedIds: (likedPostIds: string[]) => void;
  onFollowedCreatorIds: (creatorIds: string[]) => void;
}

export function subscribeCommunityFeed(
  uid: string,
  callbacks: CommunityFeedCallbacks
): Unsubscribe {
  const unsubs: Unsubscribe[] = [];

  unsubs.push(
    onSnapshot(
      query(collection(db, 'creators'), where('isPublic', '==', true)),
      (snap) => {
        const list: CreatorProfile[] = snap.docs.map((d) => {
          const v = d.data();
          return {
            uid: String(v.uid || d.id),
            displayName: String(v.displayName || 'Home Cook'),
            bio: String(v.bio || ''),
            specialty: String(v.specialty || ''),
            country: String(v.country || 'India'),
            followersCount: Math.max(0, Number(v.followersCount) || 0),
            postsCount: Math.max(0, Number(v.postsCount) || 0),
            isPublic: Boolean(v.isPublic),
          };
        });
        callbacks.onCreators(list);
      },
      (err) => console.warn('Community creators listener warning:', err)
    )
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'communityRecipes'), where('isPublic', '==', true)),
      (snap) => {
        const list: CommunityRecipePost[] = snap.docs.map((d) => {
          const v = d.data();
          const ts = v.createdAt as { toDate?: () => Date } | undefined;
          return {
            id: d.id,
            authorId: String(v.authorId || ''),
            authorName: String(v.authorName || 'Home Cook'),
            authorSpecialty: String(v.authorSpecialty || ''),
            title: String(v.title || 'Shared Recipe'),
            story: String(v.story || ''),
            cuisine: String(v.cuisine || 'Indian'),
            dietType: (v.dietType || 'Vegetarian') as DietType,
            difficulty: (['Easy', 'Medium', 'Chef'].includes(String(v.difficulty)) ? v.difficulty : 'Easy') as 'Easy' | 'Medium' | 'Chef',
            prepTimeMins: Math.max(1, Number(v.prepTimeMins) || 20),
            servings: Math.max(1, Number(v.servings) || 2),
            estimatedCostINR: Math.max(0, Number(v.estimatedCostINR) || 100),
            image: String(v.image || IMAGES.indian),
            ingredients: Array.isArray(v.ingredients) ? v.ingredients : [],
            steps: Array.isArray(v.steps) ? v.steps.map(String) : [],
            tips: Array.isArray(v.tips) ? v.tips.map(String) : [],
            tags: Array.isArray(v.tags) ? v.tags.map(String) : [],
            likesCount: Math.max(0, Number(v.likesCount) || 0),
            isPublic: Boolean(v.isPublic),
            createdAtISO: ts?.toDate ? ts.toDate().toISOString() : new Date().toISOString(),
          };
        });
        callbacks.onPosts(list);
      },
      (err) => console.warn('Community recipes listener warning:', err)
    )
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'postLikes'), where('userId', '==', uid)),
      (snap) => {
        const ids = snap.docs.map((d) => String(d.data().postId || '')).filter(Boolean);
        callbacks.onLikedIds(ids);
      },
      (err) => console.warn('Post likes listener warning:', err)
    )
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'creatorFollows'), where('followerId', '==', uid)),
      (snap) => {
        const ids = snap.docs.map((d) => String(d.data().creatorId || '')).filter(Boolean);
        callbacks.onFollowedCreatorIds(ids);
      },
      (err) => console.warn('Creator follows listener warning:', err)
    )
  );

  return () => unsubs.forEach((u) => u());
}

export async function ensureCreatorProfileFS(
  uid: string,
  profile: { displayName: string; specialty: string; bio: string; country: string }
): Promise<void> {
  const safeUid = sanitizeId(uid);
  const path = `creators/${safeUid}`;
  try {
    const ref = doc(db, 'creators', safeUid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        uid: safeUid,
        displayName: (profile.displayName || 'Home Cook').trim().slice(0, 80),
        bio: (profile.bio || 'Sharing favorite home-cooked recipes and kitchen steps.').trim().slice(0, 280),
        specialty: (profile.specialty || 'Home Favorites').trim().slice(0, 80),
        country: (profile.country || 'India').trim().slice(0, 60),
        followersCount: 0,
        postsCount: 0,
        isPublic: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function updateCreatorProfileFS(
  uid: string,
  profile: { displayName: string; specialty: string; bio: string; country: string }
): Promise<void> {
  const safeUid = sanitizeId(uid);
  const path = `creators/${safeUid}`;
  try {
    const ref = doc(db, 'creators', safeUid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await ensureCreatorProfileFS(safeUid, profile);
      return;
    }
    await updateDoc(ref, {
      displayName: (profile.displayName || 'Home Cook').trim().slice(0, 80),
      bio: profile.bio.trim().slice(0, 280),
      specialty: profile.specialty.trim().slice(0, 80),
      country: (profile.country || 'India').trim().slice(0, 60),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function publishCommunityPostFS(
  uid: string,
  author: { displayName: string; specialty: string; bio: string; country: string },
  draft: PublishPostInput
): Promise<string> {
  const safeUid = sanitizeId(uid);
  const postId = sanitizeId(`post-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`);
  const postPath = `communityRecipes/${postId}`;

  await ensureCreatorProfileFS(safeUid, author);

  const cleanIngredients = draft.ingredients
    .filter((i) => i.name.trim())
    .slice(0, 35)
    .map((i) => ({
      name: i.name.trim().slice(0, 100),
      quantity: Math.max(0.1, Number(i.quantity) || 1),
      unit: (i.unit || 'pc').trim().slice(0, 25),
      category: i.category || 'Vegetables',
    }));

  const cleanSteps = draft.steps
    .map((s) => s.trim().slice(0, 400))
    .filter(Boolean)
    .slice(0, 25);

  const cleanTips = draft.tips
    .map((t) => t.trim().slice(0, 240))
    .filter(Boolean)
    .slice(0, 10);

  const cleanTags = draft.tags
    .map((t) => t.trim().slice(0, 40))
    .filter(Boolean)
    .slice(0, 12);

  try {
    const batch = writeBatch(db);
    const postRef = doc(db, 'communityRecipes', postId);
    const creatorRef = doc(db, 'creators', safeUid);

    batch.set(postRef, {
      authorId: safeUid,
      authorName: (author.displayName || 'Home Cook').trim().slice(0, 80),
      authorSpecialty: (author.specialty || 'Home Favorites').trim().slice(0, 80),
      title: draft.title.trim().slice(0, 140),
      story: draft.story.trim().slice(0, 600),
      cuisine: draft.cuisine.trim().slice(0, 50) || 'Indian',
      dietType: draft.dietType,
      difficulty: draft.difficulty,
      prepTimeMins: Math.max(1, Math.min(360, Number(draft.prepTimeMins) || 25)),
      servings: Math.max(1, Math.min(30, Number(draft.servings) || 2)),
      estimatedCostINR: Math.max(0, Number(draft.estimatedCostINR) || 120),
      image: (() => {
        const raw = (draft.image || IMAGES.asian).trim();
        if (raw.startsWith('data:image/')) {
          return raw.length <= 280000 ? raw : IMAGES.asian;
        }
        if (raw.startsWith('http://') || raw.startsWith('https://') || raw.startsWith('/')) {
          return raw.slice(0, 500);
        }
        return IMAGES.asian;
      })(),
      ingredients: cleanIngredients.length > 0 ? cleanIngredients : [{ name: 'Main Ingredient', quantity: 1, unit: 'cup', category: 'Vegetables' }],
      steps: cleanSteps.length > 0 ? cleanSteps : ['Prepare ingredients and cook to taste.'],
      tips: cleanTips,
      tags: cleanTags,
      likesCount: 0,
      isPublic: true,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.update(creatorRef, {
      postsCount: increment(1),
      updatedAt: serverTimestamp(),
    });

    await batch.commit();
    return postId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, postPath);
  }
}

export async function deleteCommunityPostFS(uid: string, postId: string): Promise<void> {
  const safeUid = sanitizeId(uid);
  const safePostId = sanitizeId(postId);
  try {
    await deleteDoc(doc(db, 'communityRecipes', safePostId));
    const creatorRef = doc(db, 'creators', safeUid);
    const snap = await getDoc(creatorRef);
    if (snap.exists()) {
      const current = Math.max(0, Number(snap.data()?.postsCount) || 0);
      await updateDoc(creatorRef, {
        postsCount: Math.max(0, current - 1),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `communityRecipes/${safePostId}`);
  }
}

export async function togglePostLikeFS(postId: string, uid: string, currentlyLiked: boolean): Promise<void> {
  const safePostId = sanitizeId(postId);
  const safeUid = sanitizeId(uid);
  const likeId = `${safePostId}__${safeUid}`;
  const path = `postLikes/${likeId}`;

  try {
    const batch = writeBatch(db);
    const likeRef = doc(db, 'postLikes', likeId);
    const postRef = doc(db, 'communityRecipes', safePostId);

    if (currentlyLiked) {
      batch.delete(likeRef);
      batch.update(postRef, {
        likesCount: increment(-1),
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.set(likeRef, {
        userId: safeUid,
        postId: safePostId,
        createdAt: serverTimestamp(),
      });
      batch.update(postRef, {
        likesCount: increment(1),
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function toggleCreatorFollowFS(
  creatorId: string,
  followerUid: string,
  followerName: string,
  currentlyFollowing: boolean
): Promise<void> {
  const safeCreatorId = sanitizeId(creatorId);
  const safeFollowerId = sanitizeId(followerUid);
  if (safeCreatorId === safeFollowerId) return;

  const followId = `${safeCreatorId}__${safeFollowerId}`;
  const path = `creatorFollows/${followId}`;

  try {
    const batch = writeBatch(db);
    const followRef = doc(db, 'creatorFollows', followId);
    const creatorRef = doc(db, 'creators', safeCreatorId);

    if (currentlyFollowing) {
      batch.delete(followRef);
      batch.update(creatorRef, {
        followersCount: increment(-1),
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.set(followRef, {
        followerId: safeFollowerId,
        creatorId: safeCreatorId,
        followerName: (followerName || 'Kitchen Cook').trim().slice(0, 80),
        createdAt: serverTimestamp(),
      });
      batch.update(creatorRef, {
        followersCount: increment(1),
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}
