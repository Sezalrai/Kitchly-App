export async function postJson<T = Record<string, any>>(
  url: string,
  body: unknown,
  signal?: AbortSignal
): Promise<T> {
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    signal,
    body: JSON.stringify(body),
  });

  const rawText = await resp.text();
  const trimmed = rawText.trim();

  if (!trimmed) {
    if (!resp.ok) {
      throw new Error(`Request failed (${resp.status}). Please try again.`);
    }
    return {} as T;
  }

  // Guard against HTML gateway pages or SPA fallbacks returning <!doctype html>
  if (trimmed.startsWith('<') || trimmed.toLowerCase().startsWith('<!doctype')) {
    throw new Error('Kitchly AI could not be reached right now due to a temporary connection hiccup.');
  }

  let parsed: Record<string, any>;
  try {
    parsed = JSON.parse(trimmed) as Record<string, any>;
  } catch {
    throw new Error('Received an unexpected response from the server. Please try again.');
  }

  if (!resp.ok) {
    throw new Error(
      typeof parsed.error === 'string' && parsed.error
        ? parsed.error
        : `Request failed (${resp.status}). Please try again.`
    );
  }

  return parsed as T;
}
