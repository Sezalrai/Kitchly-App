import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  ChefHat,
  Clock,
  Heart,
  Loader2,
  Plus,
  Search,
  ShoppingCart,
  SlidersHorizontal,
  Sparkles,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { formatCurrency } from '../i18n/translations';
import { postJson } from '../services/apiClient';
import { CuisineType, DietType, Recipe } from '../types/kitchly';
import { FoodImage } from '../components/Logo';
import { isNationalIndianCuisine } from '../data/recipes';

const ALL_CUISINES: ('All' | CuisineType)[] = [
  'All', 'Indian', 'Italian', 'Continental', 'Chinese', 'Korean', 'Japanese',
  'Mexican', 'Mediterranean', 'Thai', 'American', 'French', 'Middle Eastern', 'Turkish', 'Spanish',
];
const INTERNATIONAL_ONLY_CUISINES: CuisineType[] = [
  'Italian', 'Continental', 'Chinese', 'Korean', 'Japanese',
  'Mexican', 'Mediterranean', 'Thai', 'American', 'French', 'Middle Eastern', 'Turkish', 'Spanish',
];

export function WeeklyMealPlannerScreen() {
  const {
    state,
    allRecipes,
    updateWeeklySlot,
    autoFillWeeklyPlan,
    openRecipe,
    generateGroceryFromWeeklyPlan,
    assignRecipeToCookMode,
    showToast,
    setScreen,
  } = useKitchly();

  const [searchQuery, setSearchQuery] = useState('');
  const [dayFilter, setDayFilter] = useState<'All' | 'Weekdays' | 'Weekend' | string>('All');
  const [slotFilter, setSlotFilter] = useState<'All' | 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack'>('All');
  const [dietFilter, setDietFilter] = useState<'All' | DietType>('All');
  const [cuisineFilter, setCuisineFilter] = useState<'All' | CuisineType>('All');
  const [maxPrepMins, setMaxPrepMins] = useState<number>(0); // 0 = any
  const [sortBy, setSortBy] = useState<
    'day-order' | 'cost-asc' | 'cost-desc' | 'cal-asc' | 'prep-asc' | 'title-asc'
  >('day-order');
  const [filterPickersOnly, setFilterPickersOnly] = useState(false);

  const recipeMap = useMemo(() => new Map(allRecipes.map((r) => [r.id, r])), [allRecipes]);

  const weeklyCostINR = state.weeklyPlan.reduce((sum, day) => {
    const ids = [day.breakfastId, day.lunchId, day.dinnerId, day.snackId];
    return sum + ids.reduce((dSum, id) => dSum + (recipeMap.get(id)?.estimatedCostINR || 0), 0);
  }, 0);

  const recipeMatchesFilters = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return (r: Recipe) => {
      if (dietFilter !== 'All' && r.dietType !== dietFilter) return false;
      if (cuisineFilter !== 'All' && r.cuisine.toLowerCase() !== cuisineFilter.toLowerCase()) return false;
      if (maxPrepMins > 0 && r.prepTimeMins > maxPrepMins) return false;
      if (q) {
        const hay = `${r.title} ${r.cuisine} ${r.dietType} ${r.ingredients.map((i) => i.name).join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    };
  }, [dietFilter, cuisineFilter, maxPrepMins, searchQuery]);

  const sortedFilteredPickerRecipes = useMemo(() => {
    const base = allRecipes.filter(recipeMatchesFilters);
    return [...base].sort((a, b) => {
      switch (sortBy) {
        case 'cost-asc':
          return a.estimatedCostINR - b.estimatedCostINR;
        case 'cost-desc':
          return b.estimatedCostINR - a.estimatedCostINR;
        case 'cal-asc':
          return a.nutrition.calories - b.nutrition.calories;
        case 'prep-asc':
          return a.prepTimeMins - b.prepTimeMins;
        case 'title-asc':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });
  }, [allRecipes, recipeMatchesFilters, sortBy]);

  const visibleDays = useMemo(() => {
    const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const weekend = ['Saturday', 'Sunday'];
    const hasRecipeSpecificFilter =
      searchQuery.trim() !== '' || dietFilter !== 'All' || cuisineFilter !== 'All' || maxPrepMins > 0;

    const getDayMetrics = (day: (typeof state.weeklyPlan)[number]) => {
      const ids =
        slotFilter === 'Breakfast'
          ? [day.breakfastId]
          : slotFilter === 'Lunch'
          ? [day.lunchId]
          : slotFilter === 'Dinner'
          ? [day.dinnerId]
          : slotFilter === 'Snack'
          ? [day.snackId]
          : [day.breakfastId, day.lunchId, day.dinnerId, day.snackId];

      const recipes = ids.map((id) => recipeMap.get(id)).filter((r): r is Recipe => Boolean(r));
      const dayCost = recipes.reduce((s, r) => s + r.estimatedCostINR, 0);
      const dayCalories = recipes.reduce((s, r) => s + r.nutrition.calories, 0);
      const dayPrep = recipes.reduce((s, r) => s + r.prepTimeMins, 0);
      return { recipes, dayCost, dayCalories, dayPrep };
    };

    const enriched = state.weeklyPlan
      .filter((day) => {
        if (dayFilter === 'Weekdays' && !weekdays.includes(day.day)) return false;
        if (dayFilter === 'Weekend' && !weekend.includes(day.day)) return false;
        if (!['All', 'Weekdays', 'Weekend'].includes(dayFilter) && day.day !== dayFilter) return false;
        if (!filterPickersOnly && hasRecipeSpecificFilter) {
          const { recipes } = getDayMetrics(day);
          if (recipes.length > 0 && !recipes.some(recipeMatchesFilters)) {
            return false;
          }
        }
        return true;
      })
      .map((day) => ({ day, ...getDayMetrics(day) }));

    if (sortBy === 'day-order' || sortBy === 'title-asc') return enriched;

    return [...enriched].sort((a, b) => {
      switch (sortBy) {
        case 'cost-asc':
          return a.dayCost - b.dayCost;
        case 'cost-desc':
          return b.dayCost - a.dayCost;
        case 'cal-asc':
          return a.dayCalories - b.dayCalories;
        case 'prep-asc':
          return a.dayPrep - b.dayPrep;
        default:
          return 0;
      }
    });
  }, [state.weeklyPlan, dayFilter, slotFilter, searchQuery, dietFilter, cuisineFilter, maxPrepMins, sortBy, filterPickersOnly, recipeMap, recipeMatchesFilters]);

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    dayFilter !== 'All' ||
    slotFilter !== 'All' ||
    dietFilter !== 'All' ||
    cuisineFilter !== 'All' ||
    maxPrepMins !== 0 ||
    sortBy !== 'day-order';

  const resetFilters = () => {
    setSearchQuery('');
    setDayFilter('All');
    setSlotFilter('All');
    setDietFilter('All');
    setCuisineFilter('All');
    setMaxPrepMins(0);
    setSortBy('day-order');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">Weekly Meal Planner</h2>
          <p className="text-sm text-[#5B625C] tabular-nums">
            7-day household schedule · Estimated week total:{' '}
            <span className="font-semibold text-[#1F2421]">
              {formatCurrency(weeklyCostINR, state.user.currency)}
            </span>
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => autoFillWeeklyPlan()}
            className="px-4 py-2.5 rounded-xl bg-[#D97736] text-white text-sm font-medium hover:opacity-95 inline-flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>{state.weeklyPlan.length === 0 ? 'Auto-Fill Smart Week' : 'Auto-Fill Week'}</span>
          </button>
          <button
            onClick={() => {
              const hasAnyMeal = state.weeklyPlan.some(
                (d) => Boolean(d.breakfastId || d.lunchId || d.dinnerId || d.snackId)
              );
              if (!hasAnyMeal) {
                showToast('Add at least one meal to your weekly plan (or click Auto-Fill Smart Week) first.');
                return;
              }
              generateGroceryFromWeeklyPlan();
              setScreen('grocery-list');
            }}
            className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A] inline-flex items-center gap-2"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Generate Weekly Grocery List</span>
          </button>
          <button
            onClick={() => {
              const weekdayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
              const todayName = weekdayNames[new Date().getDay()];
              const targetDay =
                state.weeklyPlan.find((d) => d.day === todayName && (d.breakfastId || d.lunchId || d.dinnerId)) ||
                state.weeklyPlan.find((d) => d.breakfastId || d.lunchId || d.dinnerId);
              if (!targetDay) {
                showToast('Assign meals to your weekly plan first before sending to Cook Mode.');
                return;
              }
              const b = recipeMap.get(targetDay.breakfastId);
              const l = recipeMap.get(targetDay.lunchId);
              const d = recipeMap.get(targetDay.dinnerId);
              if (b) assignRecipeToCookMode(b, 'Breakfast');
              if (l) assignRecipeToCookMode(l, 'Lunch');
              if (d) assignRecipeToCookMode(d, 'Dinner');
              setScreen('cook-mode');
            }}
            className="px-4 py-2.5 rounded-xl bg-white border border-[#E6E3DA] text-sm font-medium hover:bg-[#F3F1EA] inline-flex items-center gap-2"
          >
            <ChefHat className="w-4 h-4 text-[#4A7C59]" />
            <span>Send Today to Cook Mode</span>
          </button>
        </div>
      </div>

      {/* Sort & Filter Controls */}
      {state.weeklyPlan.length > 0 && (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-4 space-y-3">
          <div className="grid sm:grid-cols-2 lg:grid-cols-6 gap-3">
            <div className="relative lg:col-span-2">
              <Search className="w-4 h-4 text-[#5B625C] absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                aria-label="Search weekly meals or recipes"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dish, cuisine, ingredient..."
                className="w-full h-10 pl-9 pr-3 rounded-xl border border-[#E6E3DA] text-sm"
              />
            </div>

            <select
              aria-label="Filter days"
              value={dayFilter}
              onChange={(e) => setDayFilter(e.target.value)}
              className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="All">All 7 Days</option>
              <option value="Weekdays">Weekdays (Mon–Fri)</option>
              <option value="Weekend">Weekend (Sat–Sun)</option>
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((d) => (
                <option key={d} value={d}>
                  {d} Only
                </option>
              ))}
            </select>

            <select
              aria-label="Filter meal slot"
              value={slotFilter}
              onChange={(e) => setSlotFilter(e.target.value as typeof slotFilter)}
              className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="All">All Meal Slots</option>
              <option value="Breakfast">Breakfast</option>
              <option value="Lunch">Lunch</option>
              <option value="Dinner">Dinner</option>
              <option value="Snack">Snack</option>
            </select>

            <select
              aria-label="Filter diet type"
              value={dietFilter}
              onChange={(e) => setDietFilter(e.target.value as 'All' | DietType)}
              className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="All">All Diet Types</option>
              <option value="Vegetarian">Vegetarian</option>
              <option value="Vegan">Vegan</option>
              <option value="Eggetarian">Eggetarian</option>
              <option value="Pescatarian">Pescatarian</option>
              <option value="Non-vegetarian">Non-vegetarian</option>
            </select>

            <select
              aria-label="Sort weekly planner"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="day-order">Sort: Day Order (Mon–Sun)</option>
              <option value="cost-asc">Sort: Lowest Cost First</option>
              <option value="cost-desc">Sort: Highest Cost First</option>
              <option value="cal-asc">Sort: Lowest Calories</option>
              <option value="prep-asc">Sort: Quickest Prep Time</option>
              <option value="title-asc">Sort Dish List: A–Z</option>
            </select>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#EFECE3] text-xs text-[#5B625C]">
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-1.5 font-medium text-[#1F2421]">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#4A7C59]" />
                {visibleDays.length} days shown · {sortedFilteredPickerRecipes.length} recipes in pickers
              </span>
              <select
                aria-label="Filter cuisine in pickers"
                value={cuisineFilter}
                onChange={(e) => setCuisineFilter(e.target.value as 'All' | CuisineType)}
                className="h-8 px-2.5 rounded-lg border border-[#E6E3DA] text-xs bg-[#FAF9F5]"
              >
                {ALL_CUISINES.map((c) => (
                  <option key={c} value={c}>
                    {c === 'All' ? 'All Cuisines' : c}
                  </option>
                ))}
              </select>
              <select
                aria-label="Filter prep time"
                value={maxPrepMins}
                onChange={(e) => setMaxPrepMins(Number(e.target.value))}
                className="h-8 px-2.5 rounded-lg border border-[#E6E3DA] text-xs bg-[#FAF9F5]"
              >
                <option value={0}>Any Prep Time</option>
                <option value={20}>Quick (≤ 20 min)</option>
                <option value={35}>Moderate (≤ 35 min)</option>
              </select>
              <label className="inline-flex items-center gap-1.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={filterPickersOnly}
                  onChange={(e) => setFilterPickersOnly(e.target.checked)}
                  className="accent-[#4A7C59]"
                />
                <span>Keep all days visible while filtering dropdowns</span>
              </label>
            </div>
            {hasActiveFilters && (
              <button
                type="button"
                onClick={() => {
                  resetFilters();
                  setFilterPickersOnly(false);
                }}
                className="font-semibold text-[#4A7C59] hover:underline"
              >
                Reset Sort & Filters
              </button>
            )}
          </div>
        </div>
      )}

      {state.weeklyPlan.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-10 text-center space-y-4">
          <ChefHat className="w-9 h-9 text-[#4A7C59] mx-auto" />
          <div className="space-y-1">
            <h3 className="font-display text-lg font-semibold text-[#1F2421]">No weekly meals scheduled yet</h3>
            <p className="text-sm text-[#5B625C] max-w-md mx-auto">
              Build an AI-tailored week of meals and groceries in our Guided Trip Builder, or start with a blank 7-day board to pick dishes yourself.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            <button
              onClick={() => autoFillWeeklyPlan()}
              className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Auto-Fill Smart 7-Day Week</span>
            </button>
            <button
              onClick={() => setScreen('grocery-wizard')}
              className="px-5 py-2.5 rounded-xl bg-[#D97736] text-white text-xs font-semibold hover:opacity-95"
            >
              Build Grocery & Meal Trip
            </button>
            <button
              onClick={() => updateWeeklySlot('Monday', 'dinnerId', '')}
              className="px-5 py-2.5 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7]"
            >
              Create 7-Day Blank Schedule
            </button>
            <button
              onClick={() => setScreen('diet-planner')}
              className="px-5 py-2.5 rounded-xl border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] hover:bg-[#FAF9F5]"
            >
              Open Personal Diet Planner
            </button>
          </div>
        </div>
      ) : visibleDays.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 text-center space-y-3">
          <p className="font-display text-base font-semibold text-[#1F2421]">
            No days or meals match your current filters
          </p>
          <p className="text-xs text-[#5B625C]">
            Try clearing the diet, cuisine, or search filters to view your full 7-day schedule.
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            <button
              type="button"
              onClick={() => setFilterPickersOnly(true)}
              className="px-4 py-2 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7]"
            >
              Show All Days (Filter Dropdowns Only)
            </button>
            <button
              type="button"
              onClick={resetFilters}
              className="px-4 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold"
            >
              Reset Filters
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {visibleDays.map(({ day, dayCost, dayCalories }) => {
            const allSlots: { label: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack'; field: 'breakfastId' | 'lunchId' | 'dinnerId' | 'snackId'; id: string }[] = [
              { label: 'Breakfast', field: 'breakfastId', id: day.breakfastId },
              { label: 'Lunch', field: 'lunchId', id: day.lunchId },
              { label: 'Dinner', field: 'dinnerId', id: day.dinnerId },
              { label: 'Snack', field: 'snackId', id: day.snackId },
            ];
            const slots = slotFilter === 'All' ? allSlots : allSlots.filter((s) => s.label === slotFilter);
            return (
              <div key={day.day} className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <h3 className="font-display text-base font-semibold text-[#1F2421]">{day.day}</h3>
                  <span className="text-xs text-[#5B625C] tabular-nums">
                    Day Est. {formatCurrency(dayCost, state.user.currency)} · {dayCalories} kcal
                  </span>
                </div>
                <div
                  className={`grid gap-3 ${
                    slots.length === 1 ? 'grid-cols-1 max-w-md' : 'sm:grid-cols-2 lg:grid-cols-4'
                  }`}
                >
                  {slots.map((slot) => {
                    const rec = recipeMap.get(slot.id);
                    const pickerOptions =
                      rec && !sortedFilteredPickerRecipes.some((r) => r.id === rec.id)
                        ? [rec, ...sortedFilteredPickerRecipes]
                        : sortedFilteredPickerRecipes;
                    return (
                      <div key={slot.field} className="bg-[#FAF9F5] border border-[#EFECE3] rounded-xl p-3 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-[#4A7C59]">{slot.label}</span>
                          {rec && (
                            <button
                              onClick={() => openRecipe(rec)}
                              className="text-xs text-[#5B625C] hover:text-[#1F2421] underline"
                            >
                              View
                            </button>
                          )}
                        </div>
                        <select
                          aria-label={`${day.day} ${slot.label}`}
                          value={slot.id}
                          onChange={(e) => updateWeeklySlot(day.day, slot.field, e.target.value)}
                          className="w-full h-9 px-2 rounded-lg bg-white border border-[#E6E3DA] text-xs font-medium text-[#1F2421]"
                        >
                          <option value="">— Choose a meal ({sortedFilteredPickerRecipes.length}) —</option>
                          {pickerOptions.map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.title} ({r.cuisine} · {formatCurrency(r.estimatedCostINR, state.user.currency)})
                            </option>
                          ))}
                        </select>
                        {rec && (
                          <p className="text-[11px] text-[#5B625C] tabular-nums">
                            {rec.prepTimeMins}m · {rec.nutrition.calories} kcal ·{' '}
                            {formatCurrency(rec.estimatedCostINR, state.user.currency)}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function GlobalCuisineExplorerScreen() {
  const { state, allRecipes, openRecipe, toggleFavoriteRecipe, addCustomRecipe, showToast } = useKitchly();

  const [regionScope, setRegionScope] = useState<'all' | 'national' | 'international'>('all');
  const [cuisine, setCuisine] = useState<'All' | CuisineType>('All');
  const [dietFilter, setDietFilter] = useState<'All' | DietType>('All');
  const [difficulty, setDifficulty] = useState<'All' | 'Easy' | 'Medium' | 'Chef'>('All');
  const [maxPrep, setMaxPrep] = useState<number>(90);
  const [maxBudgetINR, setMaxBudgetINR] = useState<number>(800);
  const [nutritionTag, setNutritionTag] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'cost-asc' | 'prep-asc' | 'cal-asc' | 'protein-desc'>('featured');
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingAI, setLoadingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const matches = allRecipes.filter((r) => {
      const isInd = isNationalIndianCuisine(r.cuisine);
      if (regionScope === 'national' && !isInd) return false;
      if (regionScope === 'international' && isInd) return false;
      if (cuisine !== 'All' && r.cuisine.toLowerCase() !== cuisine.toLowerCase()) return false;
      if (dietFilter !== 'All' && r.dietType !== dietFilter) return false;
      if (difficulty !== 'All' && r.difficulty !== difficulty) return false;
      if (r.prepTimeMins > maxPrep) return false;
      if (r.estimatedCostINR > maxBudgetINR) return false;
      if (nutritionTag !== 'All' && !r.tags.some((tg) => tg.toLowerCase().includes(nutritionTag.toLowerCase()))) {
        return false;
      }
      if (q) {
        const matchesTitle =
          r.title.toLowerCase().includes(q) ||
          r.cuisine.toLowerCase().includes(q) ||
          r.description.toLowerCase().includes(q);
        const matchesIng = r.ingredients.some((i) => i.name.toLowerCase().includes(q));
        if (!matchesTitle && !matchesIng) return false;
      }
      return true;
    });

    if (sortBy === 'featured') return matches;
    return [...matches].sort((a, b) => {
      switch (sortBy) {
        case 'cost-asc':
          return a.estimatedCostINR - b.estimatedCostINR;
        case 'prep-asc':
          return a.prepTimeMins - b.prepTimeMins;
        case 'cal-asc':
          return a.nutrition.calories - b.nutrition.calories;
        case 'protein-desc':
          return b.nutrition.protein - a.nutrition.protein;
        default:
          return 0;
      }
    });
  }, [allRecipes, regionScope, cuisine, dietFilter, difficulty, maxPrep, maxBudgetINR, nutritionTag, sortBy, searchQuery]);

  const nationalFiltered = useMemo(() => filtered.filter((r) => isNationalIndianCuisine(r.cuisine)), [filtered]);
  const internationalFiltered = useMemo(() => filtered.filter((r) => !isNationalIndianCuisine(r.cuisine)), [filtered]);

  const handleGenerateAIRecipes = async () => {
    setLoadingAI(true);
    setAiError(null);
    try {
      const data = await postJson<{ recipes?: Recipe[] }>('/api/ai/explore-recipes', {
        regionScope,
        cuisine: regionScope === 'national' && cuisine === 'All' ? 'Indian' : cuisine,
        dietType: dietFilter,
        difficulty,
        nutritionTag,
        maxPrepMins: maxPrep,
        maxBudgetINR,
        searchQuery: searchQuery.trim(),
        profile: state.dietProfile,
        language: state.user.language,
      });
      if (Array.isArray(data.recipes) && data.recipes.length > 0) {
        data.recipes.forEach((r) => addCustomRecipe(r));
        showToast(`Added ${data.recipes.length} recipes matching your filters!`);
        return;
      }
    } catch {
      // Fall back cleanly below
    } finally {
      setLoadingAI(false);
    }

    const pickedCuisine: CuisineType =
      cuisine !== 'All'
        ? cuisine
        : regionScope === 'national'
        ? 'Indian'
        : regionScope === 'international'
        ? 'Italian'
        : 'Indian';
    const pickedDiet = dietFilter !== 'All' ? dietFilter : 'Vegetarian';
    const cleanRecipe: Recipe = {
      id: `local-explore-${Date.now()}`,
      title: `${pickedCuisine} ${searchQuery.trim() || (nutritionTag !== 'All' ? nutritionTag : 'Home-Style')} ${pickedDiet === 'Non-vegetarian' ? 'Skillet' : 'Bowl'}`,
      cuisine: pickedCuisine,
      dietType: pickedDiet,
      prepTimeMins: Math.min(maxPrep, 25),
      difficulty: difficulty !== 'All' ? difficulty : 'Easy',
      servings: 2,
      estimatedCostINR: Math.min(maxBudgetINR, 160),
      image: isNationalIndianCuisine(pickedCuisine)
        ? '/src/assets/images/meal_dinner_indian_1795377616543.jpg'
        : '/src/assets/images/meal_lunch_bowl_1795377616141.jpg',
      description: `Fresh ${pickedCuisine} ${pickedDiet.toLowerCase()} dish prepared to fit your ${maxPrep}-minute prep and budget filters.`,
      mealSlot: 'Lunch',
      allergens: [],
      tags: [
        ...(nutritionTag !== 'All' ? [nutritionTag] : ['Balanced']),
        'Low oil',
        'Zero sugar',
      ],
      nutrition: { calories: 340, protein: 18, carbs: 38, fat: 10 },
      ingredients: [
        {
          name: pickedDiet === 'Non-vegetarian' ? 'Chicken Breast' : 'Paneer / Tofu',
          quantity: 180,
          unit: 'g',
          category: pickedDiet === 'Non-vegetarian' ? 'Meat and seafood' : 'Dairy',
        },
        { name: 'Mixed Seasonal Vegetables', quantity: 1.5, unit: 'cups', category: 'Vegetables' },
        { name: 'Garlic & Light Herbs', quantity: 1, unit: 'tbsp', category: 'Spices' },
      ],
      instructions: [
        'Prep protein and vegetables into bite-sized pieces.',
        `Saute gently in 1 tsp oil with aromatic ${pickedCuisine} spices and seasonings.`,
        'Simmer briefly until cooked through and serve warm.',
      ],
    };
    addCustomRecipe(cleanRecipe);
    showToast(`Added "${cleanRecipe.title}" matching your filters!`);
  };

  const resetAllFilters = () => {
    setRegionScope('all');
    setCuisine('All');
    setDietFilter('All');
    setDifficulty('All');
    setMaxPrep(90);
    setMaxBudgetINR(800);
    setNutritionTag('All');
    setSortBy('featured');
    setSearchQuery('');
    setAiError(null);
  };

  const visibleCuisineChips: ('All' | CuisineType)[] =
    regionScope === 'national'
      ? ['All', 'Indian']
      : regionScope === 'international'
      ? ['All', ...INTERNATIONAL_ONLY_CUISINES]
      : ALL_CUISINES;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">Global & National Cuisine Explorer</h2>
          <p className="text-sm text-[#5B625C]">
            Discover {allRecipes.length}+ recipes across Indian (National) & 13 International culinary traditions.
          </p>
        </div>
        <button
          type="button"
          onClick={handleGenerateAIRecipes}
          disabled={loadingAI}
          className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] disabled:opacity-60 inline-flex items-center gap-2 shrink-0 self-start sm:self-auto"
        >
          {loadingAI ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          <span>{loadingAI ? 'Curating AI Recipes...' : 'Generate AI Recipes for Filter'}</span>
        </button>
      </div>

      {/* National vs International Region Bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
          {([
            { id: 'all', label: 'All (National + International)' },
            { id: 'national', label: 'National · Indian Kitchen' },
            { id: 'international', label: 'International · Global' },
          ] as const).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setRegionScope(tab.id);
                setCuisine('All');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                regionScope === tab.id ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C] hover:text-[#1F2421]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Cuisine Horizontal Filter */}
      <div className="flex flex-wrap gap-1.5">
        {visibleCuisineChips.map((c) => (
          <button
            key={c}
            onClick={() => setCuisine(c)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-colors whitespace-nowrap ${
              cuisine === c
                ? 'bg-[#4A7C59] text-white'
                : 'bg-white border border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
            }`}
          >
            {c === 'Indian' ? 'Indian (National)' : c}
          </button>
        ))}
      </div>

      {/* Filter & Sort Bar (Unclipped 2-row responsive grid) */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-4 space-y-3">
        <div className="grid sm:grid-cols-2 lg:grid-cols-12 gap-3">
          <div className="relative sm:col-span-2 lg:col-span-4">
            <Search className="w-4 h-4 text-[#5B625C] absolute left-3 top-3 pointer-events-none" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dish or ingredient (e.g. chicken, rice)..."
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-[#E6E3DA] text-sm"
            />
          </div>
          <select
            aria-label="Diet filter"
            value={dietFilter}
            onChange={(e) => setDietFilter(e.target.value as 'All' | DietType)}
            className="lg:col-span-3 h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
          >
            <option value="All">All Diet Types</option>
            <option value="Vegetarian">Vegetarian</option>
            <option value="Vegan">Vegan</option>
            <option value="Eggetarian">Eggetarian</option>
            <option value="Pescatarian">Pescatarian</option>
            <option value="Non-vegetarian">Non-vegetarian</option>
          </select>
          <select
            aria-label="Difficulty"
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value as 'All' | 'Easy' | 'Medium' | 'Chef')}
            className="lg:col-span-2 h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
          >
            <option value="All">Any Difficulty</option>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Chef">Chef</option>
          </select>
          <select
            aria-label="Sort recipes"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="lg:col-span-3 h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
          >
            <option value="featured">Sort: Featured</option>
            <option value="cost-asc">Sort: Lowest Cost First</option>
            <option value="prep-asc">Sort: Quickest Prep</option>
            <option value="cal-asc">Sort: Lowest Calories</option>
            <option value="protein-desc">Sort: Highest Protein</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-[#EFECE3] text-xs text-[#5B625C]">
          <div className="flex flex-wrap items-center gap-5">
            <select
              aria-label="Nutrition preference"
              value={nutritionTag}
              onChange={(e) => setNutritionTag(e.target.value)}
              className="h-9 px-3 rounded-xl border border-[#E6E3DA] text-xs font-medium text-[#1F2421] bg-[#FAF9F5]"
            >
              <option value="All">All Nutrition Tags</option>
              <option value="High-protein">High-protein</option>
              <option value="Gluten-free">Gluten-free</option>
              <option value="Plant-based">Plant-based</option>
              <option value="Budget-friendly">Budget-friendly</option>
              <option value="Quick">Quick</option>
            </select>
            <label className="flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Max Prep: {maxPrep} mins</span>
              <input
                type="range"
                min={10}
                max={90}
                step={5}
                value={maxPrep}
                onChange={(e) => setMaxPrep(Number(e.target.value))}
                className="accent-[#4A7C59]"
              />
            </label>
            <label className="flex items-center gap-2">
              <span>Max Budget: {formatCurrency(maxBudgetINR, state.user.currency)}</span>
              <input
                type="range"
                min={75}
                max={800}
                step={25}
                value={maxBudgetINR}
                onChange={(e) => setMaxBudgetINR(Number(e.target.value))}
                className="accent-[#4A7C59]"
              />
            </label>
          </div>
          <span className="font-medium text-[#1F2421] tabular-nums">
            {filtered.length} recipe{filtered.length === 1 ? '' : 's'} found
          </span>
        </div>

        {aiError && (
          <p className="text-xs text-[#9A4A18] bg-[#FDF2EC] border border-[#D97736]/30 rounded-xl px-3 py-2">
            {aiError}
          </p>
        )}
      </div>

      {/* Results */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-10 text-center space-y-3">
          <p className="font-display text-base font-semibold">No matching recipes found in library</p>
          <p className="text-sm text-[#5B625C] max-w-md mx-auto">
            Let Kitchly AI create 4 authentic recipes tailored to your active filters, or reset filters to browse all cuisines.
          </p>
          <div className="flex flex-wrap justify-center gap-2.5 pt-1">
            <button
              type="button"
              onClick={handleGenerateAIRecipes}
              disabled={loadingAI}
              className="px-4 py-2.5 rounded-xl bg-[#D97736] text-white text-sm font-semibold hover:opacity-95 disabled:opacity-60 inline-flex items-center gap-1.5"
            >
              {loadingAI ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>{loadingAI ? 'Creating Recipes...' : 'Generate AI Recipes'}</span>
            </button>
            <button
              type="button"
              onClick={resetAllFilters}
              className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-medium"
            >
              Reset Filters
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          {[
            { title: 'National · Indian Kitchen', accent: 'text-[#9A4A18]', items: nationalFiltered },
            { title: 'International · Global Kitchens', accent: 'text-[#4A7C59]', items: internationalFiltered },
          ]
            .filter((sec) => sec.items.length > 0)
            .map((sec) => (
              <section key={sec.title} className="space-y-4">
                <div className="flex items-center justify-between border-b border-[#EFECE3] pb-2">
                  <h3 className={`font-display text-lg font-bold ${sec.accent}`}>{sec.title}</h3>
                  <span className="text-xs text-[#5B625C] tabular-nums">
                    {sec.items.length} recipe{sec.items.length === 1 ? '' : 's'}
                  </span>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {sec.items.map((r) => {
                    const isFav = state.favoriteRecipeIds.includes(r.id);
                    return (
                      <div key={r.id} className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden flex flex-col">
                        <button onClick={() => openRecipe(r)} className="h-44 w-full overflow-hidden text-left">
                          <FoodImage src={r.image} alt={r.title} className="w-full h-full object-cover hover:scale-[1.02] transition-transform" />
                        </button>
                        <div className="p-5 flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-center justify-between gap-2 mb-1">
                              <p className="text-xs font-medium text-[#4A7C59]">
                                {r.cuisine} · {r.dietType} · {r.difficulty}
                              </p>
                              <button
                                onClick={() => toggleFavoriteRecipe(r)}
                                aria-label="Favorite recipe"
                                className={`p-1.5 rounded-lg ${isFav ? 'text-[#D97736]' : 'text-[#5B625C]'}`}
                              >
                                <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                              </button>
                            </div>
                            <h3
                              onClick={() => openRecipe(r)}
                              className="font-display text-base font-semibold text-[#1F2421] hover:text-[#4A7C59] cursor-pointer mb-1.5"
                            >
                              {r.title}
                            </h3>
                            <p className="text-xs text-[#5B625C] line-clamp-2 mb-3">{r.description}</p>
                          </div>
                          <div className="pt-3 border-t border-[#EFECE3] flex items-center justify-between text-xs text-[#5B625C] tabular-nums">
                            <span className="inline-flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5" />
                              {r.prepTimeMins} min
                            </span>
                            <span>{r.nutrition.calories} kcal</span>
                            <span className="font-semibold text-[#1F2421]">
                              {formatCurrency(r.estimatedCostINR, state.user.currency)}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            ))}
        </div>
      )}
    </div>
  );
}

export function RecipeDetailScreen() {
  const {
    state,
    t,
    selectedRecipe,
    allRecipes,
    setScreen,
    toggleFavoriteRecipe,
    addRecipeIngredientsToGrocery,
    assignRecipeToCookMode,
  } = useKitchly();

  const recipe: Recipe = selectedRecipe || allRecipes[0];
  const [servings, setServings] = useState(recipe.servings);
  useEffect(() => {
    setServings(recipe.servings);
  }, [recipe.id, recipe.servings]);
  const mult = servings / Math.max(1, recipe.servings);
  const pantryNames = state.pantry.map((p) => p.name.toLowerCase());
  const isFav = state.favoriteRecipeIds.includes(recipe.id);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <button
        onClick={() => setScreen('cuisine-explorer')}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-[#5B625C] hover:text-[#1F2421]"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Recipes</span>
      </button>

      <div className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden">
        <div className="grid md:grid-cols-12 items-stretch">
          <div className="md:col-span-5 min-h-[260px]">
            <FoodImage src={recipe.image} alt={recipe.title} className="w-full h-full object-cover" />
          </div>
          <div className="md:col-span-7 p-6 lg:p-8 flex flex-col justify-between space-y-5">
            <div>
              <p className="text-xs font-medium text-[#4A7C59] mb-1.5">
                {recipe.cuisine} · {recipe.dietType} · {recipe.difficulty}
              </p>
              <h2 className="font-display text-2xl font-bold text-[#1F2421] mb-2">{recipe.title}</h2>
              <p className="text-sm text-[#5B625C] leading-relaxed">{recipe.description}</p>
            </div>

            <div className="grid grid-cols-4 gap-3 py-3 border-y border-[#EFECE3] text-center">
              <div>
                <div className="font-mono text-base font-semibold tabular-nums">{recipe.nutrition.calories}</div>
                <div className="text-xs text-[#5B625C]">{t.calories}</div>
              </div>
              <div>
                <div className="font-mono text-base font-semibold tabular-nums">{recipe.nutrition.protein}g</div>
                <div className="text-xs text-[#5B625C]">{t.protein}</div>
              </div>
              <div>
                <div className="font-mono text-base font-semibold tabular-nums">{recipe.nutrition.carbs}g</div>
                <div className="text-xs text-[#5B625C]">{t.carbs}</div>
              </div>
              <div>
                <div className="font-mono text-base font-semibold tabular-nums">{recipe.nutrition.fat}g</div>
                <div className="text-xs text-[#5B625C]">{t.fat}</div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="inline-flex items-center gap-2 bg-[#F3F1EA] px-3 py-1.5 rounded-xl text-sm">
                <span className="text-xs text-[#5B625C]">{t.servings}:</span>
                <button
                  onClick={() => setServings((s) => Math.max(1, s - 1))}
                  className="w-7 h-7 rounded-lg bg-white font-semibold"
                >
                  -
                </button>
                <span className="font-mono font-semibold w-5 text-center tabular-nums">{servings}</span>
                <button
                  onClick={() => setServings((s) => Math.min(12, s + 1))}
                  className="w-7 h-7 rounded-lg bg-white font-semibold"
                >
                  +
                </button>
              </div>
              <span className="text-sm font-mono font-semibold text-[#1F2421] tabular-nums">
                Est. {formatCurrency(Math.round(recipe.estimatedCostINR * mult), state.user.currency)}
              </span>
              <span className="text-xs text-[#5B625C]">{recipe.prepTimeMins} mins</span>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => addRecipeIngredientsToGrocery(recipe, mult)}
                className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Add Missing to Grocery List</span>
              </button>
              <button
                onClick={() => assignRecipeToCookMode(recipe, 'Dinner')}
                className="px-4 py-2.5 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7] inline-flex items-center gap-1.5"
              >
                <ChefHat className="w-4 h-4 text-[#4A7C59]" />
                <span>Assign to Cook Mode</span>
              </button>
              <button
                onClick={() => toggleFavoriteRecipe(recipe)}
                className={`px-3.5 py-2.5 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 ${
                  isFav ? 'border-[#D97736] text-[#D97736] bg-[#FDF2EC]' : 'border-[#E6E3DA] text-[#5B625C]'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-current' : ''}`} />
                <span>{isFav ? 'Saved' : 'Save'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Ingredients & Instructions */}
      <div className="grid md:grid-cols-12 gap-6">
        <div className="md:col-span-5 bg-white border border-[#E6E3DA] rounded-2xl p-6">
          <h3 className="font-display text-lg font-semibold mb-4">{t.ingredients}</h3>
          <ul className="divide-y divide-[#EFECE3]">
            {recipe.ingredients.map((ing, idx) => {
              const inPantry = pantryNames.some(
                (p) => p.includes(ing.name.toLowerCase()) || ing.name.toLowerCase().includes(p)
              );
              const scaledQty = Math.round(ing.quantity * mult * 10) / 10;
              return (
                <li key={idx} className="py-2.5 flex items-center justify-between gap-3 text-sm">
                  <div>
                    <span className="font-medium text-[#1F2421]">{ing.name}</span>
                    <p className={`text-xs ${inPantry ? 'text-[#4A7C59]' : 'text-[#D97736]'}`}>
                      {inPantry ? 'Available in Pantry' : 'Need to buy'}
                    </p>
                  </div>
                  <span className="font-mono text-xs text-[#5B625C] tabular-nums shrink-0">
                    {scaledQty} {ing.unit}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="md:col-span-7 bg-white border border-[#E6E3DA] rounded-2xl p-6">
          <h3 className="font-display text-lg font-semibold mb-4">{t.instructions}</h3>
          <ol className="space-y-4">
            {recipe.instructions.map((step, idx) => (
              <li key={idx} className="flex gap-3.5 text-sm leading-relaxed">
                <span className="w-6 h-6 rounded-lg bg-[#F3F1EA] text-[#4A7C59] font-mono text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <span className="text-[#1F2421]">{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}
