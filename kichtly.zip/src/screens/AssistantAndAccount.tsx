import React, { useEffect, useRef, useState } from 'react';
import {
  Bell,
  CheckCheck,
  Globe,
  Loader2,
  LogOut,
  Mic,
  MicOff,
  RotateCcw,
  Send,
  Share2,
  Shield,
  Volume2,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { CURRENCY_RATES, formatCurrency, SUPPORTED_LANGUAGES } from '../i18n/translations';
import { INDIA_PLATFORMS, GLOBAL_PLATFORMS } from '../services/groceryAdapter';
import { AppScreen, CurrencyCode, LanguageCode } from '../types/kitchly';
import { PWAInstallButton } from '../components/PWAComponents';

interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
  actionScreen?: AppScreen;
  actionLabel?: string;
}

const VALID_SCREENS: AppScreen[] = [
  'dashboard',
  'language',
  'onboarding',
  'diet-planner',
  'meal-planner',
  'cuisine-explorer',
  'recipe-detail',
  'dont-know',
  'cook-with-have',
  'grocery-wizard',
  'grocery-list',
  'price-comparison',
  'pantry',
  'budget',
  'family',
  'cook-mode',
  'ai-assistant',
  'notifications',
  'household-profile',
  'settings',
];

const STARTER_PROMPTS = [
  'How do I change the app language?',
  'I have potatoes, eggs and onions. What can I make?',
  'Suggest a healthy dinner within my budget.',
  'How do I set up my weekly plan & grocery budget?',
  'I don’t like mushrooms.',
];

function sanitizeAIError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err || '');
  if (
    raw.includes('503') ||
    raw.includes('UNAVAILABLE') ||
    raw.includes('high demand') ||
    raw.trim().startsWith('{')
  ) {
    return 'Kitchly AI is briefly busy right now. Please tap Send or try again in a few seconds.';
  }
  return raw || 'Kitchly AI could not respond right now. Please try again.';
}

export function KitchlyAIAssistantScreen() {
  const {
    state,
    t,
    setScreen,
    setLanguage,
    excludeIngredientFromAI,
    pendingAssistantPrompt,
    clearPendingAssistantPrompt,
    showToast,
  } = useKitchly();

  const buildGreeting = () => {
    const prefsText =
      state.dietProfile.foodPreferences.length > 0
        ? state.dietProfile.foodPreferences.join(', ')
        : 'none set yet';
    const allergiesText =
      [...state.dietProfile.allergies, ...state.dietProfile.customAllergies].join(', ') || 'none';
    const pantrySummary =
      state.pantry.length > 0
        ? `${state.pantry.length} pantry items`
        : 'no pantry items added yet';
    return `Hello ${state.user.name}! I’m Kitchly AI — ask me anything about recipes, meal planning, grocery budgeting, pantry swaps, or how to use any Kitchly feature (like changing languages, resetting your kitchen, or Cook Mode). Your profile: diet (${prefsText}), allergies (${allergiesText}), and ${pantrySummary}.`;
  };

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      role: 'assistant',
      text: buildGreeting(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const userHasChattedRef = useRef(false);

  useEffect(() => {
    if (!userHasChattedRef.current) {
      setMessages([{ role: 'assistant', text: buildGreeting() }]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.user.id, state.user.name, state.pantry.length, state.dietProfile.foodPreferences.length]);

  const currentLang = SUPPORTED_LANGUAGES.find((l) => l.code === state.user.language) || SUPPORTED_LANGUAGES[0];

  const sendMessage = async (textToSend?: string) => {
    const query = (textToSend ?? input).trim();
    if (!query || loading) return;
    if (!textToSend) setInput('');
    userHasChattedRef.current = true;

    const nextHistory: ChatMessage[] = [...messages, { role: 'user', text: query }];
    setMessages(nextHistory);
    setLoading(true);

    try {
      const { postJson } = await import('../services/apiClient');
      const data = await postJson<{
        reply: string;
        excludedIngredientToSave?: string;
        suggestedActionScreen?: string;
        actionLabel?: string;
        languageCodeToSet?: string;
      }>('/api/ai/chat', {
        message: query,
        history: nextHistory,
        language: state.user.language,
        context: {
          householdName: state.user.householdName,
          country: state.user.country,
          currency: state.user.currency,
          foodPreferences: state.dietProfile.foodPreferences,
          allergies: [...state.dietProfile.allergies, ...state.dietProfile.customAllergies],
          dislikes: [...state.dietProfile.dislikedIngredients, ...state.dietProfile.neverRecommend],
          pantry: state.pantry.map((p) => `${p.name} (${p.quantity} ${p.unit})`),
          groceryCount: state.groceryList.filter((g) => !g.purchased).length,
          familyCount: state.familyMembers.length,
          weeklyBudget: state.dietProfile.weeklyBudget,
          dailyBudget: state.dietProfile.dailyBudget,
        },
      });

      if (data.excludedIngredientToSave) {
        excludeIngredientFromAI(data.excludedIngredientToSave);
      }

      if (data.languageCodeToSet) {
        const langMatch = SUPPORTED_LANGUAGES.find((l) => l.code === data.languageCodeToSet);
        if (langMatch) {
          setLanguage(langMatch.code);
          showToast(`Switched language to ${langMatch.nativeName}.`);
        }
      }

      const suggested =
        data.suggestedActionScreen && VALID_SCREENS.includes(data.suggestedActionScreen as AppScreen)
          ? (data.suggestedActionScreen as AppScreen)
          : undefined;

      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: data.reply,
          actionScreen: suggested,
          actionLabel: data.actionLabel || 'Open tool →',
        },
      ]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: 'assistant', text: sanitizeAIError(err) }]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (pendingAssistantPrompt) {
      const prompt = pendingAssistantPrompt;
      clearPendingAssistantPrompt();
      void sendMessage(prompt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingAssistantPrompt]);

  const startVoiceInput = () => {
    const SpeechRec =
      (window as unknown as { SpeechRecognition?: new () => SpeechRecognition; webkitSpeechRecognition?: new () => SpeechRecognition }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognition }).webkitSpeechRecognition;

    if (!SpeechRec) {
      showToast('Voice recognition is not supported in this browser. Type your request below.');
      return;
    }

    const recognition = new SpeechRec();
    recognition.lang = currentLang.speechLocale;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    setListening(true);
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results?.[0]?.[0]?.transcript;
      if (transcript) {
        setInput(transcript);
        sendMessage(transcript);
      }
      setListening(false);
    };
    recognition.onerror = () => {
      setListening(false);
      showToast('Could not capture voice input. Please try again.');
    };
    recognition.onend = () => setListening(false);
    recognition.start();
  };

  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = currentLang.speechLocale;
    window.speechSynthesis.speak(utter);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">{t.aiAssistant}</h2>
          <p className="text-xs text-[#5B625C]">
            Context: {state.dietProfile.foodPreferences.join(', ') || 'No diet prefs set'} · Excluded:{' '}
            {[...state.dietProfile.allergies, ...state.dietProfile.neverRecommend].join(', ') || 'None'} · Language: {currentLang.nativeName}
          </p>
        </div>
      </div>

      {/* Starter Prompts */}
      <div className="flex flex-wrap gap-2">
        {STARTER_PROMPTS.map((sp) => (
          <button
            key={sp}
            onClick={() => sendMessage(sp)}
            className="px-3 py-1.5 rounded-xl bg-white border border-[#E6E3DA] text-xs font-medium text-[#1F2421] hover:bg-[#F3F1EA]"
          >
            {sp}
          </button>
        ))}
      </div>

      {/* Chat Thread */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5 min-h-[380px] max-h-[520px] overflow-y-auto space-y-4">
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                m.role === 'user'
                  ? 'bg-[#4A7C59] text-white'
                  : 'bg-[#F3F1EA] text-[#1F2421]'
              }`}
            >
              <p className="whitespace-pre-wrap">{m.text}</p>
              {m.role === 'assistant' && (
                <div className="flex items-center gap-3 mt-2 pt-2 border-t border-[#E6E3DA]/70 text-xs">
                  <button
                    onClick={() => speakText(m.text)}
                    className="inline-flex items-center gap-1 text-[#5B625C] hover:text-[#1F2421]"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Listen</span>
                  </button>
                  {m.actionScreen && (
                    <button
                      onClick={() => setScreen(m.actionScreen!)}
                      className="font-semibold text-[#4A7C59] hover:underline"
                    >
                      {m.actionLabel || 'Open tool →'}
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-xs text-[#5B625C]">
            <Loader2 className="w-4 h-4 animate-spin text-[#4A7C59]" />
            <span>Kitchly AI is thinking...</span>
          </div>
        )}
      </div>

      {/* Input + Voice */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          sendMessage();
        }}
        className="flex gap-2"
      >
        <button
          type="button"
          onClick={startVoiceInput}
          aria-label={t.speakPrompt}
          className={`min-h-[46px] px-4 rounded-xl border flex items-center gap-1.5 text-sm font-medium shrink-0 ${
            listening ? 'bg-[#D97736] text-white border-[#D97736]' : 'bg-white border-[#E6E3DA] text-[#1F2421]'
          }`}
        >
          {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-[#4A7C59]" />}
          <span className="hidden sm:inline">{listening ? t.listening : t.speakPrompt}</span>
        </button>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={t.voicePromptPlaceholder}
          className="flex-1 h-[46px] px-4 rounded-xl bg-white border border-[#E6E3DA] text-sm"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="min-h-[46px] px-5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] disabled:opacity-50 inline-flex items-center gap-1.5"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">Send</span>
        </button>
      </form>
    </div>
  );
}

interface SpeechRecognitionEvent {
  results: { [index: number]: { [index: number]: { transcript: string } } };
}
interface SpeechRecognition {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((ev: SpeechRecognitionEvent) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
}

export function NotificationsScreen() {
  const { state, t, markNotificationRead, markAllNotificationsRead, setScreen } = useKitchly();

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">{t.notifications}</h2>
          <p className="text-sm text-[#5B625C]">Expiry reminders, low-stock alerts, and kitchen activity.</p>
        </div>
        {state.notifications.length > 0 && (
          <button
            onClick={markAllNotificationsRead}
            className="px-3.5 py-2 rounded-xl bg-white border border-[#E6E3DA] text-xs font-semibold hover:bg-[#F3F1EA] inline-flex items-center gap-1.5"
          >
            <CheckCheck className="w-4 h-4 text-[#4A7C59]" />
            <span>Mark all read</span>
          </button>
        )}
      </div>

      {state.notifications.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 text-center space-y-2">
          <Bell className="w-8 h-8 text-[#4A7C59] mx-auto" />
          <h3 className="font-display text-base font-semibold text-[#1F2421]">No kitchen alerts yet</h3>
          <p className="text-xs text-[#5B625C] max-w-md mx-auto">
            Expiry reminders, low-stock notices, and household activity updates will appear here as you add pantry items and meal plans.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {state.notifications.map((n) => (
            <div
              key={n.id}
              className={`bg-white border rounded-2xl p-4 flex items-start justify-between gap-4 ${
                n.read ? 'border-[#E6E3DA] opacity-75' : 'border-[#4A7C59]'
              }`}
            >
              <div className="flex items-start gap-3">
                <Bell className={`w-4 h-4 mt-1 shrink-0 ${n.read ? 'text-[#5B625C]' : 'text-[#D97736]'}`} />
                <div>
                  <h3 className="text-sm font-semibold text-[#1F2421]">{n.title}</h3>
                  <p className="text-xs text-[#5B625C] mt-0.5 leading-relaxed">{n.message}</p>
                  <p className="text-[11px] text-[#5B625C] mt-1">{n.timestamp}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {n.targetScreen && (
                  <button
                    onClick={() => {
                      markNotificationRead(n.id);
                      setScreen(n.targetScreen!);
                    }}
                    className="text-xs font-semibold text-[#4A7C59] hover:underline"
                  >
                    Open
                  </button>
                )}
                {!n.read && (
                  <button
                    onClick={() => markNotificationRead(n.id)}
                    className="text-xs text-[#5B625C] hover:text-[#1F2421]"
                  >
                    Dismiss
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function HouseholdProfileScreen() {
  const { state, setScreen } = useKitchly();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 lg:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#4A7C59] mb-1">HOUSEHOLD PROFILE</p>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">{state.user.householdName}</h2>
          <p className="text-sm text-[#5B625C] mt-1">
            {state.user.name} · {state.user.country} ({state.user.currency}) · {state.familyMembers.length} Family Members
          </p>
        </div>
        <button
          onClick={() => setScreen('settings')}
          className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] self-start"
        >
          Edit Account Settings
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-4 tabular-nums">
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
          <p className="text-xs text-[#5B625C] mb-1">Dietary Modes</p>
          <p className="text-sm font-semibold text-[#1F2421]">
            {state.dietProfile.foodPreferences.join(', ') || 'Not configured yet'}
          </p>
        </div>
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
          <p className="text-xs text-[#5B625C] mb-1">Strict Allergies</p>
          <p className="text-sm font-semibold text-[#D97736]">
            {state.dietProfile.allergies.join(', ') || 'None configured'}
          </p>
        </div>
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
          <p className="text-xs text-[#5B625C] mb-1">Weekly Budget</p>
          <p className="font-mono text-base font-semibold text-[#1F2421]">
            {state.dietProfile.weeklyBudget > 0
              ? formatCurrency(state.dietProfile.weeklyBudget, state.user.currency)
              : 'Not set'}
          </p>
        </div>
      </div>

      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-3">
        <h3 className="font-display text-base font-semibold">Saved Favorite Recipes ({state.favoriteRecipeIds.length})</h3>
        <p className="text-xs text-[#5B625C]">
          Manage household members on the Family screen or customize your AI nutrition plan in Personal Diet Planner.
        </p>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setScreen('family')}
            className="px-4 py-2 rounded-xl bg-[#F3F1EA] text-xs font-semibold hover:bg-[#E7E3D7]"
          >
            Manage Family Members
          </button>
          <button
            onClick={() => setScreen('diet-planner')}
            className="px-4 py-2 rounded-xl bg-[#F3F1EA] text-xs font-semibold hover:bg-[#E7E3D7]"
          >
            Open Personal Diet Planner
          </button>
        </div>
      </div>
    </div>
  );
}

export function AccountSettingsScreen() {
  const {
    state,
    t,
    firebaseUser,
    isCloudSynced,
    sessionMode,
    handleGoogleSignIn,
    handleSignOut,
    resetToFreshAccount,
    setLanguage,
    updateHouseholdSettings,
    showToast,
  } = useKitchly();

  const [householdName, setHouseholdName] = useState(state.user.householdName);
  const [country, setCountry] = useState(state.user.country);
  const [currency, setCurrency] = useState<CurrencyCode>(state.user.currency);
  const [cookPin, setCookPin] = useState(state.user.cookModePin);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetting, setResetting] = useState(false);

  useEffect(() => {
    setHouseholdName(state.user.householdName);
    setCountry(state.user.country);
    setCurrency(state.user.currency);
    setCookPin(state.user.cookModePin);
  }, [state.user.id, state.user.householdName, state.user.country, state.user.currency, state.user.cookModePin]);

  const platforms = country.toLowerCase() === 'india' ? INDIA_PLATFORMS : GLOBAL_PLATFORMS;

  const handleConfirmReset = async () => {
    setResetting(true);
    try {
      await resetToFreshAccount();
      setConfirmReset(false);
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="font-display text-2xl font-bold text-[#1F2421]">{t.settings}</h2>
        <p className="text-sm text-[#5B625C]">Manage cloud sync, language, regional currency, and partner grocery adapters.</p>
      </div>

      {/* Cloud Sync Status */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-[#4A7C59] shrink-0 mt-0.5" />
          <div>
            <h3 className="font-display text-base font-semibold text-[#1F2421]">
              {isCloudSynced
                ? 'Connected to Google Cloud Firestore'
                : sessionMode === 'guest'
                ? 'Personal Kitchen (Saved on This Device)'
                : 'Demo Kitchen Session (Saved Locally)'}
            </h3>
            <p className="text-xs text-[#5B625C]">
              {isCloudSynced
                ? `Signed in as ${firebaseUser?.email}. All household changes persist automatically.`
                : 'Everything you add is saved automatically on this device. Sign in with Google anytime to back up across devices.'}
            </p>
          </div>
        </div>
        {isCloudSynced ? (
          <button
            onClick={handleSignOut}
            className="px-4 py-2 rounded-xl border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] hover:bg-[#F3F1EA] inline-flex items-center gap-1.5 self-start"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{t.signOut}</span>
          </button>
        ) : (
          <div className="flex flex-wrap items-center gap-2 self-start">
            <button
              onClick={handleGoogleSignIn}
              className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A]"
            >
              Sign in with Google
            </button>
            <button
              onClick={handleSignOut}
              className="px-3.5 py-2.5 rounded-xl border border-[#E6E3DA] text-xs font-semibold text-[#5B625C] hover:bg-[#F3F1EA]"
            >
              Switch Mode
            </button>
          </div>
        )}
      </div>

      {/* Start Fresh / Reset Kitchen Data */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-display text-base font-semibold text-[#1F2421]">Start Fresh / Reset Kitchen Data</h3>
          <p className="text-xs text-[#5B625C] mt-0.5">
            Clear your grocery cart, pantry items, meal history, and sample budgets to set up your kitchen from scratch.
          </p>
        </div>
        {confirmReset ? (
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setConfirmReset(false)}
              disabled={resetting}
              className="px-3.5 py-2 rounded-xl border border-[#E6E3DA] text-xs font-semibold text-[#5B625C] hover:bg-[#F3F1EA]"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmReset}
              disabled={resetting}
              className="px-4 py-2 rounded-xl bg-[#D97736] text-white text-xs font-semibold hover:opacity-95 inline-flex items-center gap-1.5 disabled:opacity-60"
            >
              {resetting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
              <span>{resetting ? 'Clearing...' : 'Confirm Clear & Restart'}</span>
            </button>
          </div>
        ) : (
          <button
            onClick={() => setConfirmReset(true)}
            className="px-4 py-2.5 rounded-xl border border-[#D97736]/40 text-[#9A4A18] bg-[#FDF2EC] text-xs font-semibold hover:bg-[#FBE6DA] inline-flex items-center gap-1.5 self-start shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Kitchen Data</span>
          </button>
        )}
      </div>

      {/* Install & Share App on Device (PWA) */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-display text-base font-semibold text-[#1F2421]">Install or Share Kitchly App</h3>
          <p className="text-xs text-[#5B625C] mt-0.5">
            Add Kitchly to your home screen for offline use, or share the app link so friends and family can run their own kitchen.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={async () => {
              const url = window.location.origin;
              if (navigator.share) {
                try {
                  await navigator.share({
                    title: 'Kitchly — Kitchen & Grocery Planner',
                    text: 'Use Kitchly to plan daily calorie diets, pantry meals, and compare Blinkit/Zepto prices.',
                    url,
                  });
                  return;
                } catch {
                  // fall back to clipboard
                }
              }
              try {
                await navigator.clipboard.writeText(url);
                showToast('Copied Kitchly app link to clipboard!');
              } catch {
                showToast(`Share this link: ${url}`);
              }
            }}
            className="px-4 py-2.5 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7] inline-flex items-center gap-1.5"
          >
            <Share2 className="w-3.5 h-3.5 text-[#4A7C59]" />
            <span>Share App</span>
          </button>
          <PWAInstallButton variant="card" />
        </div>
      </div>

      {/* General & Localization Settings */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-4">
        <h3 className="font-display text-base font-semibold">Household & Localization</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs text-[#5B625C] mb-1">Household Name</label>
            <input
              value={householdName}
              onChange={(e) => setHouseholdName(e.target.value)}
              className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-[#5B625C] mb-1">Language (12 Supported)</label>
            <div className="relative">
              <Globe className="w-4 h-4 text-[#5B625C] absolute left-3 top-3" />
              <select
                value={state.user.language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                className="w-full h-10 pl-9 pr-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName} ({l.name})
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs text-[#5B625C] mb-1">Country / Region</label>
            <select
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="India">India</option>
              <option value="United States">United States</option>
              <option value="United Kingdom">United Kingdom</option>
              <option value="Germany">Germany / EU</option>
              <option value="UAE">UAE</option>
              <option value="Singapore">Singapore</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-[#5B625C] mb-1">Display Currency</label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              {Object.entries(CURRENCY_RATES).map(([code, meta]) => (
                <option key={code} value={code}>
                  {meta.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-[#5B625C] mb-1">Cook Mode Privacy PIN</label>
            <input
              value={cookPin}
              onChange={(e) => setCookPin(e.target.value)}
              maxLength={8}
              className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm font-mono"
            />
          </div>
        </div>
        <button
          onClick={() => {
            updateHouseholdSettings({
              householdName: householdName.trim() || state.user.householdName,
              country,
              currency,
              cookModePin: cookPin.trim() || '2468',
            });
            showToast('Household settings saved.');
          }}
          className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A]"
        >
          Save Settings
        </button>
      </div>

      {/* Grocery Integration Credentials Status */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-3">
        <h3 className="font-display text-base font-semibold">Partner Grocery Integration Architecture</h3>
        <p className="text-xs text-[#5B625C] leading-relaxed">
          Kitchly’s Smart Grocery Comparison engine runs in transparent sample mode until authorized
          merchant API credentials are configured on your server environment:
        </p>
        <div className="divide-y divide-[#EFECE3] text-xs">
          {platforms.map((p) => (
            <div key={p.id} className="py-2.5 flex items-center justify-between gap-4">
              <div>
                <span className="font-semibold text-[#1F2421]">{p.name}</span>
                <span className="text-[#5B625C]"> · {p.region}</span>
              </div>
              <div className="font-mono text-[#5B625C]">
                Requires env: {p.requiredCredentialHint}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
