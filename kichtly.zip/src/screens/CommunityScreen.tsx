import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  Camera,
  ChefHat,
  Clock,
  Heart,
  ImagePlus,
  Pencil,
  Plus,
  Search,
  Share2,
  ShoppingCart,
  Sparkles,
  Trash2,
  Upload,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { IMAGES } from '../data/recipes';
import { formatCurrency } from '../i18n/translations';
import {
  deleteCommunityPostFS,
  ensureCreatorProfileFS,
  publishCommunityPostFS,
  PublishPostInput,
  STARTER_COMMUNITY_CREATORS,
  STARTER_COMMUNITY_POSTS,
  subscribeCommunityFeed,
  toggleCreatorFollowFS,
  togglePostLikeFS,
  updateCreatorProfileFS,
} from '../services/communityService';
import {
  CommunityRecipePost,
  CreatorProfile,
  CuisineType,
  DietType,
  GroceryCategory,
  Recipe,
  RecipeIngredient,
} from '../types/kitchly';
import { FoodImage } from '../components/Logo';

const DEMO_STORAGE_KEY = 'kitchly_community_social_v1';

interface LocalSocialState {
  demoPosts: CommunityRecipePost[];
  demoLikedIds: string[];
  demoFollowedCreatorIds: string[];
  starterLikeDeltas: Record<string, number>;
  starterFollowDeltas: Record<string, number>;
  myBio: string;
  mySpecialty: string;
}

function loadLocalSocialState(): LocalSocialState {
  try {
    const raw = localStorage.getItem(DEMO_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<LocalSocialState>;
      return {
        demoPosts: Array.isArray(parsed.demoPosts) ? parsed.demoPosts : [],
        demoLikedIds: Array.isArray(parsed.demoLikedIds) ? parsed.demoLikedIds : [],
        demoFollowedCreatorIds: Array.isArray(parsed.demoFollowedCreatorIds) ? parsed.demoFollowedCreatorIds : [],
        starterLikeDeltas: parsed.starterLikeDeltas || {},
        starterFollowDeltas: parsed.starterFollowDeltas || {},
        myBio: typeof parsed.myBio === 'string' ? parsed.myBio : '',
        mySpecialty: typeof parsed.mySpecialty === 'string' ? parsed.mySpecialty : '',
      };
    }
  } catch {
    // ignore storage parse failure
  }
  return {
    demoPosts: [],
    demoLikedIds: [],
    demoFollowedCreatorIds: [],
    starterLikeDeltas: {},
    starterFollowDeltas: {},
    myBio: '',
    mySpecialty: '',
  };
}

const IMAGE_PRESETS: { label: string; src: string }[] = [
  { label: 'Momos & Asian Bowl', src: IMAGES.asian },
  { label: 'Indian Home Classic', src: IMAGES.indian },
  { label: 'Steaming Broth & Curry', src: IMAGES.thai },
  { label: 'Morning Tiffin / Toast', src: IMAGES.breakfast },
  { label: 'Mediterranean Bowl', src: IMAGES.mediterranean },
  { label: 'Pasta & Flatbreads', src: IMAGES.italian },
  { label: 'Tacos & Street Food', src: IMAGES.mexican },
];

async function compressDishPhoto(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Please choose a JPG, PNG, or WebP photo file.');
  }
  if (file.size > 15 * 1024 * 1024) {
    throw new Error('Photo is over 15 MB. Please pick a smaller image.');
  }

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Could not read the selected photo.'));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error('Unsupported image format. Please use JPG, PNG, or WebP.'));
    el.src = dataUrl;
  });

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Image processing is unavailable in this browser.');

  const tryEncode = (maxDim: number, quality: number): string => {
    const scale = Math.min(1, maxDim / Math.max(img.width || 1, img.height || 1));
    canvas.width = Math.max(1, Math.round(img.width * scale));
    canvas.height = Math.max(1, Math.round(img.height * scale));
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', quality);
  };

  let out = tryEncode(840, 0.78);
  if (out.length > 180000) out = tryEncode(720, 0.68);
  if (out.length > 180000) out = tryEncode(580, 0.58);
  if (out.length > 260000) {
    throw new Error('Compressed photo is still too large. Please pick another photo.');
  }
  return out;
}

const CUISINE_OPTIONS: CuisineType[] = [
  'Indian',
  'Asian' as CuisineType,
  'Korean',
  'Chinese',
  'Japanese',
  'Thai',
  'Italian',
  'Continental',
  'Mexican',
  'Mediterranean',
  'Middle Eastern',
  'American',
  'French',
  'Spanish',
  'Turkish',
];

const CATEGORIES: GroceryCategory[] = [
  'Vegetables',
  'Fruits',
  'Dairy',
  'Meat and seafood',
  'Grains',
  'Bakery',
  'Spices',
  'Beverages',
];

export function CommunityScreen() {
  const {
    state,
    firebaseUser,
    isCloudSynced,
    addCustomRecipe,
    addRecipeIngredientsToGrocery,
    assignRecipeToCookMode,
    toggleFavoriteRecipe,
    showToast,
  } = useKitchly();

  const [tab, setTab] = useState<'all' | 'following' | 'top' | 'mine' | 'creators'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cuisineFilter, setCuisineFilter] = useState<string>('All');
  const [dietFilter, setDietFilter] = useState<'All' | DietType>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'likes' | 'prep' | 'cost'>('newest');
  const [selectedCreatorUid, setSelectedCreatorUid] = useState<string | null>(null);

  // Cloud Firestore live data
  const [fsCreators, setFsCreators] = useState<CreatorProfile[]>([]);
  const [fsPosts, setFsPosts] = useState<CommunityRecipePost[]>([]);
  const [fsLikedIds, setFsLikedIds] = useState<string[]>([]);
  const [fsFollowedCreatorIds, setFsFollowedCreatorIds] = useState<string[]>([]);

  // Demo & hybrid local fallback state (for unauthenticated demo + starter showcase interactions)
  const [localSocial, setLocalSocial] = useState<LocalSocialState>(() => loadLocalSocialState());

  // Composer Modal state
  const [showComposer, setShowComposer] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [composerError, setComposerError] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [story, setStory] = useState('');
  const [cuisine, setCuisine] = useState('Asian');
  const [dietType, setDietType] = useState<DietType>('Vegetarian');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Chef'>('Medium');
  const [prepTimeMins, setPrepTimeMins] = useState(35);
  const [servings, setServings] = useState(4);
  const [estimatedCostINR, setEstimatedCostINR] = useState(140);
  const [image, setImage] = useState(IMAGES.asian);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const photoInputRef = useRef<HTMLInputElement | null>(null);
  const [ingredients, setIngredients] = useState<RecipeIngredient[]>([
    { name: 'All-Purpose Flour (Maida)', quantity: 2, unit: 'cups', category: 'Grains' },
    { name: 'Finely Chopped Cabbage', quantity: 250, unit: 'g', category: 'Vegetables' },
  ]);
  const [steps, setSteps] = useState<string[]>([
    'Knead dough with a pinch of salt and rest 20 minutes covered.',
    'Prepare your spiced filling, pleat into wrappers cleanly, and steam for 10–12 minutes.',
  ]);
  const [tipsText, setTipsText] = useState('');
  const [tagsText, setTagsText] = useState('Homemade, Step-by-Step');

  // Bio editor state
  const [editingProfile, setEditingProfile] = useState(false);
  const [mySpecialtyInput, setMySpecialtyInput] = useState(localSocial.mySpecialty || 'Momos & Home Comfort Food');
  const [myBioInput, setMyBioInput] = useState(
    localSocial.myBio || 'Love cooking homemade favorites and sharing easy steps so everyone can learn.'
  );

  // Selected Post tutorial viewer state
  const [activePost, setActivePost] = useState<CommunityRecipePost | null>(null);
  const [completedStepIdx, setCompletedStepIdx] = useState<number[]>([]);
  const [checkedIngIdx, setCheckedIngIdx] = useState<number[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(DEMO_STORAGE_KEY, JSON.stringify(localSocial));
    } catch {
      // ignore storage quota errors
    }
  }, [localSocial]);

  useEffect(() => {
    if (!firebaseUser || !isCloudSynced) {
      setFsCreators([]);
      setFsPosts([]);
      setFsLikedIds([]);
      setFsFollowedCreatorIds([]);
      return;
    }

    ensureCreatorProfileFS(firebaseUser.uid, {
      displayName: state.user.name || firebaseUser.displayName || 'Home Cook',
      specialty: localSocial.mySpecialty || 'Home Favorites',
      bio: localSocial.myBio || 'Sharing favorite home-cooked recipes and step-by-step guides.',
      country: state.user.country || 'India',
    }).catch(() => {
      // ignore initial check errors; ErrorBoundary handles critical failures if any
    });

    const unsub = subscribeCommunityFeed(firebaseUser.uid, {
      onCreators: setFsCreators,
      onPosts: setFsPosts,
      onLikedIds: setFsLikedIds,
      onFollowedCreatorIds: setFsFollowedCreatorIds,
    });
    return () => unsub();
  }, [firebaseUser, isCloudSynced]);

  const myCloudCreator = useMemo(
    () => fsCreators.find((c) => c.uid === state.user.id),
    [fsCreators, state.user.id]
  );

  useEffect(() => {
    if (myCloudCreator) {
      if (myCloudCreator.specialty) setMySpecialtyInput(myCloudCreator.specialty);
      if (myCloudCreator.bio) setMyBioInput(myCloudCreator.bio);
    }
  }, [myCloudCreator?.uid]);

  // Combine real Firestore posts/creators with curated starter showcase posts
  const allCreators: CreatorProfile[] = useMemo(() => {
    const map = new Map<string, CreatorProfile>();
    STARTER_COMMUNITY_CREATORS.forEach((c) => {
      const delta = localSocial.starterFollowDeltas[c.uid] || 0;
      map.set(c.uid, {
        ...c,
        followersCount: Math.max(0, c.followersCount + delta),
      });
    });
    fsCreators.forEach((c) => map.set(c.uid, c));

    if (!map.has(state.user.id)) {
      map.set(state.user.id, {
        uid: state.user.id,
        displayName: state.user.name || 'My Kitchen',
        bio: myBioInput,
        specialty: mySpecialtyInput,
        country: state.user.country || 'India',
        followersCount: 0,
        postsCount: localSocial.demoPosts.filter((p) => p.authorId === state.user.id).length,
        isPublic: true,
        isDemoCreator: !isCloudSynced,
      });
    }
    return Array.from(map.values());
  }, [fsCreators, localSocial.starterFollowDeltas, localSocial.demoPosts, state.user, myBioInput, mySpecialtyInput, isCloudSynced]);

  const allPosts: CommunityRecipePost[] = useMemo(() => {
    const map = new Map<string, CommunityRecipePost>();
    STARTER_COMMUNITY_POSTS.forEach((p) => {
      const delta = localSocial.starterLikeDeltas[p.id] || 0;
      map.set(p.id, {
        ...p,
        likesCount: Math.max(0, p.likesCount + delta),
      });
    });
    localSocial.demoPosts.forEach((p) => {
      const delta = localSocial.starterLikeDeltas[p.id] || 0;
      map.set(p.id, {
        ...p,
        likesCount: Math.max(0, p.likesCount + delta),
      });
    });
    fsPosts.forEach((p) => map.set(p.id, p));
    return Array.from(map.values());
  }, [fsPosts, localSocial.demoPosts, localSocial.starterLikeDeltas]);

  const likedPostIds = useMemo(
    () => new Set([...fsLikedIds, ...localSocial.demoLikedIds]),
    [fsLikedIds, localSocial.demoLikedIds]
  );

  const followedCreatorIds = useMemo(
    () => new Set([...fsFollowedCreatorIds, ...localSocial.demoFollowedCreatorIds]),
    [fsFollowedCreatorIds, localSocial.demoFollowedCreatorIds]
  );

  const filteredPosts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = allPosts.filter((p) => {
      if (tab === 'following' && !followedCreatorIds.has(p.authorId)) return false;
      if (tab === 'mine' && p.authorId !== state.user.id) return false;
      if (selectedCreatorUid && p.authorId !== selectedCreatorUid) return false;
      if (cuisineFilter !== 'All' && p.cuisine.toLowerCase() !== cuisineFilter.toLowerCase()) return false;
      if (dietFilter !== 'All' && p.dietType !== dietFilter) return false;
      if (q) {
        const hay = `${p.title} ${p.story} ${p.authorName} ${p.cuisine} ${p.tags.join(' ')} ${p.ingredients.map((i) => i.name).join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const effectiveSort = tab === 'top' && sortBy === 'newest' ? 'likes' : sortBy;
    return [...list].sort((a, b) => {
      switch (effectiveSort) {
        case 'likes':
          return b.likesCount - a.likesCount;
        case 'prep':
          return a.prepTimeMins - b.prepTimeMins;
        case 'cost':
          return a.estimatedCostINR - b.estimatedCostINR;
        case 'newest':
        default:
          return new Date(b.createdAtISO).getTime() - new Date(a.createdAtISO).getTime();
      }
    });
  }, [allPosts, tab, followedCreatorIds, state.user.id, selectedCreatorUid, cuisineFilter, dietFilter, searchQuery, sortBy]);

  const loadMomoTemplate = () => {
    setTitle('My Homemade Crispy & Steamed Chicken/Veg Momos');
    setStory(
      'I love making momos for family and friends! Sharing my simple wrapper dough ratio, juicy filling mix, and crisp pan-steamed finish so anyone can make them at home.'
    );
    setCuisine('Asian');
    setDietType('Vegetarian');
    setDifficulty('Medium');
    setPrepTimeMins(35);
    setServings(4);
    setEstimatedCostINR(140);
    setImage(IMAGES.asian);
    setIngredients([
      { name: 'All-Purpose Flour (Maida)', quantity: 2, unit: 'cups', category: 'Grains' },
      { name: 'Finely Chopped Cabbage', quantity: 250, unit: 'g', category: 'Vegetables' },
      { name: 'Onion & Spring Onion Greens', quantity: 100, unit: 'g', category: 'Vegetables' },
      { name: 'Crumbled Paneer or Minced Tofu', quantity: 150, unit: 'g', category: 'Dairy' },
      { name: 'Ginger, Garlic & Black Pepper', quantity: 2, unit: 'tbsp', category: 'Spices' },
    ]);
    setSteps([
      'Knead flour with ½ tsp salt and cool water into a firm dough. Rest covered for 20 minutes.',
      'Combine finely chopped cabbage, crumbled paneer, ginger-garlic paste, spring onions, soy sauce, salt, and 1 tbsp warm oil.',
      'Roll small dough portions into thin 3.5-inch rounds, place 1 tbsp filling in the center, and pleat around the edges to seal tightly.',
      'Steam over brisk boiling water for 10–12 minutes until glossy and tender, then serve hot with spicy chili-tomato chutney.',
    ]);
    setTipsText('Keep the center slightly thicker than the edges when rolling so wrappers do not tear.');
    setTagsText('Momos, Step-by-Step, Homemade');
    showToast('Loaded Momo recipe template — customize and post!');
  };

  const handlePublishPost = async (e: React.FormEvent) => {
    e.preventDefault();
    setComposerError(null);

    if (title.trim().length < 2) {
      setComposerError('Please enter a recipe title (at least 2 characters).');
      return;
    }
    if (story.trim().length < 5) {
      setComposerError('Share a quick note about why you love this recipe or how it turns out.');
      return;
    }
    const cleanSteps = steps.map((s) => s.trim()).filter(Boolean);
    if (cleanSteps.length === 0) {
      setComposerError('Please include at least 1 cooking step so others can learn.');
      return;
    }
    const cleanIngredients = ingredients.filter((i) => i.name.trim());
    if (cleanIngredients.length === 0) {
      setComposerError('Please include at least 1 ingredient.');
      return;
    }

    const tipsList = tipsText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 10);
    const tagsList = tagsText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 12);

    const payload: PublishPostInput = {
      title: title.trim(),
      story: story.trim(),
      cuisine: cuisine.trim() || 'Indian',
      dietType,
      difficulty,
      prepTimeMins: Math.max(1, Number(prepTimeMins) || 25),
      servings: Math.max(1, Number(servings) || 2),
      estimatedCostINR: Math.max(0, Number(estimatedCostINR) || 100),
      image: image.trim() || IMAGES.asian,
      ingredients: cleanIngredients,
      steps: cleanSteps,
      tips: tipsList,
      tags: tagsList,
    };

    setPublishing(true);
    try {
      if (firebaseUser && isCloudSynced) {
        await publishCommunityPostFS(
          firebaseUser.uid,
          {
            displayName: state.user.name || firebaseUser.displayName || 'Home Cook',
            specialty: mySpecialtyInput,
            bio: myBioInput,
            country: state.user.country || 'India',
          },
          payload
        );
      } else {
        const localPost: CommunityRecipePost = {
          id: `demo-user-post-${Date.now()}`,
          authorId: state.user.id,
          authorName: state.user.name || 'My Kitchen',
          authorSpecialty: mySpecialtyInput,
          title: payload.title,
          story: payload.story,
          cuisine: payload.cuisine,
          dietType: payload.dietType,
          difficulty: payload.difficulty,
          prepTimeMins: payload.prepTimeMins,
          servings: payload.servings,
          estimatedCostINR: payload.estimatedCostINR,
          image: payload.image,
          ingredients: payload.ingredients,
          steps: payload.steps,
          tips: payload.tips,
          tags: payload.tags,
          likesCount: 0,
          isPublic: true,
          createdAtISO: new Date().toISOString(),
          isDemoPost: true,
        };
        setLocalSocial((prev) => ({
          ...prev,
          demoPosts: [localPost, ...prev.demoPosts],
        }));
      }

      setShowComposer(false);
      setTitle('');
      setStory('');
      setImage(IMAGES.asian);
      setImageUrlInput('');
      setPhotoError(null);
      setTab('all');
      setSelectedCreatorUid(null);
      showToast(`Shared "${payload.title}" with Kitchly Community!`);
    } catch (err) {
      setComposerError(err instanceof Error ? err.message : 'Could not publish recipe right now.');
    } finally {
      setPublishing(false);
    }
  };

  const handleToggleLike = async (post: CommunityRecipePost) => {
    const isLiked = likedPostIds.has(post.id);
    if (post.isDemoPost || !firebaseUser || !isCloudSynced) {
      setLocalSocial((prev) => {
        const nextLiked = isLiked
          ? prev.demoLikedIds.filter((id) => id !== post.id)
          : [...prev.demoLikedIds, post.id];
        const prevDelta = prev.starterLikeDeltas[post.id] || 0;
        return {
          ...prev,
          demoLikedIds: nextLiked,
          starterLikeDeltas: {
            ...prev.starterLikeDeltas,
            [post.id]: prevDelta + (isLiked ? -1 : 1),
          },
        };
      });
      if (activePost?.id === post.id) {
        setActivePost((prev) =>
          prev ? { ...prev, likesCount: Math.max(0, prev.likesCount + (isLiked ? -1 : 1)) } : null
        );
      }
      return;
    }

    try {
      await togglePostLikeFS(post.id, firebaseUser.uid, isLiked);
    } catch {
      showToast('Could not update like right now. Please try again.');
    }
  };

  const handleToggleFollow = async (creatorUid: string, creatorName: string) => {
    if (creatorUid === state.user.id) return;
    const isFollowing = followedCreatorIds.has(creatorUid);
    const isStarter = STARTER_COMMUNITY_CREATORS.some((c) => c.uid === creatorUid);

    if (isStarter || !firebaseUser || !isCloudSynced) {
      setLocalSocial((prev) => {
        const nextFollowed = isFollowing
          ? prev.demoFollowedCreatorIds.filter((id) => id !== creatorUid)
          : [...prev.demoFollowedCreatorIds, creatorUid];
        const prevDelta = prev.starterFollowDeltas[creatorUid] || 0;
        return {
          ...prev,
          demoFollowedCreatorIds: nextFollowed,
          starterFollowDeltas: {
            ...prev.starterFollowDeltas,
            [creatorUid]: prevDelta + (isFollowing ? -1 : 1),
          },
        };
      });
      showToast(isFollowing ? `Unfollowed ${creatorName}.` : `Following ${creatorName}!`);
      return;
    }

    try {
      await toggleCreatorFollowFS(
        creatorUid,
        firebaseUser.uid,
        state.user.name || firebaseUser.displayName || 'Kitchen Cook',
        isFollowing
      );
      showToast(isFollowing ? `Unfollowed ${creatorName}.` : `Following ${creatorName}!`);
    } catch {
      showToast('Could not update follow status right now.');
    }
  };

  const handleDeletePost = async (post: CommunityRecipePost) => {
    if (post.authorId !== state.user.id) return;
    if (post.isDemoPost || !firebaseUser || !isCloudSynced) {
      setLocalSocial((prev) => ({
        ...prev,
        demoPosts: prev.demoPosts.filter((p) => p.id !== post.id),
      }));
    } else {
      try {
        await deleteCommunityPostFS(firebaseUser.uid, post.id);
      } catch {
        showToast('Could not delete recipe right now.');
        return;
      }
    }
    if (activePost?.id === post.id) setActivePost(null);
    showToast(`Deleted "${post.title}".`);
  };

  const handleSaveCreatorBio = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalSocial((prev) => ({
      ...prev,
      myBio: myBioInput.trim(),
      mySpecialty: mySpecialtyInput.trim(),
    }));
    if (firebaseUser && isCloudSynced) {
      try {
        await updateCreatorProfileFS(firebaseUser.uid, {
          displayName: state.user.name || firebaseUser.displayName || 'Home Cook',
          specialty: mySpecialtyInput.trim(),
          bio: myBioInput.trim(),
          country: state.user.country || 'India',
        });
      } catch {
        showToast('Saved locally; cloud update failed.');
      }
    }
    setEditingProfile(false);
    showToast('Updated your community cook profile!');
  };

  const postToRecipe = (post: CommunityRecipePost): Recipe => ({
    id: `comm-${post.id}`,
    title: post.title,
    cuisine: post.cuisine,
    dietType: post.dietType,
    prepTimeMins: post.prepTimeMins,
    difficulty: post.difficulty,
    servings: post.servings,
    estimatedCostINR: post.estimatedCostINR,
    image: post.image,
    description: post.story,
    ingredients: post.ingredients,
    instructions: post.steps,
    nutrition: { calories: 380, protein: 14, carbs: 46, fat: 12 },
    allergens: [],
    tags: post.tags,
    isAiGenerated: false,
  });

  // Step-by-Step Learning / Post Viewer View
  if (activePost) {
    const livePost = allPosts.find((p) => p.id === activePost.id) || activePost;
    const isLiked = likedPostIds.has(livePost.id);
    const isFollowing = followedCreatorIds.has(livePost.authorId);
    const isOwn = livePost.authorId === state.user.id;
    const creatorInfo = allCreators.find((c) => c.uid === livePost.authorId);
    const pantryLower = state.pantry.map((p) => p.name.toLowerCase());
    const stepsCompletedPct = Math.round(
      (completedStepIdx.length / Math.max(1, livePost.steps.length)) * 100
    );

    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              setActivePost(null);
              setCompletedStepIdx([]);
              setCheckedIngIdx([]);
            }}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-[#5B625C] hover:text-[#1F2421]"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Community Feed</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleToggleLike(livePost)}
              className={`px-3.5 py-2 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 transition-colors ${
                isLiked
                  ? 'bg-[#FDF2EC] border-[#D97736] text-[#D97736]'
                  : 'bg-white border-[#E6E3DA] text-[#1F2421] hover:bg-[#FAF9F5]'
              }`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
              <span className="tabular-nums">{livePost.likesCount} Likes</span>
            </button>
            {isOwn && (
              <button
                onClick={() => handleDeletePost(livePost)}
                className="px-3 py-2 rounded-xl border border-[#E6E3DA] text-xs font-medium text-[#D97736] hover:bg-[#FDF2EC] inline-flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            )}
          </div>
        </div>

        {/* Hero Card */}
        <div className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden grid md:grid-cols-12">
          <div className="md:col-span-5 min-h-[250px]">
            <FoodImage src={livePost.image} alt={livePost.title} className="w-full h-full object-cover" />
          </div>
          <div className="md:col-span-7 p-6 lg:p-7 flex flex-col justify-between space-y-4">
            <div className="space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-[#4A7C59]/15 text-[#4A7C59] font-display font-bold flex items-center justify-center">
                    {livePost.authorName.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#1F2421]">{livePost.authorName}</p>
                    <p className="text-xs text-[#5B625C]">
                      {livePost.authorSpecialty || 'Home Cook'} · {creatorInfo?.followersCount ?? 0} followers
                    </p>
                  </div>
                </div>
                {!isOwn && (
                  <button
                    onClick={() => handleToggleFollow(livePost.authorId, livePost.authorName)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 ${
                      isFollowing
                        ? 'bg-[#F3F1EA] text-[#4A7C59] border border-[#4A7C59]/30'
                        : 'bg-[#4A7C59] text-white hover:bg-[#3D684A]'
                    }`}
                  >
                    {isFollowing ? <UserCheck className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                    <span>{isFollowing ? 'Following' : 'Follow'}</span>
                  </button>
                )}
              </div>

              <p className="text-xs font-medium text-[#4A7C59]">
                {livePost.cuisine} · {livePost.dietType} · {livePost.difficulty} · {livePost.prepTimeMins} min · Serves {livePost.servings}
              </p>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">{livePost.title}</h2>
              <p className="text-sm text-[#5B625C] leading-relaxed">{livePost.story}</p>
            </div>

            <div className="flex flex-wrap gap-2 pt-2 border-t border-[#EFECE3]">
              <button
                onClick={() => {
                  const rec = postToRecipe(livePost);
                  addCustomRecipe(rec);
                  addRecipeIngredientsToGrocery(rec, 1);
                }}
                className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span>Add Ingredients to Cart</span>
              </button>
              <button
                onClick={() => {
                  const rec = postToRecipe(livePost);
                  addCustomRecipe(rec);
                  assignRecipeToCookMode(rec, 'Dinner');
                }}
                className="px-4 py-2.5 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7] inline-flex items-center gap-1.5"
              >
                <ChefHat className="w-3.5 h-3.5 text-[#4A7C59]" />
                <span>Send to Cook Mode</span>
              </button>
              <button
                onClick={() => {
                  const rec = postToRecipe(livePost);
                  addCustomRecipe(rec);
                  toggleFavoriteRecipe(rec);
                }}
                className="px-3.5 py-2.5 rounded-xl border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] hover:bg-[#FAF9F5]"
              >
                Save to Recipes
              </button>
            </div>
          </div>
        </div>

        {/* Ingredients + Interactive Step-by-Step Learner Grid */}
        <div className="grid md:grid-cols-12 gap-6">
          <div className="md:col-span-5 space-y-5">
            <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-semibold text-[#1F2421]">Ingredients</h3>
                <span className="text-xs font-mono text-[#5B625C] tabular-nums">
                  Est. {formatCurrency(livePost.estimatedCostINR, state.user.currency)}
                </span>
              </div>
              <ul className="divide-y divide-[#EFECE3]">
                {livePost.ingredients.map((ing, idx) => {
                  const checked = checkedIngIdx.includes(idx);
                  const inPantry = pantryLower.some(
                    (p) => p.includes(ing.name.toLowerCase()) || ing.name.toLowerCase().includes(p)
                  );
                  return (
                    <li key={idx} className="py-2.5 flex items-center justify-between gap-3 text-sm">
                      <label className="flex items-start gap-2.5 cursor-pointer flex-1">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() =>
                            setCheckedIngIdx((prev) =>
                              prev.includes(idx) ? prev.filter((x) => x !== idx) : [...prev, idx]
                            )
                          }
                          className="mt-1 accent-[#4A7C59]"
                        />
                        <div>
                          <span className={`font-medium ${checked ? 'line-through text-[#8D948E]' : 'text-[#1F2421]'}`}>
                            {ing.name}
                          </span>
                          <p className={`text-[11px] ${inPantry ? 'text-[#4A7C59]' : 'text-[#5B625C]'}`}>
                            {inPantry ? 'Already in your Pantry' : ing.category}
                          </p>
                        </div>
                      </label>
                      <span className="font-mono text-xs text-[#5B625C] tabular-nums shrink-0">
                        {ing.quantity} {ing.unit}
                      </span>
                    </li>
                  );
                })}
              </ul>
            </div>

            {livePost.tips.length > 0 && (
              <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-2xl p-5 space-y-2">
                <p className="text-xs font-semibold text-[#D97736] inline-flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{livePost.authorName}’s Cooking Tips</span>
                </p>
                <ul className="space-y-1.5 text-xs text-[#1F2421] leading-relaxed">
                  {livePost.tips.map((tip, i) => (
                    <li key={i}>• {tip}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="md:col-span-7 bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-lg font-semibold text-[#1F2421]">
                  Learn Step-by-Step ({livePost.steps.length} steps)
                </h3>
                <p className="text-xs text-[#5B625C]">Tap any step as you cook to track your progress</p>
              </div>
              <span className="text-xs font-mono font-semibold text-[#4A7C59] tabular-nums">
                {stepsCompletedPct}% done
              </span>
            </div>
            <div className="h-1.5 bg-[#EFECE3] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#4A7C59] transition-all duration-300"
                style={{ width: `${stepsCompletedPct}%` }}
              />
            </div>

            <ol className="space-y-3">
              {livePost.steps.map((stepText, idx) => {
                const done = completedStepIdx.includes(idx);
                return (
                  <li key={idx}>
                    <button
                      type="button"
                      onClick={() =>
                        setCompletedStepIdx((prev) =>
                          prev.includes(idx) ? prev.filter((x) => x !== idx) : [...prev, idx]
                        )
                      }
                      className={`w-full text-left p-4 rounded-xl border flex gap-3.5 items-start transition-colors ${
                        done
                          ? 'bg-[#F3F1EA] border-[#4A7C59]/40 text-[#5B625C]'
                          : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-white text-[#1F2421]'
                      }`}
                    >
                      <span
                        className={`w-7 h-7 rounded-lg font-mono text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5 ${
                          done ? 'bg-[#4A7C59] text-white' : 'bg-white border border-[#E6E3DA] text-[#4A7C59]'
                        }`}
                      >
                        {done ? '✓' : idx + 1}
                      </span>
                      <span className={`text-sm leading-relaxed ${done ? 'line-through' : ''}`}>
                        {stepText}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ol>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#4A7C59] mb-1">KITCHLY KITCHEN COMMUNITY</p>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">
            Share your recipes, learn steps & follow home cooks
          </h2>
          <p className="text-sm text-[#5B625C] mt-1">
            Post signature dishes like handmade momos with clear cooking steps, follow creators you love, and cook together.
          </p>
        </div>
        <button
          onClick={() => setShowComposer(true)}
          className="px-5 py-3 rounded-xl bg-[#D97736] text-white text-sm font-semibold hover:opacity-95 inline-flex items-center gap-2 shrink-0 self-start sm:self-auto"
        >
          <Share2 className="w-4 h-4" />
          <span>Share a Recipe</span>
        </button>
      </div>

      {/* Tabs + Stats Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex flex-wrap bg-[#F3F1EA] p-1 rounded-xl gap-1">
          {[
            { id: 'all' as const, label: `All Recipes (${allPosts.length})` },
            { id: 'following' as const, label: `Following (${followedCreatorIds.size})` },
            { id: 'top' as const, label: 'Most Liked' },
            { id: 'mine' as const, label: 'My Shared Recipes' },
            { id: 'creators' as const, label: `Creators (${allCreators.length})` },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setTab(item.id);
                if (item.id !== 'all') setSelectedCreatorUid(null);
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors ${
                tab === item.id ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C] hover:text-[#1F2421]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {selectedCreatorUid && (
          <div className="inline-flex items-center gap-2 bg-[#4A7C59]/10 border border-[#4A7C59]/30 px-3 py-1.5 rounded-xl text-xs font-medium text-[#1F2421]">
            <span>
              Viewing recipes by{' '}
              <strong>{allCreators.find((c) => c.uid === selectedCreatorUid)?.displayName || 'Creator'}</strong>
            </span>
            <button onClick={() => setSelectedCreatorUid(null)} aria-label="Clear creator filter">
              <X className="w-3.5 h-3.5 text-[#5B625C]" />
            </button>
          </div>
        )}
      </div>

      {/* Creator Profile Banner when in "My Shared Recipes" */}
      {tab === 'mine' && (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-full bg-[#4A7C59] text-white font-display text-lg font-bold flex items-center justify-center shrink-0">
                {(state.user.name || 'K').charAt(0).toUpperCase()}
              </div>
              <div>
                <h3 className="font-display text-lg font-semibold text-[#1F2421]">
                  {state.user.name || state.user.householdName}
                </h3>
                <p className="text-xs font-medium text-[#4A7C59]">{mySpecialtyInput}</p>
                <p className="text-sm text-[#5B625C] mt-1">{myBioInput}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right text-xs tabular-nums">
                <p className="font-semibold text-[#1F2421]">
                  {myCloudCreator?.followersCount ?? 0} Followers
                </p>
                <p className="text-[#5B625C]">
                  {allPosts.filter((p) => p.authorId === state.user.id).length} Recipes Shared
                </p>
              </div>
              <button
                onClick={() => setEditingProfile(!editingProfile)}
                className="px-3 py-2 rounded-xl border border-[#E6E3DA] text-xs font-semibold hover:bg-[#FAF9F5] inline-flex items-center gap-1"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>Edit Bio</span>
              </button>
            </div>
          </div>

          {editingProfile && (
            <form onSubmit={handleSaveCreatorBio} className="pt-4 border-t border-[#EFECE3] grid sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1">Your Cooking Specialty</label>
                <input
                  value={mySpecialtyInput}
                  onChange={(e) => setMySpecialtyInput(e.target.value)}
                  maxLength={80}
                  placeholder="e.g. Momos, Curries & Quick Dinners"
                  className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1">Short Cook Bio</label>
                <input
                  value={myBioInput}
                  onChange={(e) => setMyBioInput(e.target.value)}
                  maxLength={280}
                  placeholder="What do you love cooking and teaching?"
                  className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
                />
              </div>
              <div className="sm:col-span-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingProfile(false)}
                  className="px-3.5 py-2 rounded-xl border border-[#E6E3DA] text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold"
                >
                  Save Profile
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Creators Directory Tab */}
      {tab === 'creators' ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {allCreators.map((c) => {
            const isSelf = c.uid === state.user.id;
            const isFollowing = followedCreatorIds.has(c.uid);
            const authorPostsCount = allPosts.filter((p) => p.authorId === c.uid).length;
            return (
              <div key={c.uid} className="bg-white border border-[#E6E3DA] rounded-2xl p-5 flex flex-col justify-between gap-4">
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-full bg-[#4A7C59]/15 text-[#4A7C59] font-display font-bold flex items-center justify-center shrink-0">
                        {c.displayName.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-display text-base font-semibold text-[#1F2421] truncate">
                          {c.displayName} {isSelf && '(You)'}
                        </h3>
                        <p className="text-xs text-[#4A7C59] truncate">{c.specialty || 'Home Cook'}</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-[#5B625C] line-clamp-3 leading-relaxed">{c.bio}</p>
                </div>

                <div className="pt-3 border-t border-[#EFECE3] flex items-center justify-between gap-2">
                  <span className="text-xs text-[#5B625C] tabular-nums">
                    <strong className="text-[#1F2421]">{c.followersCount}</strong> followers ·{' '}
                    <strong className="text-[#1F2421]">{authorPostsCount}</strong> recipes
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setSelectedCreatorUid(c.uid);
                        setTab('all');
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-[#F3F1EA] text-xs font-medium text-[#1F2421] hover:bg-[#E7E3D7]"
                    >
                      Recipes
                    </button>
                    {!isSelf && (
                      <button
                        onClick={() => handleToggleFollow(c.uid, c.displayName)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 ${
                          isFollowing
                            ? 'bg-white border border-[#4A7C59] text-[#4A7C59]'
                            : 'bg-[#4A7C59] text-white'
                        }`}
                      >
                        {isFollowing ? 'Following' : 'Follow'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <>
          {/* Filter & Sort Controls for Feed */}
          <div className="bg-white border border-[#E6E3DA] rounded-2xl p-4 grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="relative lg:col-span-2">
              <Search className="w-4 h-4 text-[#5B625C] absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                aria-label="Search community recipes"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search momos, chutney, cook name, steps..."
                className="w-full h-10 pl-9 pr-3 rounded-xl border border-[#E6E3DA] text-sm"
              />
            </div>

            <select
              aria-label="Filter community cuisine"
              value={cuisineFilter}
              onChange={(e) => setCuisineFilter(e.target.value)}
              className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="All">All Cuisines</option>
              {CUISINE_OPTIONS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter community diet"
              value={dietFilter}
              onChange={(e) => setDietFilter(e.target.value as 'All' | DietType)}
              className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="All">All Diet Types</option>
              <option value="Vegetarian">Vegetarian</option>
              <option value="Vegan">Vegan</option>
              <option value="Eggetarian">Eggetarian</option>
              <option value="Pescatarian">Pescatarian</option>
              <option value="Non-vegetarian">Non-vegetarian</option>
            </select>

            <select
              aria-label="Sort community recipes"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
            >
              <option value="newest">Sort: Newest First</option>
              <option value="likes">Sort: Most Liked</option>
              <option value="prep">Sort: Quickest Prep</option>
              <option value="cost">Sort: Lowest Cost</option>
            </select>
          </div>

          {/* Feed Results */}
          {filteredPosts.length === 0 ? (
            <div className="bg-white border border-[#E6E3DA] rounded-2xl p-10 text-center space-y-3">
              <Users className="w-8 h-8 text-[#4A7C59] mx-auto" />
              <h3 className="font-display text-lg font-semibold text-[#1F2421]">
                {tab === 'following'
                  ? 'You are not following any cooks yet'
                  : tab === 'mine'
                  ? 'You haven’t shared a recipe yet'
                  : 'No community recipes match your filter'}
              </h3>
              <p className="text-sm text-[#5B625C] max-w-md mx-auto">
                {tab === 'following'
                  ? 'Browse All Recipes or Creators and tap Follow on cooks whose style you love.'
                  : tab === 'mine'
                  ? 'Share your signature recipe—like homemade momos, weekend curry, or quick snacks—with step-by-step instructions for others to learn!'
                  : 'Try clearing the search or cuisine filter.'}
              </p>
              <div className="flex flex-wrap justify-center gap-2 pt-1">
                {tab === 'mine' ? (
                  <button
                    onClick={() => setShowComposer(true)}
                    className="px-5 py-2.5 rounded-xl bg-[#D97736] text-white text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Share Your First Recipe</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setTab('all');
                      setSearchQuery('');
                      setCuisineFilter('All');
                      setDietFilter('All');
                      setSelectedCreatorUid(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold"
                  >
                    Explore All Recipes
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-5">
              {filteredPosts.map((post) => {
                const isLiked = likedPostIds.has(post.id);
                const isFollowing = followedCreatorIds.has(post.authorId);
                const isOwn = post.authorId === state.user.id;
                return (
                  <article
                    key={post.id}
                    className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden flex flex-col"
                  >
                    {/* Author Row */}
                    <div className="px-5 py-3.5 border-b border-[#EFECE3] flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => setSelectedCreatorUid(post.authorId)}
                        className="flex items-center gap-2.5 text-left min-w-0 group"
                      >
                        <div className="w-8 h-8 rounded-full bg-[#4A7C59]/15 text-[#4A7C59] font-display text-sm font-bold flex items-center justify-center shrink-0">
                          {post.authorName.charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#1F2421] truncate group-hover:text-[#4A7C59]">
                            {post.authorName} {isOwn && '(You)'}
                          </p>
                          <p className="text-[11px] text-[#5B625C] truncate">
                            {post.authorSpecialty || 'Home Cook'}
                          </p>
                        </div>
                      </button>

                      {!isOwn && (
                        <button
                          onClick={() => handleToggleFollow(post.authorId, post.authorName)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1 shrink-0 ${
                            isFollowing
                              ? 'bg-[#F3F1EA] text-[#4A7C59]'
                              : 'bg-[#4A7C59] text-white hover:bg-[#3D684A]'
                          }`}
                        >
                          {isFollowing ? <UserCheck className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                          <span>{isFollowing ? 'Following' : 'Follow'}</span>
                        </button>
                      )}
                    </div>

                    {/* Photo */}
                    <button
                      type="button"
                      onClick={() => {
                        setActivePost(post);
                        setCompletedStepIdx([]);
                        setCheckedIngIdx([]);
                      }}
                      className="h-48 w-full overflow-hidden text-left relative group"
                    >
                      <FoodImage
                        src={post.image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform"
                      />
                    </button>

                    {/* Content */}
                    <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                      <div className="space-y-2">
                        <p className="text-xs font-medium text-[#4A7C59]">
                          {post.cuisine} · {post.dietType} · {post.difficulty} · {post.steps.length} steps
                        </p>
                        <h3
                          onClick={() => {
                            setActivePost(post);
                            setCompletedStepIdx([]);
                            setCheckedIngIdx([]);
                          }}
                          className="font-display text-lg font-semibold text-[#1F2421] hover:text-[#4A7C59] cursor-pointer"
                        >
                          {post.title}
                        </h3>
                        <p className="text-xs text-[#5B625C] line-clamp-2 leading-relaxed">{post.story}</p>

                        {/* Step Preview Pill Strip */}
                        <div className="pt-1 flex flex-wrap gap-1.5">
                          {post.tags.slice(0, 3).map((tag) => (
                            <span
                              key={tag}
                              className="px-2 py-0.5 rounded-md bg-[#FAF9F5] border border-[#E6E3DA] text-[11px] text-[#5B625C]"
                            >
                              #{tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-[#EFECE3] flex items-center justify-between gap-2">
                        <div className="flex items-center gap-3 text-xs text-[#5B625C] tabular-nums">
                          <button
                            type="button"
                            onClick={() => handleToggleLike(post)}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-colors ${
                              isLiked
                                ? 'bg-[#FDF2EC] border-[#D97736] text-[#D97736] font-semibold'
                                : 'bg-white border-[#E6E3DA] text-[#5B625C] hover:text-[#1F2421]'
                            }`}
                          >
                            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
                            <span>{post.likesCount}</span>
                          </button>
                          <span className="inline-flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" />
                            {post.prepTimeMins}m
                          </span>
                          <span className="font-semibold text-[#1F2421]">
                            {formatCurrency(post.estimatedCostINR, state.user.currency)}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setActivePost(post);
                            setCompletedStepIdx([]);
                            setCheckedIngIdx([]);
                          }}
                          className="px-3.5 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>Learn Steps</span>
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Share a Recipe Composer Modal */}
      {showComposer && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="bg-white border border-[#E6E3DA] rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl">
            <div className="sticky top-0 bg-white border-b border-[#EFECE3] px-6 py-4 flex items-center justify-between gap-3 z-10">
              <div>
                <h3 className="font-display text-lg font-bold text-[#1F2421]">Share a Recipe with Kitchly</h3>
                <p className="text-xs text-[#5B625C]">
                  Post your dish, steps & tips so people can follow you and learn how to cook it.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowComposer(false)}
                aria-label="Close composer"
                className="p-2 rounded-lg hover:bg-[#F3F1EA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePublishPost} className="p-6 space-y-5">
              <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-3 flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs text-[#5B625C]">
                  Need inspiration? Start from an example (like handmade momos) and customize it!
                </span>
                <button
                  type="button"
                  onClick={loadMomoTemplate}
                  className="px-3 py-1.5 rounded-lg bg-[#4A7C59]/10 text-[#4A7C59] text-xs font-semibold hover:bg-[#4A7C59]/20"
                >
                  Load Momo Example
                </button>
              </div>

              {composerError && (
                <div className="bg-[#FDF2EC] border border-[#D97736]/40 text-[#9A4A18] rounded-xl p-3 text-xs font-medium">
                  {composerError}
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Recipe Title *</label>
                  <input
                    required
                    maxLength={140}
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Homemade Steamed Paneer Momos with Fiery Chutney"
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Your Story / Note *</label>
                  <textarea
                    required
                    maxLength={600}
                    rows={3}
                    value={story}
                    onChange={(e) => setStory(e.target.value)}
                    placeholder="Tell everyone why you love cooking this and any secret trick (e.g. rolling thin edges for momos)..."
                    className="w-full p-3 rounded-xl border border-[#E6E3DA] text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Cuisine</label>
                  <select
                    value={cuisine}
                    onChange={(e) => setCuisine(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                  >
                    {CUISINE_OPTIONS.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Diet Type</label>
                  <select
                    value={dietType}
                    onChange={(e) => setDietType(e.target.value as DietType)}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                  >
                    {(['Vegetarian', 'Vegan', 'Eggetarian', 'Pescatarian', 'Non-vegetarian', 'Flexitarian'] as DietType[]).map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Difficulty</label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as 'Easy' | 'Medium' | 'Chef')}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                  >
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Chef">Chef</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Prep Time (min)</label>
                  <input
                    type="number"
                    min={1}
                    max={360}
                    value={prepTimeMins}
                    onChange={(e) => setPrepTimeMins(Number(e.target.value) || 20)}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Servings</label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={servings}
                    onChange={(e) => setServings(Number(e.target.value) || 2)}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Est. Cost (INR)</label>
                  <input
                    type="number"
                    min={0}
                    value={estimatedCostINR}
                    onChange={(e) => setEstimatedCostINR(Number(e.target.value) || 0)}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
              </div>

              {/* Dish Photo Upload, URL & Preset Picker */}
              <div className="space-y-3 bg-[#FAF9F5] border border-[#E6E3DA] rounded-2xl p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-[#1F2421]">
                      Dish Photo (Upload Your Own or Pick a Style)
                    </label>
                    <p className="text-[11px] text-[#5B625C]">
                      Upload a photo of your dish from your phone or computer — auto-optimized for fast loading.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        e.target.value = '';
                        if (!file) return;
                        setPhotoError(null);
                        setUploadingPhoto(true);
                        try {
                          const compressed = await compressDishPhoto(file);
                          setImage(compressed);
                          setImageUrlInput('');
                          showToast('Dish photo uploaded and ready!');
                        } catch (err) {
                          setPhotoError(err instanceof Error ? err.message : 'Could not upload photo.');
                        } finally {
                          setUploadingPhoto(false);
                        }
                      }}
                    />
                    <button
                      type="button"
                      disabled={uploadingPhoto}
                      onClick={() => photoInputRef.current?.click()}
                      className="px-3.5 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5 disabled:opacity-60"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingPhoto ? 'Optimizing...' : 'Upload Photo'}</span>
                    </button>
                  </div>
                </div>

                {photoError && (
                  <p className="text-xs text-[#9A4A18] bg-[#FDF2EC] border border-[#D97736]/30 rounded-lg px-3 py-2">
                    {photoError}
                  </p>
                )}

                <div className="grid sm:grid-cols-12 gap-3 items-center">
                  <div className="sm:col-span-5 h-32 rounded-xl overflow-hidden border border-[#E6E3DA] bg-white relative group">
                    <FoodImage src={image} alt={title || 'Dish preview'} className="w-full h-full object-cover" />
                    <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md bg-black/65 text-white text-[10px] font-medium inline-flex items-center gap-1">
                      <Camera className="w-3 h-3" />
                      {image.startsWith('data:image/') ? 'Uploaded photo' : 'Cover preview'}
                    </span>
                    {image.startsWith('data:image/') && (
                      <button
                        type="button"
                        onClick={() => setImage(IMAGES.asian)}
                        aria-label="Remove uploaded photo"
                        className="absolute top-2 right-2 px-2 py-1 rounded-lg bg-white/90 text-[#1F2421] text-[10px] font-semibold hover:bg-white shadow-sm"
                      >
                        Reset
                      </button>
                    )}
                  </div>

                  <div className="sm:col-span-7 space-y-2">
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={imageUrlInput}
                        onChange={(e) => setImageUrlInput(e.target.value)}
                        placeholder="Or paste an https:// image link..."
                        className="flex-1 h-9 px-3 rounded-xl border border-[#E6E3DA] text-xs bg-white"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const trimmed = imageUrlInput.trim();
                          if (!trimmed) return;
                          if (!/^https?:\/\//i.test(trimmed)) {
                            setPhotoError('Please enter a valid http:// or https:// photo link.');
                            return;
                          }
                          setPhotoError(null);
                          setImage(trimmed);
                          showToast('Applied custom photo link.');
                        }}
                        className="px-3 h-9 rounded-xl bg-white border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] hover:bg-[#F3F1EA]"
                      >
                        Use URL
                      </button>
                    </div>
                    <p className="text-[11px] font-medium text-[#5B625C] flex items-center gap-1">
                      <ImagePlus className="w-3.5 h-3.5 text-[#4A7C59]" />
                      <span>Or quick-pick a kitchen style:</span>
                    </p>
                    <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
                      {IMAGE_PRESETS.map((preset) => (
                        <button
                          key={preset.src}
                          type="button"
                          onClick={() => {
                            setPhotoError(null);
                            setImageUrlInput('');
                            setImage(preset.src);
                          }}
                          title={preset.label}
                          className={`h-12 rounded-lg overflow-hidden border-2 ${
                            image === preset.src ? 'border-[#4A7C59]' : 'border-transparent opacity-75 hover:opacity-100'
                          }`}
                        >
                          <FoodImage src={preset.src} alt={preset.label} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Ingredients List Builder */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-[#1F2421]">Ingredients *</label>
                  <button
                    type="button"
                    onClick={() =>
                      setIngredients((prev) => [
                        ...prev,
                        { name: '', quantity: 1, unit: 'cup', category: 'Vegetables' },
                      ])
                    }
                    className="text-xs font-semibold text-[#4A7C59] hover:underline inline-flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Ingredient</span>
                  </button>
                </div>
                <div className="space-y-2">
                  {ingredients.map((ing, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                      <input
                        value={ing.name}
                        onChange={(e) =>
                          setIngredients((prev) =>
                            prev.map((row, i) => (i === idx ? { ...row, name: e.target.value } : row))
                          )
                        }
                        placeholder="Ingredient (e.g. Cabbage)"
                        className="col-span-5 h-9 px-2.5 rounded-lg border border-[#E6E3DA] text-xs"
                      />
                      <input
                        type="number"
                        step="0.1"
                        min={0.1}
                        value={ing.quantity}
                        onChange={(e) =>
                          setIngredients((prev) =>
                            prev.map((row, i) =>
                              i === idx ? { ...row, quantity: Number(e.target.value) || 1 } : row
                            )
                          )
                        }
                        className="col-span-2 h-9 px-2 rounded-lg border border-[#E6E3DA] text-xs tabular-nums"
                      />
                      <input
                        value={ing.unit}
                        onChange={(e) =>
                          setIngredients((prev) =>
                            prev.map((row, i) => (i === idx ? { ...row, unit: e.target.value } : row))
                          )
                        }
                        placeholder="unit"
                        className="col-span-2 h-9 px-2 rounded-lg border border-[#E6E3DA] text-xs"
                      />
                      <select
                        value={ing.category}
                        onChange={(e) =>
                          setIngredients((prev) =>
                            prev.map((row, i) =>
                              i === idx ? { ...row, category: e.target.value as GroceryCategory } : row
                            )
                          )
                        }
                        className="col-span-2 h-9 px-1.5 rounded-lg border border-[#E6E3DA] text-[11px] bg-white"
                      >
                        {CATEGORIES.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        disabled={ingredients.length <= 1}
                        onClick={() => setIngredients((prev) => prev.filter((_, i) => i !== idx))}
                        className="col-span-1 h-9 flex items-center justify-center text-[#5B625C] hover:text-[#D97736] disabled:opacity-30"
                        aria-label="Remove ingredient"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Step-by-Step Instructions Builder */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-[#1F2421]">
                    Cooking Steps (so people can learn) *
                  </label>
                  <button
                    type="button"
                    onClick={() => setSteps((prev) => [...prev, ''])}
                    className="text-xs font-semibold text-[#4A7C59] hover:underline inline-flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Step</span>
                  </button>
                </div>
                <div className="space-y-2">
                  {steps.map((s, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="w-7 h-9 rounded-lg bg-[#F3F1EA] text-[#4A7C59] font-mono text-xs font-semibold flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <textarea
                        rows={2}
                        maxLength={400}
                        value={s}
                        onChange={(e) =>
                          setSteps((prev) => prev.map((row, i) => (i === idx ? e.target.value : row)))
                        }
                        placeholder={`Describe step ${idx + 1}...`}
                        className="flex-1 p-2.5 rounded-xl border border-[#E6E3DA] text-xs"
                      />
                      <button
                        type="button"
                        disabled={steps.length <= 1}
                        onClick={() => setSteps((prev) => prev.filter((_, i) => i !== idx))}
                        className="h-9 px-1.5 text-[#5B625C] hover:text-[#D97736] disabled:opacity-30"
                        aria-label="Remove step"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tips & Tags */}
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">
                    Pro Tips (one per line, optional)
                  </label>
                  <textarea
                    rows={2}
                    value={tipsText}
                    onChange={(e) => setTipsText(e.target.value)}
                    placeholder="e.g. Steam over brisk water for 10 mins max"
                    className="w-full p-2.5 rounded-xl border border-[#E6E3DA] text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#5B625C] mb-1">Tags (comma separated)</label>
                  <input
                    value={tagsText}
                    onChange={(e) => setTagsText(e.target.value)}
                    placeholder="Momos, Steamed, Weekend"
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-[#EFECE3] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowComposer(false)}
                  className="px-4 py-2.5 rounded-xl border border-[#E6E3DA] text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={publishing}
                  className="px-6 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] disabled:opacity-60 inline-flex items-center gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  <span>{publishing ? 'Publishing...' : 'Publish Recipe'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
