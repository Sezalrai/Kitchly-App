import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  ChefHat,
  Globe,
  Loader2,
  Plus,
  Trash2,
  Users,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { SUPPORTED_LANGUAGES } from '../i18n/translations';
import { DietType, FamilyMember, GoalType, LanguageCode } from '../types/kitchly';
import { FoodImage } from '../components/Logo';

export function FamilyManagementScreen() {
  const { state, saveFamilyMember, removeFamilyMember, showToast } = useKitchly();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [role, setRole] = useState<FamilyMember['role']>('Member');
  const [dietType, setDietType] = useState<DietType>('Vegetarian');
  const [allergiesText, setAllergiesText] = useState('');
  const [likesText, setLikesText] = useState('');
  const [dislikesText, setDislikesText] = useState('');
  const [mealPrefs, setMealPrefs] = useState('');
  const [goal, setGoal] = useState<GoalType>('Balanced everyday eating');

  const clearForm = () => {
    setEditingId(null);
    setName('');
    setRole('Member');
    setDietType('Vegetarian');
    setAllergiesText('');
    setLikesText('');
    setDislikesText('');
    setMealPrefs('');
    setGoal('Balanced everyday eating');
  };

  const startEditMember = (member: FamilyMember) => {
    setEditingId(member.id);
    setName(member.name);
    setRole(member.role);
    setDietType(member.foodPreferences[0] || 'Vegetarian');
    setAllergiesText(member.allergies.join(', '));
    setLikesText(member.likes.join(', '));
    setDislikesText(member.dislikes.join(', '));
    setMealPrefs(member.mealPreferences || '');
    setGoal(member.dietGoal || 'Balanced everyday eating');
  };

  const handleSaveMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const split = (s: string) => s.split(',').map((x) => x.trim()).filter(Boolean);
    saveFamilyMember({
      id: editingId || `fam-${Date.now()}`,
      name: name.trim(),
      role: editingId && state.familyMembers.find((m) => m.id === editingId)?.role === 'Owner' ? 'Owner' : role,
      foodPreferences: [dietType],
      allergies: split(allergiesText),
      likes: split(likesText),
      dislikes: split(dislikesText),
      mealPreferences: mealPrefs.trim() || 'Balanced everyday meals',
      dietGoal: goal,
    });
    showToast(editingId ? `Updated ${name.trim()}’s profile.` : 'Added family member to household.');
    clearForm();
  };

  // Detect real preference & allergy conflicts across family members
  const conflicts = useMemo(() => {
    const out: { title: string; resolution: string }[] = [];
    const diets = new Set(state.familyMembers.flatMap((m) => m.foodPreferences));
    if (diets.has('Vegetarian') && (diets.has('Non-vegetarian') || diets.has('Eggetarian'))) {
      out.push({
        title: 'Mixed Vegetarian & Eggetarian/Non-Veg Household',
        resolution: 'Kitchly generates shared vegetarian bases (e.g., Dal Tadka, Quinoa Bowls) with optional protein add-ons cooked separately.',
      });
    }
    const allAllergies = Array.from(new Set(state.familyMembers.flatMap((m) => m.allergies)));
    if (allAllergies.length > 0) {
      out.push({
        title: `Household-Wide Strict Allergen Safety (${allAllergies.join(', ')})`,
        resolution: 'All shared family meal plans automatically exclude these allergens across every member’s plate.',
      });
    }
    const allLikes = state.familyMembers.flatMap((m) => m.likes.map((l) => l.toLowerCase()));
    const allDislikes = state.familyMembers.flatMap((m) => m.dislikes.map((d) => d.toLowerCase()));
    const overlap = allLikes.filter((l) => allDislikes.includes(l));
    if (overlap.length > 0) {
      out.push({
        title: `Taste Conflict on: ${Array.from(new Set(overlap)).join(', ')}`,
        resolution: 'Serve conflicting toppings (like chili flakes or olives) on the side during plating.',
      });
    }
    return out;
  }, [state.familyMembers]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl font-bold text-[#1F2421]">Family & Household Management</h2>
        <p className="text-sm text-[#5B625C]">
          Customize preferences, strict allergies, likes, dislikes, and meal goals for yourself and everyone at your table.
        </p>
      </div>

      {/* Conflict Resolution Panel */}
      {conflicts.length > 0 && (
        <div className="bg-[#F3F1EA] border border-[#E6E3DA] rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#1F2421]">
            <AlertCircle className="w-4 h-4 text-[#D97736]" />
            <span>Smart Household Compatibility & Conflict Resolution</span>
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            {conflicts.map((c, idx) => (
              <div key={idx} className="bg-white border border-[#E6E3DA] rounded-xl p-3.5 text-xs space-y-1">
                <p className="font-semibold text-[#1F2421]">{c.title}</p>
                <p className="text-[#5B625C] leading-relaxed">{c.resolution}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Existing Family Members */}
      <div className="grid md:grid-cols-3 gap-4">
        {state.familyMembers.map((member) => (
          <div
            key={member.id}
            className={`bg-white border rounded-2xl p-5 flex flex-col justify-between space-y-4 ${
              editingId === member.id ? 'border-[#4A7C59] ring-2 ring-[#4A7C59]/15' : 'border-[#E6E3DA]'
            }`}
          >
            <div className="space-y-2.5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-display text-lg font-semibold text-[#1F2421]">{member.name}</h3>
                  <p className="text-xs text-[#4A7C59] font-medium">
                    {member.role} · {member.foodPreferences.join(', ') || 'No diet pref set'}
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => startEditMember(member)}
                    className="px-2.5 py-1 rounded-lg bg-[#F3F1EA] text-xs font-medium text-[#1F2421] hover:bg-[#E7E3D7]"
                  >
                    Edit
                  </button>
                  {member.role !== 'Owner' && (
                    <button
                      onClick={() => removeFamilyMember(member.id)}
                      aria-label={`Remove ${member.name}`}
                      className="p-1.5 text-[#5B625C] hover:text-[#D97736]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              <div className="text-xs space-y-1.5 pt-2 border-t border-[#EFECE3]">
                <p>
                  <span className="font-semibold text-[#D97736]">Allergies: </span>
                  <span className="text-[#1F2421]">{member.allergies.length > 0 ? member.allergies.join(', ') : 'None'}</span>
                </p>
                <p>
                  <span className="font-semibold text-[#4A7C59]">Likes: </span>
                  <span className="text-[#5B625C]">{member.likes.join(', ') || '—'}</span>
                </p>
                <p>
                  <span className="font-semibold text-[#1F2421]">Dislikes: </span>
                  <span className="text-[#5B625C]">{member.dislikes.join(', ') || '—'}</span>
                </p>
                <p>
                  <span className="font-semibold text-[#1F2421]">Goal: </span>
                  <span className="text-[#5B625C]">{member.dietGoal}</span>
                </p>
                {member.mealPreferences && (
                  <p className="text-[#5B625C] italic">{member.mealPreferences}</p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add or Edit Family Member */}
      <form onSubmit={handleSaveMember} className="bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-display text-base font-semibold flex items-center gap-2">
            <Users className="w-4 h-4 text-[#4A7C59]" />
            <span>{editingId ? `Edit ${name || 'Member'}` : 'Add Family Member'}</span>
          </h3>
          {editingId && (
            <button
              type="button"
              onClick={clearForm}
              className="text-xs font-medium text-[#5B625C] hover:text-[#1F2421]"
            >
              Cancel edit
            </button>
          )}
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name (e.g. Grandma)"
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
          <select
            value={role}
            disabled={Boolean(editingId && state.familyMembers.find((m) => m.id === editingId)?.role === 'Owner')}
            onChange={(e) => setRole(e.target.value as FamilyMember['role'])}
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white disabled:opacity-60"
          >
            {editingId && state.familyMembers.find((m) => m.id === editingId)?.role === 'Owner' && (
              <option value="Owner">Owner</option>
            )}
            <option value="Partner">Partner</option>
            <option value="Child">Child</option>
            <option value="Parent">Parent</option>
            <option value="Member">Member</option>
          </select>
          <select
            value={dietType}
            onChange={(e) => setDietType(e.target.value as DietType)}
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
          >
            <option value="Vegetarian">Vegetarian</option>
            <option value="Eggetarian">Eggetarian</option>
            <option value="Non-vegetarian">Non-vegetarian</option>
            <option value="Vegan">Vegan</option>
            <option value="Pescatarian">Pescatarian</option>
            <option value="Flexitarian">Flexitarian</option>
          </select>
          <select
            value={goal}
            onChange={(e) => setGoal(e.target.value as GoalType)}
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
          >
            <option value="Balanced everyday eating">Balanced everyday eating</option>
            <option value="Weight management">Weight management</option>
            <option value="Muscle gain">Muscle gain</option>
            <option value="High-protein meals">High-protein meals</option>
            <option value="Budget-friendly meals">Budget-friendly meals</option>
            <option value="General nutrition improvement">General nutrition improvement</option>
          </select>
          <input
            value={allergiesText}
            onChange={(e) => setAllergiesText(e.target.value)}
            placeholder="Allergies (comma separated)"
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
          <input
            value={likesText}
            onChange={(e) => setLikesText(e.target.value)}
            placeholder="Likes (comma separated)"
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
          <input
            value={dislikesText}
            onChange={(e) => setDislikesText(e.target.value)}
            placeholder="Dislikes (comma separated)"
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
          <input
            value={mealPrefs}
            onChange={(e) => setMealPrefs(e.target.value)}
            placeholder="Meal notes (e.g. Low sodium)"
            className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
        </div>
        <button
          type="submit"
          className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A] inline-flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>{editingId ? 'Save Changes' : 'Add Member'}</span>
        </button>
      </form>
    </div>
  );
}

export function CookModeScreen() {
  const { state, t, allRecipes, saveCookTask, setLanguage, showToast } = useKitchly();
  const [ownerAssignOpen, setOwnerAssignOpen] = useState(false);
  const [slot, setSlot] = useState<'Breakfast' | 'Lunch' | 'Dinner' | 'Prep'>('Dinner');
  const [recipeId, setRecipeId] = useState(allRecipes[0]?.id || '');
  const [notes, setNotes] = useState('');
  const [translatedMap, setTranslatedMap] = useState<Record<string, { title: string; instructions: string[] }>>({});
  const [translatingId, setTranslatingId] = useState<string | null>(null);

  const recipeMap = new Map(allRecipes.map((r) => [r.id, r]));
  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === state.user.language) || SUPPORTED_LANGUAGES[0];

  const handleTranslateTask = async (taskId: string, title: string, description: string, instructions: string[]) => {
    setTranslatingId(taskId);
    try {
      const { postJson } = await import('../services/apiClient');
      const data = await postJson<{ translated?: { title?: string; instructions?: string[] } }>(
        '/api/ai/translate',
        {
          title,
          description,
          instructions,
          targetLanguageName: `${currentLangObj.name} (${currentLangObj.nativeName})`,
        }
      );
      const tr = data.translated;
      if (tr) {
        setTranslatedMap((prev) => ({
          ...prev,
          [taskId]: {
            title: tr.title || title,
            instructions: Array.isArray(tr.instructions) ? tr.instructions : instructions,
          },
        }));
      }
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Could not translate instructions.');
    } finally {
      setTranslatingId(null);
    }
  };

  const handleAssignTask = (e: React.FormEvent) => {
    e.preventDefault();
    const rec = recipeMap.get(recipeId);
    if (!rec) return;
    saveCookTask({
      id: `cook-${Date.now()}`,
      mealSlot: slot,
      recipeId: rec.id,
      recipeTitle: rec.title,
      scheduledTime: slot === 'Breakfast' ? '08:15 AM' : slot === 'Lunch' ? '01:00 PM' : '07:45 PM',
      servings: state.dietProfile.householdSize || rec.servings,
      notes: notes.trim() || 'Follow standard household spice preference.',
      completed: false,
      checklistDone: [],
    });
    setNotes('');
    setOwnerAssignOpen(false);
    showToast(`Assigned "${rec.title}" for ${slot}.`);
  };

  return (
    <div className="space-y-6">
      {/* Simple, Calm Header with Privacy Guarantee */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#4A7C59] mb-1">MAID / COOK MODE</p>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">{t.cookModeTitle}</h2>
          <p className="text-sm text-[#5B625C] mt-0.5">{t.cookModeSubtitle}</p>
          <p className="text-xs text-[#5B625C] mt-2">{t.noBudgetAccessNote}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <div className="inline-flex items-center gap-1.5 bg-[#F3F1EA] px-3 py-2 rounded-xl">
            <Globe className="w-4 h-4 text-[#4A7C59]" />
            <select
              aria-label="Cook language"
              value={state.user.language}
              onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              className="bg-transparent text-sm font-medium focus:outline-none"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName}
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={() => setOwnerAssignOpen(!ownerAssignOpen)}
            className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A]"
          >
            {ownerAssignOpen ? 'Close Assign' : '+ Assign Dish'}
          </button>
        </div>
      </div>

      {/* Owner Task Assignment Drawer */}
      {ownerAssignOpen && (
        <form onSubmit={handleAssignTask} className="bg-[#F3F1EA] border border-[#E6E3DA] rounded-2xl p-5 grid sm:grid-cols-4 gap-3 items-end">
          <div>
            <label className="block text-xs text-[#5B625C] mb-1">Meal Slot</label>
            <select
              value={slot}
              onChange={(e) => setSlot(e.target.value as 'Breakfast' | 'Lunch' | 'Dinner' | 'Prep')}
              className="w-full h-10 px-3 rounded-xl bg-white border border-[#E6E3DA] text-sm"
            >
              <option value="Breakfast">Breakfast</option>
              <option value="Lunch">Lunch</option>
              <option value="Dinner">Dinner</option>
              <option value="Prep">Prep</option>
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs text-[#5B625C] mb-1">Select Dish</label>
            <select
              value={recipeId}
              onChange={(e) => setRecipeId(e.target.value)}
              className="w-full h-10 px-3 rounded-xl bg-white border border-[#E6E3DA] text-sm"
            >
              {allRecipes.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.title}
                </option>
              ))}
            </select>
          </div>
          <button type="submit" className="h-10 px-4 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold">
            Assign Task
          </button>
          <div className="sm:col-span-4">
            <input
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Special kitchen instructions (e.g. Keep spice mild, pack 1 lunchbox)..."
              className="w-full h-10 px-3 rounded-xl bg-white border border-[#E6E3DA] text-sm"
            />
          </div>
        </form>
      )}

      {/* Simple Large-Text Task Cards */}
      {state.cookTasks.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-10 text-center space-y-3">
          <ChefHat className="w-8 h-8 text-[#4A7C59] mx-auto" />
          <h3 className="font-display text-lg font-semibold text-[#1F2421]">No cooking tasks assigned yet</h3>
          <p className="text-sm text-[#5B625C] max-w-md mx-auto">
            Assign any recipe for Breakfast, Lunch, or Dinner so your household or cook has step-by-step instructions translated into their language.
          </p>
          <button
            onClick={() => setOwnerAssignOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A]"
          >
            + Assign First Dish
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {state.cookTasks.map((task) => {
            const rec = recipeMap.get(task.recipeId);
            const trans = translatedMap[task.id];
            const displayTitle = trans?.title || task.recipeTitle;
            const steps = trans?.instructions || rec?.instructions || [];
            const mult = task.servings / Math.max(1, rec?.servings || 2);

          return (
            <div
              key={task.id}
              className={`bg-white border rounded-2xl overflow-hidden ${
                task.completed ? 'border-[#4A7C59] opacity-85' : 'border-[#E6E3DA]'
              }`}
            >
              <div className="grid md:grid-cols-12">
                {rec && (
                  <div className="md:col-span-4 min-h-[220px]">
                    <FoodImage src={rec.image} alt={displayTitle} className="w-full h-full object-cover" />
                  </div>
                )}
                <div className={`${rec ? 'md:col-span-8' : 'md:col-span-12'} p-6 space-y-5`}>
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold text-[#4A7C59] mb-1">
                        {task.mealSlot} · {task.scheduledTime} · {task.servings} {t.servings}
                      </p>
                      <h3 className="font-display text-xl font-bold text-[#1F2421]">{displayTitle}</h3>
                      {task.notes && (
                        <p className="text-sm text-[#D97736] font-medium mt-1">Note: {task.notes}</p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      {state.user.language !== 'en' && rec && !trans && (
                        <button
                          onClick={() => handleTranslateTask(task.id, rec.title, rec.description, rec.instructions)}
                          disabled={translatingId === task.id}
                          className="px-3.5 py-2.5 rounded-xl bg-[#F3F1EA] text-xs font-semibold text-[#1F2421] hover:bg-[#E7E3D7] inline-flex items-center gap-1.5"
                        >
                          {translatingId === task.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Globe className="w-3.5 h-3.5 text-[#4A7C59]" />
                          )}
                          <span>Translate Steps to {currentLangObj.nativeName}</span>
                        </button>
                      )}

                      <button
                        onClick={() => saveCookTask({ ...task, completed: !task.completed })}
                        className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold inline-flex items-center gap-2 ${
                          task.completed
                            ? 'bg-[#4A7C59] text-white'
                            : 'bg-[#F3F1EA] text-[#1F2421] hover:bg-[#E7E3D7]'
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{task.completed ? t.completed : t.markCompleted}</span>
                      </button>
                    </div>
                  </div>

                  {/* Ingredient Quantities */}
                  {rec && (
                    <div className="bg-[#FAF9F5] border border-[#EFECE3] rounded-xl p-4">
                      <h4 className="text-xs font-semibold text-[#5B625C] mb-2">{t.ingredients}</h4>
                      <div className="grid sm:grid-cols-2 gap-x-6 gap-y-1.5 text-sm">
                        {rec.ingredients.map((ing, i) => (
                          <div key={i} className="flex justify-between">
                            <span>{ing.name}</span>
                            <span className="font-mono text-xs text-[#5B625C] tabular-nums">
                              {Math.round(ing.quantity * mult * 10) / 10} {ing.unit}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Interactive Cooking Checklist */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-[#5B625C]">{t.instructions}</h4>
                    {steps.map((stepText, idx) => {
                      const done = task.checklistDone.includes(idx);
                      return (
                        <button
                          key={idx}
                          onClick={() => {
                            const nextDone = done
                              ? task.checklistDone.filter((x) => x !== idx)
                              : [...task.checklistDone, idx];
                            saveCookTask({ ...task, checklistDone: nextDone });
                          }}
                          className={`w-full min-h-[44px] text-left p-3 rounded-xl border flex items-start gap-3 transition-colors ${
                            done
                              ? 'bg-[#F3F1EA] border-[#4A7C59]/40 text-[#5B625C] line-through'
                              : 'bg-white border-[#E6E3DA] text-[#1F2421]'
                          }`}
                        >
                          <span
                            className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 mt-0.5 ${
                              done ? 'bg-[#4A7C59] text-white' : 'border border-[#D4CFC2]'
                            }`}
                          >
                            {done && <Check className="w-3.5 h-3.5" />}
                          </span>
                          <span className="text-sm leading-relaxed">
                            <span className="font-mono text-xs font-semibold mr-1.5">{idx + 1}.</span>
                            {stepText}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        </div>
      )}
    </div>
  );
}
