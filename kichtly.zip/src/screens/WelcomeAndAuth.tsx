import React, { useEffect, useState } from 'react';
import { ArrowRight, Check, Globe, ShieldCheck, Utensils } from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { IMAGES } from '../data/recipes';
import { CURRENCY_RATES, formatCurrency, SUPPORTED_LANGUAGES } from '../i18n/translations';
import {
  AllergyType,
  CuisineType,
  CurrencyCode,
  DietType,
  GoalType,
  LanguageCode,
} from '../types/kitchly';
import { FoodImage, KitchlyLogo } from '../components/Logo';
import { PWAInstallButton } from '../components/PWAComponents';

export function WelcomeScreen() {
  const { setScreen, handleGoogleSignIn, enterDemoMode, enterGuestKitchen, state, setLanguage, t } = useKitchly();

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-[#1F2421] overflow-x-clip">
      {/* 3-Zone Top Bar */}
      <header className="max-w-7xl mx-auto px-4 sm:px-6 pt-[calc(0.9rem+env(safe-area-inset-top))] pb-4 sm:py-5 flex items-center justify-between gap-3 sm:gap-8 border-b border-[#E6E3DA]">
        <KitchlyLogo />
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#5B625C]">
          <button onClick={() => setScreen('language')} className="hover:text-[#1F2421] transition-colors whitespace-nowrap shrink-0">
            {t.selectLanguage}
          </button>
          <button onClick={enterDemoMode} className="hover:text-[#1F2421] transition-colors whitespace-nowrap shrink-0">
            Meal Planner
          </button>
          <button onClick={enterDemoMode} className="hover:text-[#1F2421] transition-colors whitespace-nowrap shrink-0">
            Price Compare
          </button>
          <button onClick={() => setScreen('auth')} className="hover:text-[#1F2421] transition-colors whitespace-nowrap shrink-0">
            Sign In
          </button>
        </nav>
        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton variant="compact" />
          <button
            onClick={() => setScreen('auth')}
            className="px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs sm:text-sm font-medium hover:bg-[#3D684A] transition-colors whitespace-nowrap shrink-0"
          >
            Get Started
          </button>
        </div>
      </header>

      {/* Hero Split */}
      <section className="max-w-7xl mx-auto px-6 py-12 lg:py-20 grid lg:grid-cols-12 gap-10 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center">
          <p className="text-sm font-medium text-[#4A7C59] mb-3">
            {t.tagline} · Plan Smarter. Shop Better. Eat Happier.
          </p>
          <h1 className="font-display text-4xl lg:text-5xl font-bold tracking-tight text-[#1F2421] leading-[1.12] mb-5 text-balance">
            Your intelligent kitchen companion for every meal and grocery run.
          </h1>
          <p className="text-base lg:text-lg text-[#5B625C] leading-relaxed mb-8 max-w-xl">
            Plan personalized global meals around your family’s allergies and dislikes, cook with
            ingredients already in your fridge, compare grocery baskets, and share simple cooking
            checklists in 12 languages.
          </p>

          <div className="flex flex-wrap items-center gap-3 mb-8">
            <button
              onClick={handleGoogleSignIn}
              className="px-6 py-3.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] transition-colors inline-flex items-center gap-2 whitespace-nowrap"
            >
              <span>Continue with Google</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={enterGuestKitchen}
              className="px-5 py-3.5 rounded-xl bg-[#1E3A2A] text-white text-sm font-semibold hover:bg-[#294E39] transition-colors whitespace-nowrap"
            >
              Start Fresh Kitchen (No Sign-In)
            </button>
            <button
              onClick={enterDemoMode}
              className="px-5 py-3.5 rounded-xl bg-white border border-[#E6E3DA] text-[#1F2421] text-sm font-semibold hover:bg-[#F3F1EA] transition-colors whitespace-nowrap"
            >
              Explore Demo Kitchen
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs text-[#5B625C] pt-4 border-t border-[#E6E3DA]">
            <label className="inline-flex items-center gap-2">
              <Globe className="w-4 h-4 text-[#4A7C59]" />
              <select
                value={state.user.language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                className="bg-transparent font-medium text-[#1F2421] focus:outline-none cursor-pointer"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName} ({l.name})
                  </option>
                ))}
              </select>
            </label>
            <span aria-hidden="true">·</span>
            <span>14+ Global Cuisines</span>
            <span aria-hidden="true">·</span>
            <span>12 Languages + Cook Mode</span>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[340px] rounded-2xl overflow-hidden border border-[#E6E3DA] bg-[#F3F1EA]">
            <FoodImage
              src={IMAGES.hero}
              alt="Sunlit modern Kitchly kitchen counter with fresh vegetables and herbs"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Core Capabilities Strip */}
      <section className="max-w-7xl mx-auto px-6 pb-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-8 border-t border-[#E6E3DA]">
          <div>
            <h2 className="font-display text-base font-semibold text-[#1F2421] mb-1.5">
              Personal Diet Planner
            </h2>
            <p className="text-sm text-[#5B625C] leading-relaxed">
              Strict allergy exclusions, spice tuning, budget caps, and AI meal plans across 14+ cuisines.
            </p>
          </div>
          <div>
            <h2 className="font-display text-base font-semibold text-[#1F2421] mb-1.5">
              Cook With What You Have
            </h2>
            <p className="text-sm text-[#5B625C] leading-relaxed">
              Match pantry & fridge items before they expire and calculate exact missing grocery costs.
            </p>
          </div>
          <div>
            <h2 className="font-display text-base font-semibold text-[#1F2421] mb-1.5">
              Smart Grocery Comparison
            </h2>
            <p className="text-sm text-[#5B625C] leading-relaxed">
              Compare product prices, complete baskets, and smart split shopping net of delivery fees.
            </p>
          </div>
          <div>
            <h2 className="font-display text-base font-semibold text-[#1F2421] mb-1.5">
              Family & Cook Mode
            </h2>
            <p className="text-sm text-[#5B625C] leading-relaxed">
              Resolve household food conflicts and share distraction-free cooking steps in 12 languages.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export function AuthScreen() {
  const { handleGoogleSignIn, enterDemoMode, enterGuestKitchen, setScreen } = useKitchly();
  const [loading, setLoading] = useState(false);

  const onGoogle = async () => {
    setLoading(true);
    await handleGoogleSignIn();
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] flex flex-col justify-center items-center px-4 py-12">
      <div className="max-w-md w-full bg-white border border-[#E6E3DA] rounded-2xl p-8">
        <div className="flex items-center justify-between mb-6">
          <KitchlyLogo />
          <button
            onClick={() => setScreen('welcome')}
            className="text-xs font-medium text-[#5B625C] hover:text-[#1F2421]"
          >
            Back
          </button>
        </div>

        <h1 className="font-display text-2xl font-bold text-[#1F2421] mb-2">
          Open your Kitchly kitchen
        </h1>
        <p className="text-sm text-[#5B625C] mb-6 leading-relaxed">
          Sync across phones and laptops with Google, or jump straight into your own private saved
          kitchen on this device without signing in.
        </p>

        <button
          onClick={onGoogle}
          disabled={loading}
          className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] disabled:opacity-60 transition-colors flex items-center justify-center gap-2 mb-3"
        >
          <ShieldCheck className="w-4 h-4" />
          <span>{loading ? 'Connecting to Google...' : 'Continue with Google (Cloud Sync)'}</span>
        </button>

        <button
          onClick={enterGuestKitchen}
          className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#1E3A2A] text-white text-sm font-semibold hover:bg-[#294E39] transition-colors flex items-center justify-center gap-2 mb-3"
        >
          <ArrowRight className="w-4 h-4" />
          <span>Start My Fresh Kitchen (No Sign-In)</span>
        </button>

        <button
          onClick={enterDemoMode}
          className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-sm font-semibold hover:bg-[#E7E3D7] transition-colors flex items-center justify-center gap-2"
        >
          <Utensils className="w-4 h-4 text-[#4A7C59]" />
          <span>Explore Demo Kitchen</span>
        </button>

        <p className="text-xs text-[#5B625C] mt-6 leading-relaxed">
          Fresh Kitchen saves your groceries, pantry, and diet plans automatically on this device.
          Connect Google anytime in Settings for multi-device cloud backup.
        </p>
      </div>
    </div>
  );
}

export function LanguageSelectionScreen() {
  const { state, setLanguage, setScreen, t } = useKitchly();

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-[#1F2421] mb-2">{t.selectLanguage}</h1>
        <p className="text-sm text-[#5B625C]">
          Translate navigation, meal plans, grocery lists, voice input, and Cook Mode instructions.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-8">
        {SUPPORTED_LANGUAGES.map((lang) => {
          const active = state.user.language === lang.code;
          return (
            <button
              key={lang.code}
              onClick={() => setLanguage(lang.code)}
              className={`p-4 rounded-xl border text-left transition-colors min-h-[76px] ${
                active
                  ? 'bg-[#4A7C59] text-white border-[#4A7C59]'
                  : 'bg-white text-[#1F2421] border-[#E6E3DA] hover:bg-[#F3F1EA]'
              }`}
            >
              <div className="font-display text-lg font-semibold">{lang.nativeName}</div>
              <div className={`text-xs ${active ? 'text-white/85' : 'text-[#5B625C]'}`}>{lang.name}</div>
            </button>
          );
        })}
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={() => setScreen('onboarding')}
          className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A]"
        >
          Continue to Setup
        </button>
        <button
          onClick={() => setScreen('dashboard')}
          className="px-5 py-2.5 rounded-xl bg-white border border-[#E6E3DA] text-sm font-medium text-[#1F2421] hover:bg-[#F3F1EA]"
        >
          {t.dashboard}
        </button>
      </div>
    </div>
  );
}

const DIET_TYPES: DietType[] = ['Vegetarian', 'Non-vegetarian', 'Eggetarian', 'Vegan', 'Pescatarian', 'Flexitarian'];
const CUISINES: CuisineType[] = ['Indian', 'Italian', 'Continental', 'Chinese', 'Korean', 'Japanese', 'Mexican', 'Mediterranean', 'Thai', 'American', 'French', 'Middle Eastern', 'Turkish', 'Spanish'];
const ALLERGIES: AllergyType[] = ['Nut allergies', 'Dairy intolerance', 'Gluten intolerance', 'Lactose intolerance', 'Shellfish allergies', 'Soy allergies', 'Egg allergy'];
const GOALS: GoalType[] = ['Balanced everyday eating', 'Weight management', 'Muscle gain', 'High-protein meals', 'Budget-friendly meals', 'Family meal planning', 'General nutrition improvement'];

export function OnboardingScreen() {
  const {
    state,
    setLanguage,
    updateHouseholdSettings,
    updateDietProfile,
    saveFamilyMember,
    resetToFreshAccount,
    setScreen,
    showToast,
  } = useKitchly();

  const [step, setStep] = useState(1);
  const [householdName, setHouseholdName] = useState(state.user.householdName);
  const [country, setCountry] = useState(state.user.country);
  const [currency, setCurrency] = useState<CurrencyCode>(state.user.currency);
  const [profile, setProfile] = useState(state.dietProfile);
  const [dislikesInput, setDislikesInput] = useState(
    state.dietProfile.dislikedIngredients.join(', ')
  );
  const [weeklyDisplayBudget, setWeeklyDisplayBudget] = useState<string>(() => {
    if (state.dietProfile.weeklyBudget > 0) {
      const rate = (CURRENCY_RATES[state.user.currency] || CURRENCY_RATES.INR).rateFromINR;
      return String(Math.round(state.dietProfile.weeklyBudget * rate));
    }
    return '';
  });

  useEffect(() => {
    setHouseholdName(state.user.householdName);
    setCountry(state.user.country);
    setCurrency(state.user.currency);
    setProfile(state.dietProfile);
    setDislikesInput(state.dietProfile.dislikedIngredients.join(', '));
    if (state.dietProfile.weeklyBudget > 0) {
      const rate = (CURRENCY_RATES[state.user.currency] || CURRENCY_RATES.INR).rateFromINR;
      setWeeklyDisplayBudget(String(Math.round(state.dietProfile.weeklyBudget * rate)));
    } else {
      setWeeklyDisplayBudget('');
    }
  }, [state.user.id]);

  const cfg = CURRENCY_RATES[currency] || CURRENCY_RATES.INR;
  const presetsDisplay = currency === 'INR' ? [1500, 2500, 4000, 6000] : [50, 90, 140, 220];

  const parsedDisplayBudget = Math.max(0, Number(weeklyDisplayBudget) || 0);
  const weeklyBudgetINR = Math.round(parsedDisplayBudget / Math.max(0.0001, cfg.rateFromINR));
  const dailyBudgetINR = weeklyBudgetINR > 0 ? Math.round(weeklyBudgetINR / 7) : 0;
  const monthlyBudgetINR = weeklyBudgetINR > 0 ? Math.round(weeklyBudgetINR * 4.3) : 0;

  const toggleItem = <T extends string>(list: T[], val: T): T[] =>
    list.includes(val) ? list.filter((x) => x !== val) : [...list, val];

  const finishOnboarding = () => {
    const parsedDislikes = dislikesInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const updatedProfile = {
      ...profile,
      dislikedIngredients: parsedDislikes,
      weeklyBudget: weeklyBudgetINR,
      dailyBudget: dailyBudgetINR,
      monthlyBudget: monthlyBudgetINR,
    };

    updateHouseholdSettings({
      householdName: householdName.trim() || state.user.householdName,
      country,
      currency,
      onboarded: true,
    });
    updateDietProfile(updatedProfile, true);

    const owner = state.familyMembers.find((m) => m.role === 'Owner') || state.familyMembers[0];
    if (owner) {
      saveFamilyMember({
        ...owner,
        name: state.user.name?.split(' ')[0] || owner.name,
        foodPreferences: updatedProfile.foodPreferences,
        allergies: updatedProfile.allergies,
        dislikes: parsedDislikes,
        dietGoal: updatedProfile.goals[0] || owner.dietGoal || 'Balanced everyday eating',
      });
    }

    showToast('Your Kitchly household is ready!');
    setScreen('dashboard');
  };

  const hasLegacyItems = state.groceryList.length > 0 || state.pantry.length > 0 || state.monthlySpentINR > 0;

  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#4A7C59] mb-1">Step {step} of 4 · Kitchen Setup</p>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-[#1F2421]">
            Personalize your Kitchly household
          </h1>
        </div>
        <div className="flex items-center gap-3">
          {hasLegacyItems && (
            <button
              onClick={resetToFreshAccount}
              className="text-xs font-medium text-[#D97736] hover:underline"
            >
              Clear existing cart & history
            </button>
          )}
          <button
            onClick={() => {
              updateHouseholdSettings({ onboarded: true });
              setScreen('dashboard');
            }}
            className="text-sm text-[#5B625C] hover:text-[#1F2421]"
          >
            Skip for now
          </button>
        </div>
      </div>

      {/* Step progress bar */}
      <progress
        value={step}
        max={4}
        aria-label={`Onboarding step ${step} of 4`}
        className="w-full h-1.5 rounded-full overflow-hidden accent-[#4A7C59] mb-6 block"
      />

      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 lg:p-8 space-y-6">
        {step === 1 && (
          <div className="space-y-5">
            <h2 className="font-display text-lg font-semibold">Language, Household & Currency</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1.5">Household Name</label>
                <input
                  value={householdName}
                  onChange={(e) => setHouseholdName(e.target.value)}
                  placeholder="e.g. Sezl's Kitchen"
                  className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1.5">Preferred Language</label>
                <select
                  value={state.user.language}
                  onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                  className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.nativeName} ({l.name})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1.5">Country / Region</label>
                <select
                  value={country}
                  onChange={(e) => {
                    const c = e.target.value;
                    setCountry(c);
                    if (c === 'India') setCurrency('INR');
                    else if (c === 'United States') setCurrency('USD');
                    else if (c === 'United Kingdom') setCurrency('GBP');
                    else if (c === 'UAE') setCurrency('AED');
                    else if (c === 'Singapore') setCurrency('SGD');
                    else setCurrency('EUR');
                  }}
                  className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                >
                  <option value="India">India</option>
                  <option value="United States">United States</option>
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="Germany">Europe / Germany</option>
                  <option value="UAE">United Arab Emirates</option>
                  <option value="Singapore">Singapore</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1.5">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                >
                  {Object.entries(CURRENCY_RATES).map(([code, meta]) => (
                    <option key={code} value={code}>
                      {meta.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-lg font-semibold mb-3">Food Preferences</h2>
              <div className="flex flex-wrap gap-2">
                {DIET_TYPES.map((d) => {
                  const active = profile.foodPreferences.includes(d);
                  return (
                    <button
                      key={d}
                      onClick={() => setProfile({ ...profile, foodPreferences: toggleItem(profile.foodPreferences, d) })}
                      className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors ${
                        active ? 'bg-[#4A7C59] text-white border-[#4A7C59]' : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421]'
                      }`}
                    >
                      {d}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <h2 className="font-display text-lg font-semibold mb-3">Favorite Global Cuisines</h2>
              <div className="flex flex-wrap gap-2">
                {CUISINES.map((c) => {
                  const active = profile.cuisines.includes(c);
                  return (
                    <button
                      key={c}
                      onClick={() => setProfile({ ...profile, cuisines: toggleItem(profile.cuisines, c) })}
                      className={`px-3.5 py-2 rounded-xl text-sm font-medium border transition-colors ${
                        active ? 'bg-[#4A7C59] text-white border-[#4A7C59]' : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421]'
                      }`}
                    >
                      {c}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block font-display text-base font-semibold mb-1.5">
                Ingredients you dislike or avoid (optional)
              </label>
              <input
                value={dislikesInput}
                onChange={(e) => setDislikesInput(e.target.value)}
                placeholder="e.g. Mushrooms, Olives, Bitter Gourd (comma separated)"
                className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm"
              />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-lg font-semibold mb-1">Allergies (Strict Exclusions)</h2>
              <p className="text-xs text-[#5B625C] mb-3">Kitchly will never suggest meals containing these allergens.</p>
              <div className="flex flex-wrap gap-2">
                {ALLERGIES.map((a) => {
                  const active = profile.allergies.includes(a);
                  return (
                    <button
                      key={a}
                      onClick={() => setProfile({ ...profile, allergies: toggleItem(profile.allergies, a) })}
                      className={`px-3.5 py-2 rounded-xl text-sm font-medium border transition-colors ${
                        active ? 'bg-[#D97736] text-white border-[#D97736]' : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421]'
                      }`}
                    >
                      {a}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <h2 className="font-display text-lg font-semibold mb-3">Personal Goals</h2>
              <div className="flex flex-wrap gap-2">
                {GOALS.map((g) => {
                  const active = profile.goals.includes(g);
                  return (
                    <button
                      key={g}
                      onClick={() => setProfile({ ...profile, goals: toggleItem(profile.goals, g) })}
                      className={`px-3.5 py-2 rounded-xl text-sm font-medium border transition-colors ${
                        active ? 'bg-[#4A7C59] text-white border-[#4A7C59]' : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421]'
                      }`}
                    >
                      {g}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-lg font-semibold">Household Size & Weekly Grocery Budget</h2>
              <p className="text-xs text-[#5B625C] mt-1">
                Enter your own weekly grocery budget in {currency}. Daily and monthly budgets update automatically.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1.5">People Eating</label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={profile.householdSize}
                  onChange={(e) => setProfile({ ...profile, householdSize: Math.max(1, Number(e.target.value) || 1) })}
                  className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1.5">Max Cooking Time (mins)</label>
                <input
                  type="number"
                  min={10}
                  max={180}
                  value={profile.maxCookingTimeMins}
                  onChange={(e) => setProfile({ ...profile, maxCookingTimeMins: Math.max(10, Number(e.target.value) || 30) })}
                  className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                />
              </div>
              <div className="sm:col-span-2 bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-4 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="text-xs font-medium text-[#5B625C]">
                    Your Weekly Grocery Budget ({cfg.label})
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {presetsDisplay.map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setWeeklyDisplayBudget(String(amt))}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono border transition-colors ${
                          Number(weeklyDisplayBudget) === amt
                            ? 'bg-[#4A7C59] text-white border-[#4A7C59]'
                            : 'bg-white border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                        }`}
                      >
                        {cfg.symbol}{amt.toLocaleString()}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-lg font-semibold text-[#1F2421]">{cfg.symbol}</span>
                  <input
                    type="number"
                    min={0}
                    value={weeklyDisplayBudget}
                    onChange={(e) => setWeeklyDisplayBudget(e.target.value)}
                    placeholder={`Enter weekly budget in ${currency} (e.g. ${presetsDisplay[1]})`}
                    className="flex-1 h-11 px-3.5 rounded-xl border border-[#E6E3DA] bg-white text-sm font-mono tabular-nums"
                  />
                </div>
                <div className="flex flex-wrap gap-4 text-xs text-[#5B625C] tabular-nums">
                  <span>
                    Daily est:{' '}
                    <strong className="text-[#1F2421]">
                      {weeklyBudgetINR > 0 ? formatCurrency(dailyBudgetINR, currency) : 'Not set'}
                    </strong>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    Monthly est:{' '}
                    <strong className="text-[#1F2421]">
                      {weeklyBudgetINR > 0 ? formatCurrency(monthlyBudgetINR, currency) : 'Not set'}
                    </strong>
                  </span>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1.5">Cooking Skill Level</label>
                <select
                  value={profile.skillLevel}
                  onChange={(e) => setProfile({ ...profile, skillLevel: e.target.value as 'Beginner' | 'Intermediate' | 'Advanced' })}
                  className="w-full h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t border-[#E6E3DA]">
          <button
            onClick={() => setStep((s) => Math.max(1, s - 1))}
            disabled={step === 1}
            className="px-4 py-2.5 rounded-xl border border-[#E6E3DA] text-sm font-medium disabled:opacity-40"
          >
            Previous
          </button>
          {step < 4 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A] inline-flex items-center gap-1.5"
            >
              <span>Next</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={finishOnboarding}
              className="px-6 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Save & Open Dashboard</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

