import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Copy,
  ExternalLink,
  Info,
  ListChecks,
  Minus,
  PackagePlus,
  Plus,
  Scale,
  Search,
  ShoppingBag,
  Store,
  Trash2,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { formatCurrency } from '../i18n/translations';
import {
  STORE_BROWSE_CATALOG,
  computeCompleteBaskets,
  computeSmartSplitShopping,
  generateProductComparisons,
  getPlatformsForRegion,
  getStoreHomeUrl,
} from '../services/groceryAdapter';
import { GroceryCategory } from '../types/kitchly';

const CATEGORIES: GroceryCategory[] = [
  'Vegetables',
  'Fruits',
  'Dairy',
  'Meat and seafood',
  'Grains',
  'Bakery',
  'Spices',
  'Beverages',
  'Household essentials',
];

export function GroceryListScreen() {
  const {
    state,
    t,
    saveGroceryItem,
    toggleGroceryPurchased,
    removeGroceryItem,
    generateGroceryFromWeeklyPlan,
    movePurchasedToPantry,
    showToast,
    setScreen,
  } = useKitchly();

  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unit, setUnit] = useState('kg');
  const [category, setCategory] = useState<GroceryCategory>('Vegetables');
  const [costINR, setCostINR] = useState(60);
  const [storeRegion, setStoreRegion] = useState<'India' | 'Global'>(
    state.user.country.toLowerCase() === 'india' ? 'India' : 'Global'
  );
  const [activeStoreId, setActiveStoreId] = useState<string>(() =>
    state.user.country.toLowerCase() === 'india' ? 'blinkit' : 'walmart'
  );
  const [catalogSearch, setCatalogSearch] = useState('');
  const [catalogCatFilter, setCatalogCatFilter] = useState<'All' | GroceryCategory>('All');

  useEffect(() => {
    const nextReg = state.user.country.toLowerCase() === 'india' ? 'India' : 'Global';
    setStoreRegion(nextReg);
    setActiveStoreId(nextReg === 'India' ? 'blinkit' : 'walmart');
  }, [state.user.country]);

  const storePlatforms = useMemo(() => getPlatformsForRegion(storeRegion), [storeRegion]);
  const activeStore =
    storePlatforms.find((p) => p.id === activeStoreId) || storePlatforms[0];

  const catalogCategories = useMemo(() => {
    const cats = new Set(
      STORE_BROWSE_CATALOG.filter((p) => p.region === storeRegion).map((p) => p.category)
    );
    return ['All', ...Array.from(cats)] as ('All' | GroceryCategory)[];
  }, [storeRegion]);

  const catalogProducts = useMemo(() => {
    const q = catalogSearch.trim().toLowerCase();
    return STORE_BROWSE_CATALOG.filter((p) => p.region === storeRegion)
      .filter((p) => catalogCatFilter === 'All' || p.category === catalogCatFilter)
      .filter(
        (p) =>
          !q ||
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
  }, [storeRegion, catalogCatFilter, catalogSearch]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      showToast('Enter a product name first.');
      return;
    }
    saveGroceryItem({
      id: `groc-${Date.now()}`,
      name: trimmed,
      quantity: Math.max(0.1, quantity),
      unit: unit.trim() || 'pc',
      category,
      estimatedCostINR: Math.max(0, costINR),
      purchased: false,
      source: 'manual',
    });
    setName('');
    showToast(`Added "${trimmed}" to your grocery list.`);
  };

  const pendingItems = state.groceryList.filter((g) => !g.purchased);
  const purchasedItems = state.groceryList.filter((g) => g.purchased);
  const totalEstINR = pendingItems.reduce((sum, g) => sum + g.estimatedCostINR, 0);

  const handleCopyCart = async () => {
    if (pendingItems.length === 0) return;
    const text = pendingItems
      .map((g, i) => `${i + 1}. ${g.name} (${g.quantity} ${g.unit})`)
      .join('\n');
    try {
      await navigator.clipboard.writeText(text);
      showToast(`Copied ${pendingItems.length} item(s) to paste into ${activeStore.name}.`);
    } catch {
      showToast('Use the Shop links beside each item to open the store directly.');
    }
  };

  return (
    <div className="space-y-6 pb-14 lg:pb-0">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">{t.groceryList}</h2>
          <p className="text-sm text-[#5B625C] tabular-nums">
            {pendingItems.length} item(s) {t.toBuy.toLowerCase()} · Est. Total:{' '}
            <span className="font-semibold text-[#1F2421]">
              {formatCurrency(totalEstINR, state.user.currency)}
            </span>
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setScreen('grocery-wizard')}
            className="px-3.5 sm:px-4 py-2.5 rounded-xl bg-[#D97736] text-white text-xs font-semibold hover:opacity-95 inline-flex items-center gap-1.5"
          >
            <ListChecks className="w-4 h-4" />
            <span>Guided Trip Builder</span>
          </button>
          <button
            onClick={generateGroceryFromWeeklyPlan}
            className="px-3.5 sm:px-4 py-2.5 rounded-xl bg-white border border-[#E6E3DA] text-xs font-semibold hover:bg-[#F3F1EA]"
          >
            Sync Weekly Plan
          </button>
          {purchasedItems.length > 0 && (
            <button
              onClick={movePurchasedToPantry}
              className="px-3.5 sm:px-4 py-2.5 rounded-xl bg-[#F3F1EA] text-xs font-semibold text-[#4A7C59] hover:bg-[#E7E3D7] inline-flex items-center gap-1.5"
            >
              <PackagePlus className="w-4 h-4" />
              <span>Move Purchased ({purchasedItems.length})</span>
            </button>
          )}
          <button
            onClick={() => setScreen('price-comparison')}
            className="px-3.5 sm:px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
          >
            <Scale className="w-4 h-4" />
            <span>{t.comparePrices}</span>
          </button>
        </div>
      </div>

      {/* Add Manual Product */}
      <form onSubmit={handleAdd} className="bg-white border border-[#E6E3DA] rounded-2xl p-4 grid grid-cols-2 sm:grid-cols-6 gap-3 items-end">
        <div className="col-span-2 sm:col-span-2">
          <label className="block text-xs text-[#5B625C] mb-1">Product Name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Organic Spinach"
            className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Qty & Unit</label>
          <div className="flex gap-1.5">
            <input
              type="number"
              step="0.5"
              min="0.1"
              value={quantity}
              onChange={(e) => setQuantity(Number(e.target.value))}
              className="w-16 h-10 px-2 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
            />
            <input
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="w-full h-10 px-2 rounded-xl border border-[#E6E3DA] text-sm"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Category</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as GroceryCategory)}
            className="w-full h-10 px-2.5 rounded-xl border border-[#E6E3DA] text-sm bg-white"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Est. Cost (INR)</label>
          <input
            type="number"
            min="0"
            value={costINR}
            onChange={(e) => setCostINR(Number(e.target.value))}
            className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
          />
        </div>
        <button
          type="submit"
          className="h-10 px-4 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A] inline-flex items-center justify-center gap-1"
        >
          <Plus className="w-4 h-4" />
          <span>Add</span>
        </button>
      </form>

      {/* Categorized Shopping List */}
      {state.groceryList.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 sm:p-8 text-center space-y-3">
          <ShoppingBag className="w-8 h-8 text-[#4A7C59] mx-auto" />
          <h3 className="font-display text-lg font-semibold text-[#1F2421]">Your grocery cart is empty</h3>
          <p className="text-sm text-[#5B625C] max-w-md mx-auto">
            Add groceries directly from the store catalog below, add a custom item above, or run the Guided Trip Builder.
          </p>
          <button
            onClick={() => setScreen('grocery-wizard')}
            className="px-5 py-2.5 rounded-xl bg-[#D97736] text-white text-xs font-semibold hover:opacity-95 inline-flex items-center gap-1.5"
          >
            <ListChecks className="w-4 h-4" />
            <span>Start Guided Trip Builder</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-white border border-[#E6E3DA] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start sm:items-center gap-2 text-xs text-[#5B625C]">
              <Store className="w-4 h-4 text-[#4A7C59] shrink-0 mt-0.5 sm:mt-0" />
              <span>
                Ready to order? Shop directly on <strong className="text-[#1F2421]">{activeStore.name}</strong> ({activeStore.deliveryTimeLabel}) or copy your cart list.
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleCopyCart}
                className="px-3 py-2 rounded-xl bg-[#FAF9F5] border border-[#E6E3DA] text-xs font-medium hover:bg-[#F3F1EA] inline-flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5 text-[#4A7C59]" />
                <span>Copy List</span>
              </button>
              <a
                href={activeStore.storeHomeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
              >
                <span>Open {activeStore.name}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 sm:gap-5">
            {CATEGORIES.map((cat) => {
              const items = state.groceryList.filter((g) => g.category === cat);
              if (items.length === 0) return null;
              return (
                <div key={cat} className="bg-white border border-[#E6E3DA] rounded-2xl p-4 sm:p-5">
                  <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#EFECE3]">
                    <h3 className="font-display text-sm font-semibold text-[#1F2421]">{cat}</h3>
                    <span className="text-xs font-mono text-[#5B625C] tabular-nums">{items.length}</span>
                  </div>
                  <div className="divide-y divide-[#EFECE3]/70">
                    {items.map((item) => (
                      <div key={item.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-sm">
                        <button
                          onClick={() => toggleGroceryPurchased(item.id)}
                          className="flex items-center gap-2.5 text-left flex-1 min-w-0"
                        >
                          <CheckCircle2
                            className={`w-4 h-4 shrink-0 ${item.purchased ? 'text-[#4A7C59]' : 'text-[#D4CFC2]'}`}
                          />
                          <span className={`truncate font-medium ${item.purchased ? 'line-through text-[#5B625C]' : 'text-[#1F2421]'}`}>
                            {item.name}
                          </span>
                        </button>
                        <div className="flex items-center justify-between sm:justify-end gap-2 pl-6 sm:pl-0 shrink-0">
                          <div className="flex items-center gap-1.5">
                            <input
                              type="number"
                              min="0.1"
                              step="0.5"
                              aria-label={`Quantity for ${item.name}`}
                              value={item.quantity}
                              onChange={(e) =>
                                saveGroceryItem({ ...item, quantity: Math.max(0.1, Number(e.target.value)) })
                              }
                              className="w-16 h-8 px-2 rounded-lg border border-[#E6E3DA] text-xs font-mono text-right tabular-nums"
                            />
                            <span className="text-xs text-[#5B625C] min-w-[28px]">{item.unit}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-mono font-semibold text-[#1F2421] min-w-[52px] text-right tabular-nums">
                              {formatCurrency(item.estimatedCostINR, state.user.currency)}
                            </span>
                            <a
                              href={activeStore.buildSearchUrl(item.name)}
                              target="_blank"
                              rel="noopener noreferrer"
                              title={`Buy ${item.name} on ${activeStore.name}`}
                              className="p-2 rounded-lg text-[#4A7C59] hover:bg-[#F3F1EA]"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                            <button
                              onClick={() => removeGroceryItem(item.id)}
                              aria-label={`Remove ${item.name}`}
                              className="p-2 text-[#5B625C] hover:text-[#D97736]"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Store Catalog — What Blinkit, Zepto, Instamart, BigBasket & Partner Apps Offer */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-4 sm:p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold text-[#4A7C59]">Live Store Catalog & Direct Links</p>
            <h3 className="font-display text-lg sm:text-xl font-semibold text-[#1F2421]">
              What {storePlatforms.map((p) => p.name).join(', ')} offer
            </h3>
            <p className="text-xs text-[#5B625C]">
              Tap + Add to build your basket just like Blinkit, adjust packs, or jump straight to the store to checkout.
            </p>
          </div>
          <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1 self-start">
            {(['India', 'Global'] as const).map((reg) => (
              <button
                key={reg}
                onClick={() => {
                  setStoreRegion(reg);
                  setCatalogCatFilter('All');
                  setActiveStoreId(reg === 'India' ? 'blinkit' : 'walmart');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  storeRegion === reg ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
                }`}
              >
                {reg} Stores
              </button>
            ))}
          </div>
        </div>

        {/* Store Filter Tabs + Search (horizontal scroll on mobile) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 sm:flex-wrap">
            {storePlatforms.map((plat) => {
              const selected = activeStore.id === plat.id;
              return (
                <button
                  key={plat.id}
                  onClick={() => setActiveStoreId(plat.id)}
                  className={`px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    selected
                      ? 'bg-[#4A7C59] border-[#4A7C59] text-white'
                      : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                  }`}
                >
                  {plat.name} · {plat.deliveryTimeLabel}
                </button>
              );
            })}
          </div>
          <div className="relative sm:w-64 shrink-0">
            <Search className="w-4 h-4 text-[#5B625C] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={catalogSearch}
              onChange={(e) => setCatalogSearch(e.target.value)}
              placeholder={`Search ${activeStore.name} items...`}
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-[#E6E3DA] text-xs bg-[#FAF9F5]"
            />
          </div>
        </div>

        {/* Category Filter Strip (Blinkit-style quick browse) */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {catalogCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCatalogCatFilter(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 border transition-colors ${
                catalogCatFilter === cat
                  ? 'bg-[#1E3A2A] border-[#1E3A2A] text-white'
                  : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#5B625C] hover:text-[#1F2421]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 2-column mobile grid like Blinkit/Zepto */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
          {catalogProducts.map((prod) => {
            const mult = prod.multipliers[activeStore.id] ?? 0.9;
            const estPriceINR = Math.round(prod.mrpINR * mult);
            const discountPct = prod.mrpINR > estPriceINR ? Math.round(((prod.mrpINR - estPriceINR) / prod.mrpINR) * 100) : 0;
            const cartEntry = state.groceryList.find(
              (g) => !g.purchased && g.name.toLowerCase() === prod.name.toLowerCase()
            );

            return (
              <div
                key={prod.id}
                className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-3 sm:p-4 flex flex-col justify-between gap-2.5"
              >
                <div>
                  <div className="flex items-center justify-between gap-1 text-[10px] sm:text-[11px] text-[#5B625C]">
                    <span className="truncate">{prod.category}</span>
                    {discountPct > 0 && (
                      <span className="font-semibold text-[#4A7C59] shrink-0">{discountPct}% off</span>
                    )}
                  </div>
                  <h4 className="font-display text-xs sm:text-sm font-semibold text-[#1F2421] mt-1 leading-snug line-clamp-2">
                    {prod.name}
                  </h4>
                  <p className="text-[11px] text-[#5B625C] mt-0.5 truncate">
                    {prod.brand} · {prod.packSize}
                  </p>
                  <div className="flex items-baseline gap-1.5 mt-1.5 tabular-nums">
                    <span className="text-sm font-bold text-[#1F2421]">
                      {formatCurrency(estPriceINR, state.user.currency)}
                    </span>
                    {prod.mrpINR > estPriceINR && (
                      <span className="text-[11px] text-[#5B625C] line-through">
                        {formatCurrency(prod.mrpINR, state.user.currency)}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-1.5 pt-2 border-t border-[#E6E3DA]">
                  {cartEntry ? (
                    <div className="flex-1 h-9 rounded-lg bg-[#4A7C59] text-white flex items-center justify-between px-1.5">
                      <button
                        type="button"
                        aria-label={`Decrease ${prod.name}`}
                        onClick={() => {
                          const nextQty = Math.round((cartEntry.quantity - prod.quantity) * 10) / 10;
                          if (nextQty <= 0) {
                            removeGroceryItem(cartEntry.id);
                            showToast(`Removed "${prod.name}" from cart.`);
                          } else {
                            saveGroceryItem({
                              ...cartEntry,
                              quantity: nextQty,
                              estimatedCostINR: Math.max(10, Math.round(cartEntry.estimatedCostINR - estPriceINR)),
                            });
                          }
                        }}
                        className="w-7 h-7 rounded-md hover:bg-white/15 flex items-center justify-center"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-xs font-mono font-bold tabular-nums px-1">
                        {cartEntry.quantity}
                      </span>
                      <button
                        type="button"
                        aria-label={`Increase ${prod.name}`}
                        onClick={() => {
                          const nextQty = Math.round((cartEntry.quantity + prod.quantity) * 10) / 10;
                          saveGroceryItem({
                            ...cartEntry,
                            quantity: nextQty,
                            estimatedCostINR: Math.round(cartEntry.estimatedCostINR + estPriceINR),
                          });
                        }}
                        className="w-7 h-7 rounded-md hover:bg-white/15 flex items-center justify-center"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        saveGroceryItem({
                          id: `groc-cat-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
                          name: prod.name,
                          quantity: prod.quantity,
                          unit: prod.unit,
                          category: prod.category,
                          estimatedCostINR: estPriceINR,
                          purchased: false,
                          source: 'manual',
                        });
                        showToast(`Added "${prod.name}" to cart.`);
                      }}
                      className="flex-1 h-9 px-2.5 rounded-lg text-xs font-semibold bg-[#4A7C59] text-white hover:bg-[#3D684A] transition-colors"
                    >
                      + Add
                    </button>
                  )}
                  <a
                    href={activeStore.buildSearchUrl(prod.name)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-9 px-2.5 rounded-lg bg-white border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] hover:bg-[#F3F1EA] inline-flex items-center justify-center gap-1"
                  >
                    <span>Buy</span>
                    <ExternalLink className="w-3 h-3 text-[#D97736]" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Blinkit-style Sticky Mobile Cart Bar */}
      {pendingItems.length > 0 && (
        <div className="lg:hidden fixed bottom-[calc(4.1rem+env(safe-area-inset-bottom))] left-3 right-3 z-30">
          <div className="bg-[#1E3A2A] text-white rounded-2xl px-4 py-3 shadow-xl flex items-center justify-between gap-3">
            <div className="min-w-0 tabular-nums">
              <p className="text-xs text-[#B8D2C0] truncate">
                {pendingItems.length} item{pendingItems.length === 1 ? '' : 's'} in cart · {activeStore.name}
              </p>
              <p className="text-sm font-bold text-white">
                Est. {formatCurrency(totalEstINR, state.user.currency)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setScreen('price-comparison')}
              className="px-3.5 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold inline-flex items-center gap-1.5 shrink-0 hover:bg-[#3D684A]"
            >
              <span>Compare & Shop</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function PriceComparisonScreen() {
  const { state, t } = useKitchly();
  const [regionOverride, setRegionOverride] = useState<'India' | 'Global'>(
    state.user.country.toLowerCase() === 'india' ? 'India' : 'Global'
  );
  const [mode, setMode] = useState<'product' | 'basket' | 'split'>('basket');

  useEffect(() => {
    setRegionOverride(state.user.country.toLowerCase() === 'india' ? 'India' : 'Global');
  }, [state.user.country]);

  const pendingItems = state.groceryList.filter((g) => !g.purchased);
  const platforms = useMemo(() => getPlatformsForRegion(regionOverride), [regionOverride]);
  const comparisons = useMemo(
    () => generateProductComparisons(pendingItems, platforms),
    [pendingItems, platforms]
  );
  const baskets = useMemo(
    () => computeCompleteBaskets(comparisons, platforms),
    [comparisons, platforms]
  );
  const splitPlan = useMemo(
    () => computeSmartSplitShopping(comparisons, platforms, baskets),
    [comparisons, platforms, baskets]
  );

  const cheapestBasket = baskets.find((b) => b.isCheapest) || baskets[0];
  const priciestBasket = baskets[baskets.length - 1];
  const basketSavingsINR =
    cheapestBasket && priciestBasket ? Math.max(0, priciestBasket.totalPayableINR - cheapestBasket.totalPayableINR) : 0;

  return (
    <div className="space-y-6">
      {/* Header & Region Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#4A7C59] mb-1">SMART GROCERY COMPARISON</p>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">
            Compare grocery prices & delivery fees
          </h2>
        </div>
        <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1 self-start">
          <button
            onClick={() => setRegionOverride('India')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
              regionOverride === 'India' ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
            }`}
          >
            India Platforms
          </button>
          <button
            onClick={() => setRegionOverride('Global')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
              regionOverride === 'Global' ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
            }`}
          >
            Global Platforms
          </button>
        </div>
      </div>

      {/* Explicit Transparency Notice */}
      <div className="bg-[#F3F1EA] border border-[#E6E3DA] rounded-xl p-4 flex items-start gap-3 text-xs text-[#1F2421]">
        <Info className="w-4 h-4 text-[#4A7C59] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold">
            {t.sampleDataNotice}
          </p>
          <p className="text-[#5B625C]">
            Platform adapters ({platforms.map((p) => p.name).join(', ')}) are modular and ready for
            partner API credentials. All prices below are labeled as <span className="font-medium text-[#1F2421]">Sample Demo Price</span> or <span className="font-medium text-[#1F2421]">Estimated Price</span>.
          </p>
        </div>
      </div>

      {/* Mode Tabs (horizontal scroll on narrow mobile) */}
      <div className="flex overflow-x-auto no-scrollbar bg-[#F3F1EA] p-1 rounded-xl gap-1">
        <button
          onClick={() => setMode('product')}
          className={`px-3.5 sm:px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 ${
            mode === 'product' ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
          }`}
        >
          A. Cheapest Product
        </button>
        <button
          onClick={() => setMode('basket')}
          className={`px-3.5 sm:px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 ${
            mode === 'basket' ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
          }`}
        >
          B. Cheapest Complete Basket
        </button>
        <button
          onClick={() => setMode('split')}
          className={`px-3.5 sm:px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 ${
            mode === 'split' ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
          }`}
        >
          C. Smart Split Shopping
        </button>
      </div>

      {pendingItems.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 text-center">
          <ShoppingBag className="w-8 h-8 text-[#4A7C59] mx-auto mb-2" />
          <p className="font-display text-base font-semibold">Your grocery list has no pending items</p>
          <p className="text-sm text-[#5B625C]">Add items to your Grocery Shopping List to compare platforms.</p>
        </div>
      ) : (
        <>
          {/* Mode A: Cheapest Product */}
          {mode === 'product' && (
            <div className="bg-white border border-[#E6E3DA] rounded-2xl overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[#E6E3DA] text-xs text-[#5B625C]">
                    <th className="py-3.5 px-4 font-medium">Product & Equivalent Pack</th>
                    {platforms.map((p) => (
                      <th key={p.id} className="py-3.5 px-4 font-medium text-right">
                        {p.name}
                      </th>
                    ))}
                    <th className="py-3.5 px-4 font-medium text-right">Best Option</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EFECE3] text-sm">
                  {comparisons.map((row) => (
                    <tr key={row.groceryItem.id} className="hover:bg-[#FAF9F5]">
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-[#1F2421]">{row.groceryItem.name}</div>
                        <div className="text-xs text-[#5B625C]">
                          {row.offers[0]?.brand} · {row.offers[0]?.packSize}
                          {row.alternativeProduct ? ` · Alt: ${row.alternativeProduct}` : ''}
                        </div>
                      </td>
                      {row.offers.map((offer) => {
                        const isBest = row.cheapestOffer?.platformId === offer.platformId && offer.inStock;
                        return (
                          <td key={offer.platformId} className="py-3.5 px-4 text-right font-mono tabular-nums">
                            {offer.inStock ? (
                              <div>
                                <span className={`font-semibold ${isBest ? 'text-[#4A7C59]' : 'text-[#1F2421]'}`}>
                                  {formatCurrency(offer.priceINR, state.user.currency)}
                                </span>
                                {offer.discountPct > 0 && (
                                  <div className="text-[11px] text-[#5B625C]">{offer.discountPct}% off</div>
                                )}
                              </div>
                            ) : (
                              <span className="text-xs text-[#D97736] font-sans">Out of stock</span>
                            )}
                          </td>
                        );
                      })}
                      <td className="py-3.5 px-4 text-right text-xs">
                        {row.cheapestOffer ? (
                          <div className="inline-flex flex-col items-end gap-0.5">
                            <a
                              href={row.cheapestOffer.searchUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-semibold text-[#4A7C59] hover:underline inline-flex items-center gap-1"
                            >
                              <span>Buy on {row.cheapestOffer.platformName}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                            <div className="text-[#5B625C] font-mono tabular-nums">
                              Save {formatCurrency(row.savingsVsHighestINR, state.user.currency)}
                            </div>
                          </div>
                        ) : (
                          '—'
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Mode B: Cheapest Complete Basket */}
          {mode === 'basket' && (
            <div className="space-y-4">
              {cheapestBasket && (
                <div className="bg-white border border-[#4A7C59] rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold text-[#4A7C59] mb-1">
                      Lowest complete basket (sample estimate)
                    </p>
                    <h3 className="font-display text-xl font-semibold text-[#1F2421]">
                      {cheapestBasket.platform.name} —{' '}
                      <span className="font-mono tabular-nums">
                        {formatCurrency(cheapestBasket.totalPayableINR, state.user.currency)}
                      </span>
                    </h3>
                    <p className="text-xs text-[#5B625C] mt-1">
                      Delivery {cheapestBasket.platform.deliveryTimeLabel} · Saves{' '}
                      <span className="font-mono font-semibold text-[#4A7C59]">
                        {formatCurrency(basketSavingsINR, state.user.currency)}
                      </span>{' '}
                      vs highest platform.
                    </p>
                  </div>
                  <a
                    href={cheapestBasket.platform.storeHomeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5 self-start sm:self-center shrink-0"
                  >
                    <span>Shop on {cheapestBasket.platform.name}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {baskets.map((b) => (
                  <div
                    key={b.platform.id}
                    className={`bg-white border rounded-2xl p-5 flex flex-col justify-between gap-3 ${
                      b.isCheapest ? 'border-[#4A7C59]' : 'border-[#E6E3DA]'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-display text-base font-semibold text-[#1F2421]">{b.platform.name}</h4>
                        <span className="text-[11px] font-medium text-[#5B625C]">
                          {b.dataSource === 'sample' ? 'Sample' : 'Estimated'}
                        </span>
                      </div>
                      <p className="text-xs text-[#5B625C]">{b.platform.deliveryTimeLabel}</p>
                      <div className="space-y-1.5 text-xs pt-2 border-t border-[#EFECE3] tabular-nums">
                        <div className="flex justify-between">
                          <span className="text-[#5B625C]">Items Subtotal</span>
                          <span className="font-mono">{formatCurrency(b.itemsSubtotalINR, state.user.currency)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#5B625C]">Delivery Fee</span>
                          <span className="font-mono">
                            {b.deliveryFeeINR === 0 ? 'Free' : formatCurrency(b.deliveryFeeINR, state.user.currency)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#5B625C]">Platform / Handling</span>
                          <span className="font-mono">{formatCurrency(b.handlingFeeINR, state.user.currency)}</span>
                        </div>
                        <div className="flex justify-between pt-2 border-t border-[#EFECE3] text-sm font-semibold text-[#1F2421]">
                          <span>Total Payable</span>
                          <span className="font-mono">{formatCurrency(b.totalPayableINR, state.user.currency)}</span>
                        </div>
                      </div>
                      {b.unavailableCount > 0 && (
                        <p className="text-xs text-[#D97736]">{b.unavailableCount} item(s) out of stock</p>
                      )}
                      {b.minOrderTopUpNeededINR > 0 && (
                        <p className="text-xs text-[#5B625C] tabular-nums">
                          Add {formatCurrency(b.minOrderTopUpNeededINR, state.user.currency)} to meet minimum order.
                        </p>
                      )}
                    </div>
                    <a
                      href={getStoreHomeUrl(b.platform.name)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`w-full py-2 px-3 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-1.5 ${
                        b.isCheapest
                          ? 'bg-[#4A7C59] text-white hover:bg-[#3D684A]'
                          : 'bg-[#FAF9F5] border border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                      }`}
                    >
                      <span>Open {b.platform.name}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Mode C: Smart Split Shopping */}
          {mode === 'split' && splitPlan && (
            <div className="space-y-4">
              <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6">
                <p className="text-xs font-semibold text-[#4A7C59] mb-1">SMART SPLIT RECOMMENDATION</p>
                <h3 className="font-display text-xl font-bold text-[#1F2421] mb-1">
                  {splitPlan.recommended
                    ? `Split Order Saves ${formatCurrency(splitPlan.netSavingsAfterFeesINR, state.user.currency)} Net`
                    : `Single Platform (${splitPlan.singleBestPlatform.platform.name}) Wins After Delivery Fees`}
                </h3>
                <p className="text-sm text-[#5B625C] mb-4">{splitPlan.reason}</p>
                <div className="grid sm:grid-cols-2 gap-4 text-sm tabular-nums">
                  <div className="bg-[#FAF9F5] border border-[#EFECE3] rounded-xl p-4">
                    <div className="text-xs text-[#5B625C]">Single Best Basket ({splitPlan.singleBestPlatform.platform.name})</div>
                    <div className="font-mono text-lg font-semibold">
                      {formatCurrency(splitPlan.singleBestPlatform.totalPayableINR, state.user.currency)}
                    </div>
                  </div>
                  <div className="bg-[#FAF9F5] border border-[#EFECE3] rounded-xl p-4">
                    <div className="text-xs text-[#5B625C]">Split Basket Grand Total (incl. all fees)</div>
                    <div className="font-mono text-lg font-semibold text-[#4A7C59]">
                      {formatCurrency(splitPlan.splitGrandTotalINR, state.user.currency)}
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {splitPlan.splitPlatforms.map((bucket) => (
                  <div key={bucket.platform.id} className="bg-white border border-[#E6E3DA] rounded-2xl p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-display text-base font-semibold">{bucket.platform.name}</h4>
                      <span className="font-mono text-sm font-semibold text-[#4A7C59] tabular-nums">
                        {formatCurrency(bucket.totalINR, state.user.currency)}
                      </span>
                    </div>
                    <ul className="divide-y divide-[#EFECE3] text-xs">
                      {bucket.items.map(({ item, offer }) => (
                        <li key={item.id} className="py-2 flex justify-between">
                          <span>{item.name}</span>
                          <span className="font-mono tabular-nums">
                            {formatCurrency(offer.priceINR, state.user.currency)}
                          </span>
                        </li>
                      ))}
                    </ul>
                    <div className="pt-2 border-t border-[#EFECE3] text-xs text-[#5B625C] flex justify-between tabular-nums">
                      <span>Delivery + Handling</span>
                      <span className="font-mono">
                        {formatCurrency(bucket.deliveryFeeINR + bucket.handlingFeeINR, state.user.currency)}
                      </span>
                    </div>
                    <a
                      href={bucket.platform.storeHomeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 px-3 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center justify-center gap-1.5"
                    >
                      <span>Shop on {bucket.platform.name}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
