import React, { useMemo, useRef, useState } from 'react';
import { Check, Loader2, Plus, Sparkles, UtensilsCrossed } from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { isNationalIndianCuisine } from '../data/recipes';
import { formatCurrency } from '../i18n/translations';
import { postJson } from '../services/apiClient';
import { Recipe } from '../types/kitchly';
import { FoodImage } from '../components/Logo';

type RegionScope = 'all' | 'national' | 'international';

const MOODS = [
  'Surprise me',
  'Something healthy',
  'Something quick',
  'Something affordable',
  'Something different',
  'Something using my leftovers',
];

export function DontKnowWhatToEatScreen() {
  const { state, allRecipes, openRecipe, addCustomRecipe, addRecipeIngredientsToGrocery, showToast } = useKitchly();
  const [selectedMood, setSelectedMood] = useState('Surprise me');
  const [regionScope, setRegionScope] = useState<RegionScope>('all');
  const [aiSuggestions, setAiSuggestions] = useState<Recipe[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const localFallbackSuggestions = useMemo(() => {
    const allergies = [...state.dietProfile.allergies, ...state.dietProfile.customAllergies].map((a) => a.toLowerCase());
    const safe = allRecipes.filter((r) => !r.allergens.some((a) => allergies.includes(a.toLowerCase())));

    const scored = safe
      .map((r) => {
        let score = 0;
        if (selectedMood === 'Something quick' && r.prepTimeMins <= 20) score += 5;
        if (selectedMood === 'Something healthy' && (r.nutrition.protein >= 16 || r.tags.includes('High-protein'))) score += 5;
        if (selectedMood === 'Something affordable' && r.estimatedCostINR <= 150) score += 5;
        if (selectedMood === 'Something using my leftovers') {
          const pantryMatches = r.ingredients.filter((ing) =>
            state.pantry.some((p) => p.name.toLowerCase().includes(ing.name.toLowerCase()) || ing.name.toLowerCase().includes(p.name.toLowerCase()))
          ).length;
          score += pantryMatches * 2;
        }
        if (state.dietProfile.cuisines.includes(r.cuisine)) score += 2;
        return { r, score };
      })
      .sort((a, b) => b.score - a.score)
      .map((x) => x.r);

    const national = scored.filter((r) => isNationalIndianCuisine(r.cuisine));
    const international = scored.filter((r) => !isNationalIndianCuisine(r.cuisine));

    if (regionScope === 'national') return national.slice(0, 6);
    if (regionScope === 'international') return international.slice(0, 6);
    return [...national.slice(0, 4), ...international.slice(0, 4)];
  }, [allRecipes, selectedMood, regionScope, state.dietProfile, state.pantry]);

  const askGeminiForIdeas = async (mood: string, scope: RegionScope = regionScope) => {
    setSelectedMood(mood);
    setLoading(true);
    setErrorMsg(null);
    try {
      const data = await postJson<{ suggestions?: Recipe[] }>('/api/ai/surprise-meal', {
        mood,
        regionScope: scope,
        profile: state.dietProfile,
        pantryNames: state.pantry.map((p) => p.name),
        language: state.user.language,
      });
      if (Array.isArray(data.suggestions) && data.suggestions.length > 0) {
        data.suggestions.forEach((r: Recipe) => addCustomRecipe(r));
        setAiSuggestions(data.suggestions);
      } else {
        setAiSuggestions(null);
      }
    } catch {
      setAiSuggestions(null);
      setErrorMsg(null);
      showToast(`Showing instant ${mood.toLowerCase()} picks from your kitchen library.`);
    } finally {
      setLoading(false);
    }
  };

  const displayList = useMemo(() => {
    if (aiSuggestions && aiSuggestions.length > 0) {
      const scopedAI = aiSuggestions.filter((r) => {
        if (regionScope === 'national') return isNationalIndianCuisine(r.cuisine);
        if (regionScope === 'international') return !isNationalIndianCuisine(r.cuisine);
        return true;
      });
      if (scopedAI.length > 0) return scopedAI;
    }
    return localFallbackSuggestions;
  }, [aiSuggestions, localFallbackSuggestions, regionScope]);

  const nationalList = useMemo(() => displayList.filter((r) => isNationalIndianCuisine(r.cuisine)), [displayList]);
  const internationalList = useMemo(() => displayList.filter((r) => !isNationalIndianCuisine(r.cuisine)), [displayList]);

  const renderSuggestionCard = (r: Recipe) => (
    <div key={r.id} className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden flex flex-col sm:flex-row">
      <button onClick={() => openRecipe(r)} className="sm:w-44 h-44 sm:h-auto shrink-0">
        <FoodImage src={r.image} alt={r.title} className="w-full h-full object-cover" />
      </button>
      <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <p className="text-xs font-medium text-[#4A7C59] mb-1">
            {r.cuisine} · {r.dietType} · {r.prepTimeMins} mins · {formatCurrency(r.estimatedCostINR, state.user.currency)}
          </p>
          <h3
            onClick={() => openRecipe(r)}
            className="font-display text-base font-semibold text-[#1F2421] hover:text-[#4A7C59] cursor-pointer mb-1.5"
          >
            {r.title}
          </h3>
          <p className="text-xs text-[#5B625C] line-clamp-2">{r.description}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => openRecipe(r)}
            className="px-3.5 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-medium hover:bg-[#3D684A]"
          >
            Cook This
          </button>
          <button
            onClick={() => addRecipeIngredientsToGrocery(r)}
            className="px-3.5 py-2 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-medium hover:bg-[#E7E3D7]"
          >
            Add Missing Items
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 lg:p-8 space-y-5">
        <div>
          <p className="text-xs font-medium text-[#D97736] mb-1">PERSONAL FOOD ASSISTANT</p>
          <h2 className="font-display text-2xl lg:text-3xl font-bold text-[#1F2421] mb-2">
            I Don’t Know What to Eat
          </h2>
          <p className="text-sm text-[#5B625C] max-w-2xl">
            Pick a vibe and Kitchly checks your allergies ({state.dietProfile.allergies.join(', ') || 'none'}),
            dislikes, pantry stock ({state.pantry.length} items), cooking time, and daily budget across Indian & global kitchens.
          </p>
        </div>

        {/* National (Indian) vs International Selector */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
            {([
              { id: 'all', label: 'All Cuisines (National + International)' },
              { id: 'national', label: 'National · Indian Kitchen' },
              { id: 'international', label: 'International · Global' },
            ] as const).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setRegionScope(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  regionScope === tab.id ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C] hover:text-[#1F2421]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {MOODS.map((mood) => {
            const active = selectedMood === mood;
            return (
              <button
                key={mood}
                onClick={() => askGeminiForIdeas(mood, regionScope)}
                disabled={loading}
                className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  active
                    ? 'bg-[#D97736] text-white'
                    : 'bg-[#F3F1EA] text-[#1F2421] hover:bg-[#E7E3D7]'
                }`}
              >
                {mood}
              </button>
            );
          })}
        </div>

        <button
          onClick={() => askGeminiForIdeas(selectedMood, regionScope)}
          disabled={loading}
          className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] inline-flex items-center gap-2"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          <span>{loading ? 'Thinking of meals for you...' : 'Generate Fresh AI Picks'}</span>
        </button>

        {errorMsg && (
          <p className="text-xs text-[#9A4A18]">
            {errorMsg} Showing your smart local preference matches below.
          </p>
        )}
      </div>

      {displayList.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 text-center space-y-3">
          <p className="font-display text-base font-semibold text-[#1F2421]">
            No local recipes fit every active allergy filter
          </p>
          <p className="text-xs text-[#5B625C] max-w-md mx-auto">
            Let Kitchly AI craft custom meal suggestions strictly excluding your allergies and dislikes.
          </p>
          <button
            type="button"
            onClick={() => askGeminiForIdeas(selectedMood, regionScope)}
            disabled={loading}
            className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Generate Safe AI Picks</span>
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {[
            { title: 'National · Indian Kitchen Picks', subtitle: 'Rajma Chawal, Egg Curry, Mutton Biryani, Dal Tadka & everyday favorites', accent: 'text-[#9A4A18]', items: nationalList },
            { title: 'International · Global Kitchen Picks', subtitle: 'Italian, Mediterranean, Korean, Mexican, Thai & Continental classics', accent: 'text-[#4A7C59]', items: internationalList },
          ]
            .filter((sec) => sec.items.length > 0)
            .map((sec) => (
              <section key={sec.title} className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 border-b border-[#EFECE3] pb-2">
                  <div>
                    <h3 className={`font-display text-lg font-bold ${sec.accent}`}>{sec.title}</h3>
                    <p className="text-xs text-[#5B625C]">{sec.subtitle}</p>
                  </div>
                  <span className="text-xs text-[#5B625C] tabular-nums">
                    {sec.items.length} idea{sec.items.length === 1 ? '' : 's'}
                  </span>
                </div>
                <div className="grid md:grid-cols-2 gap-5">{sec.items.map(renderSuggestionCard)}</div>
              </section>
            ))}
        </div>
      )}
    </div>
  );
}

const COMMON_STAPLES = [
  'Rice',
  'Eggs',
  'Rajma (Kidney Beans)',
  'Tomatoes',
  'Onions',
  'Potatoes',
  'Paneer',
  'Chicken',
  'Mutton / Meat',
  'Poha',
  'Toor Dal',
  'Milk',
  'Cheese',
  'Chickpeas',
  'Spinach',
  'Tofu',
  'Garam Masala',
];

export function CookWithWhatIHaveScreen() {
  const { state, allRecipes, openRecipe, addCustomRecipe, addRecipeIngredientsToGrocery, showToast } = useKitchly();

  const [selectedIngredients, setSelectedIngredients] = useState<string[]>(() =>
    Array.from(new Set(state.pantry.map((p) => p.name)))
  );
  const [regionScope, setRegionScope] = useState<RegionScope>('all');
  const [customIng, setCustomIng] = useState('');
  const customInputRef = useRef<HTMLInputElement>(null);
  const [aiRecipes, setAiRecipes] = useState<Recipe[]>([]);
  const [loadingAI, setLoadingAI] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const toggleIng = (name: string) => {
    const exists = selectedIngredients.some((x) => x.toLowerCase() === name.toLowerCase());
    setSelectedIngredients((prev) =>
      exists ? prev.filter((x) => x.toLowerCase() !== name.toLowerCase()) : [...prev, name]
    );
  };

  const addCustom = () => {
    const parts = customIng.split(',').map((s) => s.trim()).filter(Boolean);
    if (parts.length === 0) {
      showToast('Type an ingredient first (e.g. brown bread, paneer).');
      customInputRef.current?.focus();
      return;
    }
    const existingLower = new Set(selectedIngredients.map((x) => x.toLowerCase()));
    const added: string[] = [];
    const next = [...selectedIngredients];
    parts.forEach((p) => {
      if (!existingLower.has(p.toLowerCase())) {
        existingLower.add(p.toLowerCase());
        next.push(p);
        added.push(p);
      }
    });
    setSelectedIngredients(next);
    setCustomIng('');
    if (added.length > 0) {
      showToast(`Added ${added.join(', ')} to your ingredients.`);
    } else {
      showToast(`${parts.join(', ')} already selected.`);
    }
  };

  const combinedPool = useMemo(() => {
    const map = new Map<string, Recipe>();
    [...allRecipes, ...aiRecipes].forEach((r) => map.set(r.id, r));
    return Array.from(map.values());
  }, [allRecipes, aiRecipes]);

  const rankedMatches = useMemo(() => {
    const haveLower = selectedIngredients.map((s) => s.toLowerCase());
    return combinedPool
      .filter((recipe) => {
        if (regionScope === 'national') return isNationalIndianCuisine(recipe.cuisine);
        if (regionScope === 'international') return !isNationalIndianCuisine(recipe.cuisine);
        return true;
      })
      .map((recipe) => {
        const available: string[] = [];
        const missing: string[] = [];
        recipe.ingredients.forEach((ing) => {
          const ingL = ing.name.toLowerCase();
          const hasIt = haveLower.some((h) => {
            const cleanH = h.replace(/\(.*?\)/g, '').trim();
            return (
              ingL.includes(h) ||
              h.includes(ingL) ||
              (cleanH.length >= 3 && ingL.includes(cleanH)) ||
              (h.includes('meat') && (ingL.includes('mutton') || ingL.includes('chicken') || ingL.includes('meat'))) ||
              (h.includes('mutton') && ingL.includes('mutton'))
            );
          });
          if (hasIt) available.push(ing.name);
          else missing.push(`${ing.name} (${ing.quantity} ${ing.unit})`);
        });
        const matchPct = recipe.ingredients.length
          ? Math.round((available.length / recipe.ingredients.length) * 100)
          : 0;
        const missingCostINR =
          recipe.ingredients.length > 0
            ? Math.round((recipe.estimatedCostINR * missing.length) / recipe.ingredients.length)
            : 0;
        return { recipe, available, missing, matchPct, missingCostINR };
      })
      .filter((x) => x.available.length > 0)
      .sort((a, b) => b.matchPct - a.matchPct || a.missing.length - b.missing.length);
  }, [combinedPool, selectedIngredients, regionScope]);

  const nationalMatches = useMemo(
    () => rankedMatches.filter((m) => isNationalIndianCuisine(m.recipe.cuisine)),
    [rankedMatches]
  );
  const internationalMatches = useMemo(
    () => rankedMatches.filter((m) => !isNationalIndianCuisine(m.recipe.cuisine)),
    [rankedMatches]
  );

  const generateWithGemini = async () => {
    if (selectedIngredients.length === 0) return;
    setLoadingAI(true);
    setErrorMsg(null);
    try {
      const data = await postJson<{ recipes?: Recipe[] }>('/api/ai/pantry-recipes', {
        ingredients: selectedIngredients,
        regionScope,
        allergies: [...state.dietProfile.allergies, ...state.dietProfile.customAllergies],
        dislikes: [...state.dietProfile.dislikedIngredients, ...state.dietProfile.neverRecommend],
        language: state.user.language,
      });
      if (Array.isArray(data.recipes) && data.recipes.length > 0) {
        data.recipes.forEach((r: Recipe) => addCustomRecipe(r));
        setAiRecipes(data.recipes);
        return;
      }
    } catch {
      // Fall through cleanly to local instant recipe synthesis
    } finally {
      setLoadingAI(false);
    }

    const sample = selectedIngredients.slice(0, 5);
    const label = sample.slice(0, 3).join(', ');
    const indianSkillet: Recipe = {
      id: `local-pantry-ind-${Date.now()}`,
      title: `Home-Style ${label} Masala Skillet`,
      cuisine: 'Indian',
      dietType: state.dietProfile.foodPreferences[0] || 'Flexitarian',
      prepTimeMins: 18,
      difficulty: 'Easy',
      servings: 2,
      estimatedCostINR: 95,
      image: '/src/assets/images/meal_dinner_indian_1795377616543.jpg',
      description: `Quick Indian pan dish built directly around your available kitchen items (${sample.join(', ')}) with light oil and everyday spices.`,
      mealSlot: 'Lunch',
      allergens: [],
      tags: ['Quick', 'Low oil', 'Zero sugar'],
      nutrition: { calories: 310, protein: 14, carbs: 34, fat: 9 },
      ingredients: sample.map((item) => ({ name: item, quantity: 1, unit: 'portion', category: 'Vegetables' })),
      instructions: [
        `Prep and portion ${sample.join(', ')} neatly.`,
        'Warm 1 tsp oil with cumin seeds and garlic, then toss your main ingredients for 6-8 minutes.',
        'Season lightly with turmeric, salt, and black pepper; serve hot.',
      ],
    };
    const globalBowl: Recipe = {
      id: `local-pantry-intl-${Date.now() + 1}`,
      title: `Light Herb ${label} Plate`,
      cuisine: 'Continental',
      dietType: state.dietProfile.foodPreferences[0] || 'Flexitarian',
      prepTimeMins: 12,
      difficulty: 'Easy',
      servings: 1,
      estimatedCostINR: 85,
      image: '/src/assets/images/meal_lunch_bowl_1795377616141.jpg',
      description: `Simple international-style portion combining ${sample.join(', ')} with minimal oil and zero added sugar.`,
      mealSlot: 'Dinner',
      allergens: [],
      tags: ['Quick', 'Low oil', 'Zero sugar', 'Less fat'],
      nutrition: { calories: 270, protein: 13, carbs: 28, fat: 8 },
      ingredients: sample.map((item) => ({ name: item, quantity: 1, unit: 'serving', category: 'Grains' })),
      instructions: [
        `Dry-toast or steam ${sample.join(', ')} separately for clean texture.`,
        'Finish with lemon juice, black pepper, and fresh herbs.',
      ],
    };
    const localOut =
      regionScope === 'national'
        ? [indianSkillet]
        : regionScope === 'international'
        ? [globalBowl]
        : [indianSkillet, globalBowl];
    localOut.forEach((r) => addCustomRecipe(r));
    setAiRecipes(localOut);
    setErrorMsg(null);
    showToast(`Created instant recipes using ${label}!`);
  };

  const chipOptions = Array.from(new Set([...state.pantry.map((p) => p.name), ...COMMON_STAPLES]));

  const renderMatchCard = ({
    recipe,
    available,
    missing,
    matchPct,
    missingCostINR,
  }: (typeof rankedMatches)[number]) => (
    <div key={recipe.id} className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden flex flex-col">
      <div className="h-40 overflow-hidden">
        <FoodImage src={recipe.image} alt={recipe.title} className="w-full h-full object-cover" />
      </div>
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <p className="text-xs font-semibold text-[#4A7C59] mb-1 tabular-nums">
            {matchPct}% Pantry Match · {recipe.cuisine} · {recipe.prepTimeMins} mins · {recipe.nutrition.calories} kcal
          </p>
          <h3
            onClick={() => openRecipe(recipe)}
            className="font-display text-lg font-semibold text-[#1F2421] hover:text-[#4A7C59] cursor-pointer mb-2"
          >
            {recipe.title}
          </h3>

          <div className="space-y-2 text-xs">
            <div>
              <span className="font-semibold text-[#4A7C59]">Already available: </span>
              <span className="text-[#1F2421]">{available.join(', ')}</span>
            </div>
            <div>
              <span className="font-semibold text-[#D97736]">Missing: </span>
              <span className="text-[#5B625C]">
                {missing.length > 0 ? missing.join(', ') : 'Nothing! You have everything.'}
              </span>
            </div>
            <div className="font-mono text-[#1F2421] tabular-nums">
              Additional estimated cost: {formatCurrency(missingCostINR, state.user.currency)}
            </div>
          </div>
        </div>

        <div className="flex gap-2 pt-2 border-t border-[#EFECE3]">
          <button
            onClick={() => openRecipe(recipe)}
            className="flex-1 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A]"
          >
            View Instructions
          </button>
          {missing.length > 0 && (
            <button
              onClick={() => addRecipeIngredientsToGrocery(recipe)}
              className="px-3.5 py-2 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-medium hover:bg-[#E7E3D7]"
            >
              Add Missing to List
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-[#1F2421]">Cook With What You Have</h2>
            <p className="text-sm text-[#5B625C]">
              Select available ingredients from your kitchen to match Indian (National) & International recipes with minimal shopping.
            </p>
          </div>
          <button
            onClick={generateWithGemini}
            disabled={loadingAI || selectedIngredients.length === 0}
            className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] disabled:opacity-50 inline-flex items-center gap-2 shrink-0"
          >
            {loadingAI ? <Loader2 className="w-4 h-4 animate-spin" /> : <UtensilsCrossed className="w-4 h-4" />}
            <span>{loadingAI ? 'Finding AI Recipes...' : 'Find More AI Recipes'}</span>
          </button>
        </div>

        {/* National vs International Section Filter */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
            {([
              { id: 'all', label: 'All (National + International)' },
              { id: 'national', label: 'National · Indian' },
              { id: 'international', label: 'International · Global' },
            ] as const).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setRegionScope(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  regionScope === tab.id ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C] hover:text-[#1F2421]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          {selectedIngredients.length > 0 && (
            <button
              type="button"
              onClick={() => setSelectedIngredients([])}
              className="text-xs font-medium text-[#5B625C] hover:text-[#1F2421] underline"
            >
              Clear selected ({selectedIngredients.length})
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {chipOptions.map((item) => {
            const active = selectedIngredients.some((x) => x.toLowerCase() === item.toLowerCase());
            return (
              <button
                key={item}
                type="button"
                onClick={() => toggleIng(item)}
                className={`px-3.5 py-2 rounded-xl text-xs font-medium border inline-flex items-center gap-1.5 ${
                  active
                    ? 'bg-[#4A7C59] text-white border-[#4A7C59]'
                    : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421]'
                }`}
              >
                {active && <Check className="w-3.5 h-3.5" />}
                <span>{item}</span>
              </button>
            );
          })}
          {selectedIngredients
            .filter((item) => !chipOptions.some((c) => c.toLowerCase() === item.toLowerCase()))
            .map((custom) => (
              <button
                key={`custom-${custom}`}
                type="button"
                onClick={() => toggleIng(custom)}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold border bg-[#4A7C59] text-white border-[#4A7C59] inline-flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>{custom} ×</span>
              </button>
            ))}
        </div>

        <div className="flex gap-2 max-w-md">
          <input
            ref={customInputRef}
            value={customIng}
            onChange={(e) => setCustomIng(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCustom())}
            placeholder="Add another ingredient you have..."
            className="flex-1 h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
          <button
            type="button"
            onClick={addCustom}
            className="px-4 h-10 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add</span>
          </button>
        </div>

        {errorMsg && <p className="text-xs text-[#9A4A18]">{errorMsg}</p>}
      </div>

      {selectedIngredients.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 text-center space-y-4">
          <UtensilsCrossed className="w-8 h-8 text-[#4A7C59] mx-auto" />
          <div className="space-y-1">
            <h3 className="font-display text-lg font-semibold text-[#1F2421]">
              Pick ingredients above or start with a kitchen combo
            </h3>
            <p className="text-sm text-[#5B625C] max-w-md mx-auto">
              Select what is currently in your fridge or spice rack to see Indian & International matches ranked by pantry coverage.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {[
              { label: 'Rajma + Rice + Onions + Tomatoes', items: ['Rajma (Kidney Beans)', 'Rice', 'Onions', 'Tomatoes'] },
              { label: 'Eggs + Tomatoes + Onions + Rice', items: ['Eggs', 'Tomatoes', 'Onions', 'Rice'] },
              { label: 'Mutton / Meat + Rice + Onions', items: ['Mutton / Meat', 'Rice', 'Onions'] },
              { label: 'Eggs + Potatoes + Onions', items: ['Eggs', 'Potatoes', 'Onions'] },
              { label: 'Chickpeas + Spinach + Tomatoes', items: ['Chickpeas', 'Spinach', 'Tomatoes'] },
            ].map((combo) => (
              <button
                key={combo.label}
                type="button"
                onClick={() => setSelectedIngredients(combo.items)}
                className="px-3.5 py-2 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7]"
              >
                {combo.label}
              </button>
            ))}
            {state.pantry.length > 0 && (
              <button
                type="button"
                onClick={() => setSelectedIngredients(Array.from(new Set(state.pantry.map((p) => p.name))))}
                className="px-3.5 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold"
              >
                Load My Pantry ({state.pantry.length})
              </button>
            )}
          </div>
        </div>
      ) : rankedMatches.length === 0 ? (
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 text-center space-y-3">
          <p className="font-display text-base font-semibold text-[#1F2421]">
            No library recipes match "{selectedIngredients.join(', ')}" in this section yet
          </p>
          <p className="text-xs text-[#5B625C]">
            Tap Find More AI Recipes to let Kitchly invent dishes using your exact ingredients.
          </p>
          <button
            type="button"
            onClick={generateWithGemini}
            disabled={loadingAI}
            className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
          >
            {loadingAI ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            <span>Find AI Recipes with These Ingredients</span>
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {[
            { title: 'National · Indian Kitchen Matches', accent: 'text-[#9A4A18]', items: nationalMatches },
            { title: 'International · Global Kitchen Matches', accent: 'text-[#4A7C59]', items: internationalMatches },
          ]
            .filter((sec) => sec.items.length > 0)
            .map((sec) => (
              <section key={sec.title} className="space-y-3">
                <div className="flex items-center justify-between border-b border-[#EFECE3] pb-2">
                  <h3 className={`font-display text-lg font-bold ${sec.accent}`}>{sec.title}</h3>
                  <span className="text-xs text-[#5B625C] tabular-nums">
                    {sec.items.length} recipe{sec.items.length === 1 ? '' : 's'}
                  </span>
                </div>
                <div className="grid md:grid-cols-2 gap-5">{sec.items.map(renderMatchCard)}</div>
              </section>
            ))}
        </div>
      )}
    </div>
  );
}
