import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Copy,
  ExternalLink,
  Flame,
  Plus,
  RefreshCw,
  Search,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  Store,
  Users,
  Utensils,
  Wallet,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { CURRENCY_RATES, formatCurrency } from '../i18n/translations';
import {
  STORE_BROWSE_CATALOG,
  findPlatformConfigByName,
  generateProductComparisons,
  getPlatformsForRegion,
  getStoreHomeUrl,
  getStoreItemSearchUrl,
} from '../services/groceryAdapter';
import { postJson } from '../services/apiClient';
import {
  DietType,
  GroceryCategory,
  GroceryItem,
  Recipe,
} from '../types/kitchly';
import { FoodImage } from '../components/Logo';

interface StoreOption {
  id: string;
  name: string;
  region: 'Global' | 'India';
  note: string;
}

const STORE_OPTIONS: StoreOption[] = [
  { id: 'walmart', name: 'Walmart', region: 'Global', note: 'Everyday low prices' },
  { id: 'costco', name: 'Costco', region: 'Global', note: 'Bulk warehouse value' },
  { id: 'kroger', name: 'Kroger', region: 'Global', note: 'Fresh produce & weekly deals' },
  { id: 'aldi', name: 'Aldi', region: 'Global', note: 'Smart budget staples' },
  { id: 'target', name: 'Target', region: 'Global', note: 'Good & Gather picks' },
  { id: 'publix', name: 'Publix', region: 'Global', note: 'Fresh bakery & deli' },
  { id: 'safeway', name: 'Safeway', region: 'Global', note: 'Neighborhood essentials' },
  { id: 'wholefoods', name: 'Whole Foods', region: 'Global', note: 'Organic & specialty' },
  { id: 'traderjoes', name: "Trader Joe's", region: 'Global', note: 'Curated pantry favorites' },
  { id: 'samsclub', name: "Sam's Club", region: 'Global', note: 'Family pack savings' },
  { id: 'heb', name: 'H-E-B', region: 'Global', note: 'Fresh local market' },
  { id: 'blinkit', name: 'Blinkit', region: 'India', note: '10-min express grocery' },
  { id: 'zepto', name: 'Zepto', region: 'India', note: 'Fast urban delivery' },
  { id: 'instamart', name: 'Swiggy Instamart', region: 'India', note: 'Quick daily essentials' },
  { id: 'bigbasket', name: 'BigBasket', region: 'India', note: 'Full weekly basket' },
  { id: 'dmart', name: 'DMart Ready', region: 'India', note: 'Value household staples' },
  { id: 'reliance', name: 'Reliance Fresh', region: 'India', note: 'Produce & grains' },
];

const MEAL_SLOT_OPTIONS = ['Breakfast', 'Lunch', 'Dinner', 'Snacks'] as const;

const DAY_OPTIONS = [
  { short: 'M', full: 'Monday' },
  { short: 'T', full: 'Tuesday' },
  { short: 'W', full: 'Wednesday' },
  { short: 'T', full: 'Thursday' },
  { short: 'F', full: 'Friday' },
  { short: 'S', full: 'Saturday' },
  { short: 'S', full: 'Sunday' },
];

const APPLIANCE_OPTIONS = [
  'Stove',
  'Oven',
  'Microwave',
  'Toaster',
  'Blender',
  'Air Fryer',
  'Pressure Cooker',
  'Crock-Pot',
];

const EATING_STYLE_OPTIONS = [
  'No Restrictions',
  'Vegetarian',
  'Vegan',
  'Pescatarian',
  'Keto',
  'High-protein',
  'GLP-1 friendly',
  'Anti-inflammatory',
  'Mediterranean',
  'Mexican',
  'Indian',
];

const VIBE_OPTIONS = [
  { label: 'Quick & Easy', sub: 'Under 25 mins' },
  { label: 'One-Pan', sub: 'Minimal cleanup' },
  { label: 'Batch Cook', sub: 'Cook once, eat twice' },
  { label: 'Family Favorites', sub: 'Kid & crowd friendly' },
  { label: 'Comfort Classics', sub: 'Warm & hearty' },
  { label: 'Fresh & Light', sub: 'Crisp & vibrant' },
  { label: 'Fiber-Forward', sub: 'Wholesome grains & greens' },
  { label: 'Takeout at Home', sub: 'Restaurant flavors' },
];

const ALLERGY_OPTIONS = [
  'No allergies',
  'Peanuts',
  'Tree nuts',
  'Dairy',
  'Eggs',
  'Gluten (wheat)',
  'Soy',
  'Shellfish',
  'Fish',
  'Sesame',
];

const DISLIKE_SUGGESTIONS = [
  'Beef',
  'Bell peppers',
  'Mushrooms',
  'Spicy food',
  'Pork',
  'Tomatoes',
  'Eggplant',
  'Avocado',
  'Coconut',
  'Lamb',
  'Shellfish',
  'Chicken',
  'Broccoli',
  'Cilantro',
  'Turkey',
  'Salmon',
  'Shrimp',
  'Pickles',
  'Onions',
  'Fish',
  'Honey',
  'Olives',
  'Tuna',
  'Corn',
  'Eggs',
  'Tofu',
  'Kale',
  'Okra',
  'Bitter Gourd',
];

interface PantryTile {
  name: string;
  group: 'Fresh' | 'Meat' | 'Fridge' | 'Pantry';
}

const PANTRY_TILES: PantryTile[] = [
  { name: 'Onions', group: 'Fresh' },
  { name: 'Garlic', group: 'Fresh' },
  { name: 'Tomatoes', group: 'Fresh' },
  { name: 'Potatoes', group: 'Fresh' },
  { name: 'Spinach', group: 'Fresh' },
  { name: 'Bell Peppers', group: 'Fresh' },
  { name: 'Carrots', group: 'Fresh' },
  { name: 'Lemons', group: 'Fresh' },
  { name: 'Avocado', group: 'Fresh' },
  { name: 'Chicken Breast', group: 'Meat' },
  { name: 'Ground Turkey', group: 'Meat' },
  { name: 'Salmon Fillets', group: 'Meat' },
  { name: 'Shrimp', group: 'Meat' },
  { name: 'Eggs', group: 'Fridge' },
  { name: 'Milk', group: 'Fridge' },
  { name: 'Greek Yogurt', group: 'Fridge' },
  { name: 'Paneer / Tofu', group: 'Fridge' },
  { name: 'Cheddar Cheese', group: 'Fridge' },
  { name: 'Butter', group: 'Fridge' },
  { name: 'Olive Oil', group: 'Pantry' },
  { name: 'Basmati Rice', group: 'Pantry' },
  { name: 'Pasta', group: 'Pantry' },
  { name: 'Quinoa', group: 'Pantry' },
  { name: 'Oats', group: 'Pantry' },
  { name: 'Black Beans', group: 'Pantry' },
  { name: 'Chickpeas', group: 'Pantry' },
  { name: 'Red Lentils', group: 'Pantry' },
  { name: 'Soy Sauce', group: 'Pantry' },
];

const BUILD_STAGES = [
  'Browsing store catalog',
  'Selecting your recipes',
  'Costing your basket',
  'Checking the budget',
  'Finalizing your plan',
];

const VALID_CATEGORIES: GroceryCategory[] = [
  'Vegetables',
  'Fruits',
  'Dairy',
  'Meat and seafood',
  'Grains',
  'Bakery',
  'Spices',
  'Beverages',
  'Household essentials',
];

function normalizeCategory(raw: string): GroceryCategory {
  const found = VALID_CATEGORIES.find((c) => c.toLowerCase() === raw.toLowerCase());
  if (found) return found;
  const lower = raw.toLowerCase();
  if (lower.includes('produce') || lower.includes('veg')) return 'Vegetables';
  if (lower.includes('fruit')) return 'Fruits';
  if (lower.includes('dairy') || lower.includes('egg')) return 'Dairy';
  if (lower.includes('meat') || lower.includes('seafood')) return 'Meat and seafood';
  if (lower.includes('bak') || lower.includes('bread')) return 'Bakery';
  if (lower.includes('spice') || lower.includes('condiment')) return 'Spices';
  if (lower.includes('bev') || lower.includes('drink')) return 'Beverages';
  return 'Grains';
}

interface WizardMeal extends Recipe {
  dayLabel: string;
}

interface WizardGroceryItem extends GroceryItem {
  storeSection: string;
  packNote: string;
}

function formatWizardError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err || '');
  if (raw.toLowerCase().includes('abort') || raw.toLowerCase().includes('timed out')) {
    return 'The AI planner took too long on this connection. You can tap Try Again or use Instant Smart Basket below.';
  }
  if (
    raw.includes('503') ||
    raw.includes('UNAVAILABLE') ||
    raw.includes('high demand') ||
    raw.trim().startsWith('{')
  ) {
    return 'Our meal planner AI is experiencing a brief traffic spike. Please tap Try Again or use Instant Smart Basket below.';
  }
  return raw || 'Unable to generate your trip plan right now.';
}

function mapCategoryToStoreSection(category: GroceryCategory): string {
  switch (category) {
    case 'Vegetables':
    case 'Fruits':
      return 'Produce';
    case 'Meat and seafood':
      return 'Meat & Seafood';
    case 'Dairy':
      return 'Dairy & Eggs';
    case 'Bakery':
      return 'Bakery';
    case 'Spices':
      return 'Condiments & Spices';
    default:
      return 'Canned & Pantry';
  }
}

export function GroceryWizardScreen() {
  const {
    state,
    allRecipes,
    openRecipe,
    addCustomRecipe,
    saveGroceryItem,
    savePantryItem,
    updateDietProfile,
    updateWeeklySlot,
    showToast,
    setScreen,
  } = useKitchly();

  // Wizard phase: 1..12 = questions, 13 = building animation, 14 = results
  const [step, setStep] = useState<number>(1);

  // Step 1: Stores
  const [storeRegion, setStoreRegion] = useState<'Global' | 'India'>(
    state.user.country.toLowerCase() === 'india' ? 'India' : 'Global'
  );
  const [selectedStores, setSelectedStores] = useState<string[]>(
    state.user.country.toLowerCase() === 'india' ? ['Blinkit'] : ['Trader Joe\'s']
  );

  // Step 2: Household portions
  const [adults, setAdults] = useState<number>(Math.max(1, state.dietProfile.householdSize || 2));
  const [kids, setKids] = useState<number>(0);

  // Step 3: Meal slots
  const [mealSlots, setMealSlots] = useState<string[]>(['Breakfast', 'Lunch', 'Dinner']);

  // Step 4: Days of week
  const [days, setDays] = useState<string[]>(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']);

  // Step 5: Appliances
  const [appliances, setAppliances] = useState<string[]>(['Stove', 'Oven', 'Microwave']);

  // Step 6: Eating styles
  const [eatingStyles, setEatingStyles] = useState<string[]>(() => {
    const base = state.dietProfile.foodPreferences || [];
    return base.length > 0 ? [...base] : ['No Restrictions'];
  });

  // Step 7: Meal vibe
  const [vibes, setVibes] = useState<string[]>(['Quick & Easy', 'Family Favorites']);

  // Step 8: Calorie target
  const [hasCalorieTarget, setHasCalorieTarget] = useState<boolean>(Boolean(state.dietProfile.calorieTarget));
  const [calorieTarget, setCalorieTarget] = useState<number>(state.dietProfile.calorieTarget || 1800);

  // Step 9: Allergies
  const [allergies, setAllergies] = useState<string[]>(() => {
    const mapped = (state.dietProfile.allergies || []).map((a) =>
      a.toLowerCase().includes('nut') ? 'Tree nuts' : a
    );
    return mapped.length > 0 ? mapped : ['No allergies'];
  });

  // Step 10: Dislikes
  const [dislikes, setDislikes] = useState<string[]>(() => [
    ...(state.dietProfile.dislikedIngredients || []),
    ...(state.dietProfile.neverRecommend || []),
  ]);
  const [dislikeSearch, setDislikeSearch] = useState('');
  const [customDislike, setCustomDislike] = useState('');

  // Step 11: Pantry already have
  const [pantryTab, setPantryTab] = useState<'All' | 'Fresh' | 'Meat' | 'Fridge' | 'Pantry'>('All');
  const [alreadyHave, setAlreadyHave] = useState<string[]>(() =>
    state.pantry.map((p) => p.name)
  );
  const [customPantryInput, setCustomPantryInput] = useState('');

  // Step 12: Weekly budget in user currency
  const currencyCfg = CURRENCY_RATES[state.user.currency] || CURRENCY_RATES.INR;
  const fallbackBudgetINR = state.user.currency === 'INR' ? 1500 : 2500;
  const effectiveWeeklyBudgetINR = state.dietProfile.weeklyBudget > 0 ? state.dietProfile.weeklyBudget : fallbackBudgetINR;
  const initialDisplayBudget = useMemo(() => {
    const raw = effectiveWeeklyBudgetINR * currencyCfg.rateFromINR;
    return state.user.currency === 'INR' ? Math.round(raw / 50) * 50 : Math.round(raw);
  }, [effectiveWeeklyBudgetINR, currencyCfg.rateFromINR, state.user.currency]);
  const [budgetDisplayAmount, setBudgetDisplayAmount] = useState<number>(
    Math.max(state.user.currency === 'INR' ? 300 : 15, initialDisplayBudget)
  );

  useEffect(() => {
    setAlreadyHave(state.pantry.map((p) => p.name));
  }, [state.user.id, state.pantry]);

  useEffect(() => {
    setBudgetDisplayAmount(Math.max(state.user.currency === 'INR' ? 300 : 15, initialDisplayBudget));
  }, [state.user.id, initialDisplayBudget, state.user.currency]);

  // Step 13 & 14: Building & Results
  const [buildStageIdx, setBuildStageIdx] = useState(0);
  const [elapsedSecs, setElapsedSecs] = useState(0);
  const [buildError, setBuildError] = useState<string | null>(null);
  const [meals, setMeals] = useState<WizardMeal[]>([]);
  const [groceryItems, setGroceryItems] = useState<WizardGroceryItem[]>([]);
  const [showGrocerySection, setShowGrocerySection] = useState(true);
  const [swappingIdx, setSwappingIdx] = useState<number | null>(null);
  const [addedToMainList, setAddedToMainList] = useState(false);
  const [appliedToWeek, setAppliedToWeek] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const portionsPerMeal = Math.round((adults + kids * 0.5) * 10) / 10;
  const servingsPerWeek = Math.max(1, Math.round(portionsPerMeal * mealSlots.length * days.length));
  const weeklyBudgetINR = Math.round(budgetDisplayAmount / Math.max(0.0001, currencyCfg.rateFromINR));
  const perServingDisplay = (budgetDisplayAmount / servingsPerWeek).toFixed(2);

  const toggleItem = (list: string[], setList: (v: string[]) => void, value: string, allowEmpty = false) => {
    if (list.includes(value)) {
      if (!allowEmpty && list.length <= 1) return;
      setList(list.filter((x) => x !== value));
    } else {
      setList([...list, value]);
    }
  };

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  useEffect(() => {
    if (step !== 13 || buildError) {
      setElapsedSecs(0);
      return;
    }
    setBuildStageIdx(0);
    setElapsedSecs(0);
    const stageInterval = setInterval(() => {
      setBuildStageIdx((prev) => (prev < BUILD_STAGES.length - 1 ? prev + 1 : prev));
    }, 1000);
    const timerInterval = setInterval(() => {
      setElapsedSecs((prev) => prev + 1);
    }, 1000);
    return () => {
      clearInterval(stageInterval);
      clearInterval(timerInterval);
    };
  }, [step, buildError]);

  const buildLocalTripPlan = (noticeToast?: string) => {
    abortControllerRef.current?.abort();
    const cleanAllergies = allergies.filter((a) => a !== 'No allergies').map((a) => a.toLowerCase());
    const cleanDislikes = dislikes.map((d) => d.toLowerCase());
    const exclusions = [...cleanAllergies, ...cleanDislikes];
    const pantryLower = alreadyHave.map((p) => p.toLowerCase());
    const stylesLower = eatingStyles.map((s) => s.toLowerCase());

    const isSafeRecipe = (r: Recipe) => {
      const allergenMatch = r.allergens.some((a) =>
        cleanAllergies.some((ex) => a.toLowerCase().includes(ex) || ex.includes(a.toLowerCase()))
      );
      if (allergenMatch) return false;
      const ingredientMatch = r.ingredients.some((ing) =>
        exclusions.some((ex) => ing.name.toLowerCase().includes(ex))
      );
      if (ingredientMatch) return false;
      if (cleanDislikes.some((ex) => r.title.toLowerCase().includes(ex))) return false;
      return true;
    };

    const matchesDiet = (r: Recipe) => {
      if (stylesLower.includes('no restrictions')) return true;
      const diet = r.dietType.toLowerCase();
      const cuisine = r.cuisine.toLowerCase();
      const tags = r.tags.map((t) => t.toLowerCase());
      if (stylesLower.includes('vegan') && diet !== 'vegan') return false;
      if (stylesLower.includes('vegetarian') && !['vegetarian', 'vegan'].includes(diet)) return false;
      if (stylesLower.includes('pescatarian') && !['vegetarian', 'vegan', 'pescatarian'].includes(diet)) return false;
      if (stylesLower.includes('indian') && cuisine.includes('indian')) return true;
      if (stylesLower.includes('high-protein') && (r.nutrition.protein >= 18 || tags.some((t) => t.includes('protein')))) return true;
      return true;
    };

    let candidates = allRecipes.filter((r) => isSafeRecipe(r) && matchesDiet(r));
    if (candidates.length < 4) {
      candidates = allRecipes.filter(isSafeRecipe);
    }
    if (candidates.length === 0) {
      candidates = allRecipes;
    }
    if (weeklyBudgetINR <= 2200) {
      candidates = [...candidates].sort((a, b) => a.estimatedCostINR - b.estimatedCostINR);
    }

    const desiredCount = Math.min(5, Math.max(4, days.length));
    const chosenMeals: WizardMeal[] = [];
    for (let i = 0; i < desiredCount; i++) {
      const targetSlot = mealSlots[i % Math.max(1, mealSlots.length)] || 'Dinner';
      const slotNormalized = targetSlot === 'Snacks' ? 'Snack' : targetSlot;
      const slotCandidate =
        candidates.find(
          (r) =>
            ((r.mealSlot || 'Dinner').toLowerCase() === slotNormalized.toLowerCase() || !chosenMeals.length) &&
            !chosenMeals.some((m) => m.id === r.id)
        ) || candidates[i % candidates.length];
      const dayShort = (days[i % Math.max(1, days.length)] || 'Monday').slice(0, 3).toUpperCase();
      const scaleFactor = Math.max(1, portionsPerMeal / Math.max(1, slotCandidate.servings));
      chosenMeals.push({
        ...slotCandidate,
        id: `local-wiz-${slotCandidate.id}-${i}`,
        servings: Math.max(1, Math.ceil(portionsPerMeal)),
        estimatedCostINR: Math.round(slotCandidate.estimatedCostINR * Math.min(2.2, scaleFactor)),
        dayLabel: `${dayShort} · ${slotNormalized.toUpperCase()}`,
      });
    }

    const consolidated = new Map<string, WizardGroceryItem>();
    chosenMeals.forEach((meal) => {
      const scale = Math.max(1, portionsPerMeal / Math.max(1, meal.servings));
      meal.ingredients.forEach((ing) => {
        const lowerName = ing.name.toLowerCase();
        if (pantryLower.some((p) => lowerName.includes(p) || p.includes(lowerName))) return;
        const existing = consolidated.get(lowerName);
        if (existing) {
          existing.quantity = Math.round((existing.quantity + ing.quantity * scale) * 10) / 10;
          existing.packNote = `${existing.quantity} ${existing.unit}`;
        } else {
          const qty = Math.max(1, Math.round(ing.quantity * scale * 10) / 10);
          const category = normalizeCategory(ing.category);
          consolidated.set(lowerName, {
            id: `local-groc-${Date.now()}-${consolidated.size}`,
            name: ing.name,
            storeSection: mapCategoryToStoreSection(category),
            packNote: `${qty} ${ing.unit}`,
            quantity: qty,
            unit: ing.unit,
            category,
            estimatedCostINR: Math.max(25, Math.min(140, Math.round(meal.estimatedCostINR / Math.max(3, meal.ingredients.length)))),
            purchased: false,
            source: 'meal-plan',
          });
        }
      });
    });

    const maxItemCount = weeklyBudgetINR <= 1200 ? 8 : weeklyBudgetINR <= 2000 ? 10 : 14;
    let items = Array.from(consolidated.values()).slice(0, maxItemCount);
    const safeCap = Math.max(200, weeklyBudgetINR);
    const totalCost = items.reduce((sum, item) => sum + item.estimatedCostINR, 0);
    if (totalCost > safeCap && items.length > 0) {
      const ratio = (safeCap * 0.9) / totalCost;
      items = items.map((item) => ({
        ...item,
        estimatedCostINR: Math.max(10, Math.round(item.estimatedCostINR * ratio)),
      }));
    }

    setMeals(chosenMeals);
    setGroceryItems(items);
    setBuildError(null);
    setStep(14);
    if (noticeToast) {
      showToast(noticeToast);
    }
  };

  const generateTripPlan = async () => {
    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setStep(13);
    setBuildError(null);
    setAddedToMainList(false);
    setAppliedToWeek(false);

    const timeoutId = setTimeout(() => {
      controller.abort();
    }, 26000);

    try {
      const cleanAllergies = allergies.filter((a) => a !== 'No allergies');
      const data = await postJson<{ meals?: Record<string, unknown>[]; groceryItems?: Record<string, unknown>[] }>(
        '/api/ai/trip-plan',
        {
          stores: selectedStores,
          adults,
          kids,
          portionsPerMeal,
          mealSlots,
          days,
          appliances,
          eatingStyles,
          vibes,
          calorieTarget: hasCalorieTarget ? calorieTarget : undefined,
          allergies: cleanAllergies,
          dislikes,
          alreadyHave,
          weeklyBudgetINR,
          currency: state.user.currency,
          language: state.user.language,
        },
        controller.signal
      );

      const aiMeals: WizardMeal[] = (data.meals || []).map((m: Record<string, unknown>, idx: number) => ({
        id: String(m.id || `wiz-meal-${Date.now()}-${idx}`),
        dayLabel: String(m.dayLabel || `${days[idx % days.length]?.slice(0, 3).toUpperCase() || 'MON'} · ${String(m.mealSlot || 'MEAL').toUpperCase()}`),
        title: String(m.title || 'Balanced Home Meal'),
        cuisine: String(m.cuisine || 'Continental'),
        dietType: (['Vegetarian', 'Non-vegetarian', 'Eggetarian', 'Vegan', 'Pescatarian', 'Flexitarian'].includes(String(m.dietType))
          ? m.dietType
          : 'Vegetarian') as DietType,
        prepTimeMins: Number(m.prepTimeMins) || 25,
        difficulty: (['Easy', 'Medium', 'Chef'].includes(String(m.difficulty)) ? m.difficulty : 'Easy') as 'Easy' | 'Medium' | 'Chef',
        servings: Number(m.servings) || Math.ceil(portionsPerMeal),
        estimatedCostINR: Number(m.estimatedCostINR) || 180,
        image: String(m.image || '/src/assets/images/meal_lunch_mediterranean_1795377617245.jpg'),
        description: String(m.description || ''),
        mealSlot: (['Breakfast', 'Lunch', 'Dinner', 'Snack', 'Dessert'].includes(String(m.mealSlot))
          ? m.mealSlot
          : 'Dinner') as Recipe['mealSlot'],
        allergens: Array.isArray(m.allergens) ? m.allergens.map(String) : [],
        tags: Array.isArray(m.tags) ? m.tags.map(String) : ['Trip Plan'],
        isAiGenerated: true,
        nutrition: (m.nutrition as Recipe['nutrition']) || { calories: 450, protein: 24, carbs: 45, fat: 16 },
        ingredients: Array.isArray(m.ingredients)
          ? m.ingredients.map((ing: Record<string, unknown>) => ({
              name: String(ing.name || 'Ingredient'),
              quantity: Number(ing.quantity) || 1,
              unit: String(ing.unit || 'pc'),
              category: normalizeCategory(String(ing.category || 'Vegetables')),
            }))
          : [],
        instructions: Array.isArray(m.instructions) ? m.instructions.map(String) : ['Cook ingredients until ready.'],
      }));

      const aiGroceries: WizardGroceryItem[] = (data.groceryItems || []).map((g: Record<string, unknown>, idx: number) => ({
        id: String(g.id || `wiz-groc-${Date.now()}-${idx}`),
        name: String(g.name || 'Grocery Item'),
        storeSection: String(g.storeSection || 'Produce'),
        packNote: String(g.packNote || `${g.quantity || 1} ${g.unit || 'pc'}`),
        quantity: Math.max(0.1, Number(g.quantity) || 1),
        unit: String(g.unit || 'pc'),
        category: normalizeCategory(String(g.category || g.storeSection || 'Vegetables')),
        estimatedCostINR: Math.max(10, Number(g.estimatedCostINR) || 60),
        purchased: false,
        source: 'meal-plan',
      }));

      if (aiMeals.length < 2) {
        buildLocalTripPlan('Built your instant multi-meal basket tailored to your filters.');
        return;
      }

      let finalGroceries = aiGroceries;
      if (finalGroceries.length === 0) {
        const pantryLower = alreadyHave.map((p) => p.toLowerCase());
        const derivedMap = new Map<string, WizardGroceryItem>();
        aiMeals.forEach((meal) => {
          meal.ingredients.forEach((ing) => {
            const key = ing.name.toLowerCase().trim();
            if (!key || pantryLower.some((p) => key.includes(p) || p.includes(key))) return;
            if (!derivedMap.has(key)) {
              const cat = normalizeCategory(ing.category);
              derivedMap.set(key, {
                id: `wiz-derived-${Date.now()}-${derivedMap.size}`,
                name: ing.name,
                storeSection: mapCategoryToStoreSection(cat),
                packNote: `${ing.quantity} ${ing.unit}`,
                quantity: Math.max(0.1, ing.quantity),
                unit: ing.unit,
                category: cat,
                estimatedCostINR: 60,
                purchased: false,
                source: 'meal-plan',
              });
            }
          });
        });
        finalGroceries = Array.from(derivedMap.values()).slice(0, 12);
      }

      if (finalGroceries.length === 0) {
        buildLocalTripPlan('Built your complete store basket matched to your filters.');
        return;
      }

      const rawTotal = finalGroceries.reduce((s, g) => s + g.estimatedCostINR, 0);
      if (rawTotal > weeklyBudgetINR && finalGroceries.length > 0) {
        const ratio = (weeklyBudgetINR * 0.92) / rawTotal;
        finalGroceries = finalGroceries.map((g) => ({
          ...g,
          estimatedCostINR: Math.max(10, Math.round(g.estimatedCostINR * ratio)),
        }));
      }

      setMeals(aiMeals);
      setGroceryItems(finalGroceries);
      setStep(14);
    } catch {
      buildLocalTripPlan(
        `Built your instant budget basket under ${formatCurrency(weeklyBudgetINR, state.user.currency)}.`
      );
    } finally {
      clearTimeout(timeoutId);
    }
  };

  const handleSwapMeal = async (idx: number) => {
    const target = meals[idx];
    if (!target) return;
    setSwappingIdx(idx);
    try {
      const data = await postJson<{ meal?: Recipe }>('/api/ai/diet-plan', {
        replaceSlot: target.mealSlot || 'Dinner',
        language: state.user.language,
        pantryNames: alreadyHave,
        profile: {
          ...state.dietProfile,
          allergies: allergies.filter((a) => a !== 'No allergies'),
          dislikedIngredients: dislikes,
          householdSize: Math.ceil(portionsPerMeal),
          dailyBudget: Math.round(weeklyBudgetINR / Math.max(1, days.length)),
        },
      });
      const nextMeal = data.meal;
      if (!nextMeal) {
        throw new Error('Swap failed');
      }
      setMeals((prev) =>
        prev.map((m, i) =>
          i === idx
            ? {
                ...nextMeal,
                dayLabel: target.dayLabel,
                ingredients: (nextMeal.ingredients || []).map((ing) => ({
                  name: String(ing.name || 'Ingredient'),
                  quantity: Number(ing.quantity) || 1,
                  unit: String(ing.unit || 'pc'),
                  category: normalizeCategory(String(ing.category || 'Vegetables')),
                })),
              }
            : m
        )
      );
      showToast(`Swapped "${target.title}" for "${nextMeal.title}".`);
    } catch {
      // Deterministic safe fallback from allRecipes matching exclusions
      const excl = [...allergies.filter((a) => a !== 'No allergies'), ...dislikes].map((x) => x.toLowerCase());
      const candidate = allRecipes.find(
        (r) =>
          r.title !== target.title &&
          !meals.some((m) => m.id === r.id) &&
          !r.ingredients.some((ing) => excl.some((ex) => ing.name.toLowerCase().includes(ex)))
      );
      if (candidate) {
        setMeals((prev) => prev.map((m, i) => (i === idx ? { ...candidate, dayLabel: target.dayLabel } : m)));
        showToast(`Swapped to "${candidate.title}".`);
      } else {
        showToast('Could not swap meal right now.');
      }
    } finally {
      setSwappingIdx(null);
    }
  };

  const handleAddAllToMainGroceryList = () => {
    const existingNames = new Set(state.groceryList.filter((g) => !g.purchased).map((g) => g.name.toLowerCase()));
    let addedCount = 0;
    groceryItems.forEach((item) => {
      if (item.purchased) return;
      if (!existingNames.has(item.name.toLowerCase())) {
        saveGroceryItem({
          id: `groc-wiz-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          name: item.name,
          quantity: item.quantity,
          unit: item.unit,
          category: item.category,
          estimatedCostINR: item.estimatedCostINR,
          purchased: false,
          source: 'meal-plan',
        });
        addedCount++;
      }
    });

    // Save preferences & any newly added pantry items
    const cleanAllergies = allergies.filter((a) => a !== 'No allergies');
    updateDietProfile({
      ...state.dietProfile,
      dislikedIngredients: Array.from(new Set([...state.dietProfile.dislikedIngredients, ...dislikes])),
      allergies: Array.from(new Set([...state.dietProfile.allergies, ...cleanAllergies])),
      householdSize: Math.max(1, Math.round(portionsPerMeal)),
      weeklyBudget: weeklyBudgetINR,
      calorieTarget: hasCalorieTarget ? calorieTarget : state.dietProfile.calorieTarget,
    });

    const existingPantryLower = new Set(state.pantry.map((p) => p.name.toLowerCase()));
    const today = new Date().toISOString().split('T')[0];
    const nextWeek = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];
    alreadyHave.forEach((name) => {
      if (!existingPantryLower.has(name.toLowerCase())) {
        savePantryItem({
          id: `pan-wiz-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          name,
          quantity: 1,
          unit: 'pack',
          category: 'Grains',
          purchaseDate: today,
          expiryDate: nextWeek,
          storageLocation: 'Pantry',
          lowStockThreshold: 1,
        });
      }
    });

    setAddedToMainList(true);
    showToast(`Added ${addedCount} items to your Grocery List & synced preferences.`);
  };

  const handleApplyToWeeklyPlan = () => {
    meals.forEach((meal, index) => {
      addCustomRecipe(meal);
      const dayName = days[index % days.length] || 'Monday';
      const slot =
        meal.mealSlot === 'Breakfast'
          ? 'breakfastId'
          : meal.mealSlot === 'Lunch'
          ? 'lunchId'
          : meal.mealSlot === 'Snack'
          ? 'snackId'
          : 'dinnerId';
      updateWeeklySlot(dayName, slot, meal.id);
    });
    setAppliedToWeek(true);
    showToast('Meals saved to your Weekly Meal Planner.');
  };

  const totalSpentINR = useMemo(
    () => groceryItems.reduce((sum, item) => sum + item.estimatedCostINR, 0),
    [groceryItems]
  );
  const savedINR = Math.max(0, weeklyBudgetINR - totalSpentINR);
  const budgetPct = Math.min(100, Math.round((totalSpentINR / Math.max(1, weeklyBudgetINR)) * 100));

  const groupedGrocery = useMemo(() => {
    const map = new Map<string, WizardGroceryItem[]>();
    groceryItems.forEach((g) => {
      const key = g.storeSection || 'Produce';
      const list = map.get(key) || [];
      list.push(g);
      map.set(key, list);
    });
    return Array.from(map.entries());
  }, [groceryItems]);

  const filteredDislikes = useMemo(() => {
    const q = dislikeSearch.trim().toLowerCase();
    const combined = Array.from(new Set([...DISLIKE_SUGGESTIONS, ...dislikes]));
    if (!q) return combined;
    return combined.filter((item) => item.toLowerCase().includes(q));
  }, [dislikeSearch, dislikes]);

  const filteredPantryTiles = useMemo(() => {
    const base = pantryTab === 'All' ? PANTRY_TILES : PANTRY_TILES.filter((t) => t.group === pantryTab);
    const customNames = alreadyHave.filter((name) => !PANTRY_TILES.some((p) => p.name.toLowerCase() === name.toLowerCase()));
    const extraTiles: PantryTile[] =
      pantryTab === 'All' || pantryTab === 'Pantry'
        ? customNames.map((name) => ({ name, group: 'Pantry' }))
        : [];
    return [...extraTiles, ...base];
  }, [pantryTab, alreadyHave]);

  const visibleStores = STORE_OPTIONS.filter((s) => s.region === storeRegion);
  const sliderMin = state.user.currency === 'INR' ? 300 : 15;
  const sliderMax = state.user.currency === 'INR' ? 15000 : 350;
  const sliderStep = state.user.currency === 'INR' ? 50 : 5;

  const storePlatformsForRegion = useMemo(() => {
    const regional = getPlatformsForRegion(storeRegion === 'India' ? 'india' : 'us');
    const matchedSelected = selectedStores
      .map((s) => findPlatformConfigByName(s))
      .filter((p): p is NonNullable<typeof p> => Boolean(p));
    if (matchedSelected.length > 0) {
      const ids = new Set(matchedSelected.map((p) => p.id));
      return [...matchedSelected, ...regional.filter((r) => !ids.has(r.id))].slice(0, 4);
    }
    return regional;
  }, [storeRegion, selectedStores]);

  const itemComparisons = useMemo(
    () => generateProductComparisons(groceryItems, storePlatformsForRegion),
    [groceryItems, storePlatformsForRegion]
  );

  const comparisonMap = useMemo(() => {
    const m = new Map<string, (typeof itemComparisons)[number]>();
    itemComparisons.forEach((row) => m.set(row.groceryItem.id, row));
    return m;
  }, [itemComparisons]);

  const catalogForRegion = useMemo(
    () => STORE_BROWSE_CATALOG.filter((p) => p.region === storeRegion).slice(0, 8),
    [storeRegion]
  );

  const handleQuickAddSingleItem = (item: {
    name: string;
    quantity: number;
    unit: string;
    category: GroceryCategory;
    estimatedCostINR: number;
    storeSection?: string;
    packNote?: string;
  }) => {
    saveGroceryItem({
      id: `groc-store-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      name: item.name,
      quantity: item.quantity,
      unit: item.unit,
      category: item.category,
      estimatedCostINR: item.estimatedCostINR,
      purchased: false,
      source: 'manual',
    });
    if (!groceryItems.some((g) => g.name.toLowerCase() === item.name.toLowerCase())) {
      setGroceryItems((prev) => [
        ...prev,
        {
          id: `wiz-extra-${Date.now()}`,
          name: item.name,
          quantity: item.quantity,
          unit: item.unit,
          category: item.category,
          estimatedCostINR: item.estimatedCostINR,
          purchased: false,
          source: 'manual',
          storeSection: item.storeSection || mapCategoryToStoreSection(item.category),
          packNote: item.packNote || `${item.quantity} ${item.unit}`,
        },
      ]);
    }
    showToast(`Added "${item.name}" to your Grocery Cart.`);
  };

  const handleCopyStoreList = async (storeName: string) => {
    const lines = [
      `Kitchly Shopping List for ${storeName}:`,
      ...groceryItems.map((g, i) => `${i + 1}. ${g.name} (${g.packNote})`),
    ].join('\n');
    try {
      await navigator.clipboard.writeText(lines);
      showToast(`Copied ${groceryItems.length} items for ${storeName}.`);
    } catch {
      showToast('Select items to shop or use the store links.');
    }
  };

  // Step 13: Animated Loading Build View
  if (step === 13) {
    return (
      <div className="max-w-xl mx-auto py-12">
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 space-y-6">
          <div className="space-y-1.5 text-center">
            <p className="text-xs font-semibold text-[#4A7C59]">Kitchly Trip Builder</p>
            <h2 className="font-display text-2xl font-semibold text-[#1F2421]">
              {buildError ? 'We hit a snag building your basket' : 'Building your meal & grocery plan'}
            </h2>
            <p className="text-sm text-[#5B625C]">
              Tailoring {selectedStores.join(', ')} picks for {adults} adult{adults === 1 ? '' : 's'}
              {kids > 0 ? ` & ${kids} kid${kids === 1 ? '' : 's'}` : ''} under{' '}
              {formatCurrency(weeklyBudgetINR, state.user.currency)}.
            </p>
          </div>

          {buildError ? (
            <div className="bg-[#FAF9F5] border border-[#D97736]/40 rounded-xl p-5 space-y-4 text-center">
              <p className="text-sm text-[#1F2421]">{buildError}</p>
              <div className="flex flex-wrap justify-center gap-2.5">
                <button
                  onClick={() => setStep(12)}
                  className="px-4 py-2.5 rounded-xl border border-[#E6E3DA] text-sm font-medium hover:bg-[#F3F1EA]"
                >
                  Adjust Budget & Preferences
                </button>
                <button
                  onClick={() =>
                    buildLocalTripPlan('Created an instant smart plan matched to your allergies and budget.')
                  }
                  className="px-4 py-2.5 rounded-xl bg-[#D97736] text-white text-sm font-semibold hover:opacity-95"
                >
                  Use Instant Smart Basket
                </button>
                <button
                  onClick={generateTripPlan}
                  className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A]"
                >
                  Try Again
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-3">
                {BUILD_STAGES.map((stage, idx) => {
                  const done = idx < buildStageIdx;
                  const active = idx === buildStageIdx;
                  return (
                    <div
                      key={stage}
                      className={`flex items-center justify-between px-4 py-3 rounded-xl border text-sm transition-colors ${
                        active
                          ? 'bg-[#F3F1EA] border-[#4A7C59] text-[#1F2421] font-medium'
                          : done
                          ? 'bg-white border-[#E6E3DA] text-[#1F2421]'
                          : 'bg-[#FAF9F5] border-[#EFECE3] text-[#5B625C]'
                      }`}
                    >
                      <span>{stage}</span>
                      {done ? (
                        <CheckCircle2 className="w-4 h-4 text-[#4A7C59]" />
                      ) : active ? (
                        <RefreshCw className="w-4 h-4 text-[#4A7C59] animate-spin" />
                      ) : (
                        <span className="text-xs text-[#D4CFC2]">Waiting</span>
                      )}
                    </div>
                  );
                })}
              </div>

              {elapsedSecs >= 6 && (
                <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="text-xs text-[#5B625C] text-center sm:text-left">
                    Taking a few extra seconds ({elapsedSecs}s)... AI is finalizing your recipes, or you can switch straight to an instant curated basket.
                  </div>
                  <button
                    onClick={() =>
                      buildLocalTripPlan('Built your instant smart basket tailored to your filters.')
                    }
                    className="px-3.5 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] shrink-0"
                  >
                    Instant Smart Basket →
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Step 14: Results View ("Your week is ready!")
  if (step === 14) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-[#4A7C59] mb-1">
              {selectedStores.join(' · ')} · {days.length} days · {portionsPerMeal} portions/meal
            </p>
            <h2 className="font-display text-2xl lg:text-3xl font-semibold text-[#1F2421]">
              Your week is ready!
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2.5 rounded-xl bg-white border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] hover:bg-[#F3F1EA]"
            >
              Start New Trip
            </button>
            <button
              onClick={handleApplyToWeeklyPlan}
              disabled={appliedToWeek}
              className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] disabled:opacity-70 inline-flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{appliedToWeek ? 'Applied to Weekly Plan' : 'Looks great — Apply to Weekly Plan'}</span>
            </button>
          </div>
        </div>

        {/* Budget Summary Card */}
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5 sm:p-6 space-y-3">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <p className="text-xs font-medium text-[#5B625C]">Estimated weekly basket</p>
              <p className="font-display text-xl sm:text-2xl font-semibold text-[#1F2421] tabular-nums">
                Spent {formatCurrency(totalSpentINR, state.user.currency)} of{' '}
                {formatCurrency(weeklyBudgetINR, state.user.currency)}
              </p>
            </div>
            <div className="text-right">
              <p className="font-mono text-base font-bold text-[#4A7C59] tabular-nums">
                {savedINR > 0
                  ? `Saved ${formatCurrency(savedINR, state.user.currency)}`
                  : 'Right on budget'}
              </p>
              <p className="text-xs text-[#5B625C] tabular-nums">
                {alreadyHave.length} pantry item{alreadyHave.length === 1 ? '' : 's'} reused
              </p>
            </div>
          </div>
          <div className="h-2.5 w-full bg-[#EFECE3] rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                totalSpentINR > weeklyBudgetINR ? 'bg-[#D97736]' : 'bg-[#4A7C59]'
              }`}
              style={{ width: `${budgetPct}%` }}
            />
          </div>
        </div>

        {/* Direct Store Links & Basket Offer Strip */}
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="font-display text-base font-semibold text-[#1F2421]">
                Shop directly on your selected stores
              </h3>
              <p className="text-xs text-[#5B625C]">
                Compare sample basket totals and open any store directly to order your items.
              </p>
            </div>
            <button
              onClick={() => handleCopyStoreList(selectedStores[0] || 'Store')}
              className="px-3 py-1.5 rounded-xl bg-[#FAF9F5] border border-[#E6E3DA] text-xs font-medium text-[#1F2421] hover:bg-[#F3F1EA] inline-flex items-center gap-1.5"
            >
              <Copy className="w-3.5 h-3.5 text-[#4A7C59]" />
              <span>Copy shopping list</span>
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {selectedStores.map((storeName) => {
              const plat = findPlatformConfigByName(storeName);
              const estTotalINR = plat
                ? itemComparisons.reduce((sum, row) => {
                    const offer = row.offers.find((o) => o.platformId === plat.id && o.inStock);
                    return sum + (offer ? offer.priceINR : row.groceryItem.estimatedCostINR);
                  }, 0)
                : totalSpentINR;
              return (
                <div
                  key={storeName}
                  className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-3.5 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-display text-sm font-semibold text-[#1F2421]">{storeName}</span>
                      <span className="text-xs font-semibold text-[#4A7C59] tabular-nums">
                        {formatCurrency(estTotalINR, state.user.currency)}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#5B625C] mt-0.5">
                      {plat ? `${plat.deliveryTimeLabel} · Free above ${formatCurrency(plat.freeDeliveryMinOrderINR, state.user.currency)}` : 'Browse grocery catalog'}
                    </p>
                  </div>
                  <a
                    href={getStoreHomeUrl(storeName)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 rounded-lg bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center justify-center gap-1.5"
                  >
                    <span>Shop on {storeName}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              );
            })}
          </div>
        </div>

        {/* Categorized Grocery List Drawer/Panel */}
        <div className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden">
          <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#EFECE3]">
            <button
              onClick={() => setShowGrocerySection((v) => !v)}
              className="flex items-center gap-2.5 text-left"
            >
              <ShoppingCart className="w-5 h-5 text-[#4A7C59]" />
              <span className="font-display text-lg font-semibold text-[#1F2421]">
                Grocery list ({groceryItems.length} items)
              </span>
              {showGrocerySection ? (
                <ChevronUp className="w-4 h-4 text-[#5B625C]" />
              ) : (
                <ChevronDown className="w-4 h-4 text-[#5B625C]" />
              )}
            </button>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleAddAllToMainGroceryList}
                disabled={addedToMainList}
                className="px-4 py-2 rounded-xl bg-[#D97736] text-white text-xs font-semibold hover:opacity-95 disabled:opacity-70 inline-flex items-center gap-1.5"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>
                  {addedToMainList ? 'Synced to Grocery List' : 'Add All to Main Grocery List'}
                </span>
              </button>
              {addedToMainList && (
                <button
                  onClick={() => setScreen('grocery-list')}
                  className="px-3.5 py-2 rounded-xl bg-[#F3F1EA] text-xs font-semibold text-[#1F2421] hover:bg-[#E7E3D7]"
                >
                  Open Grocery List →
                </button>
              )}
            </div>
          </div>

          {showGrocerySection && (
            <div className="p-5 grid md:grid-cols-2 gap-5">
              {groupedGrocery.map(([section, items]) => (
                <div key={section} className="bg-[#FAF9F5] border border-[#EFECE3] rounded-xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between pb-2 border-b border-[#E6E3DA]">
                    <h3 className="font-display text-sm font-semibold text-[#1F2421]">{section}</h3>
                    <span className="text-xs font-mono text-[#5B625C] tabular-nums">{items.length}</span>
                  </div>
                  <div className="space-y-2.5">
                    {items.map((item) => {
                      const comp = comparisonMap.get(item.id);
                      const bestStore = comp?.cheapestOffer?.platformName || selectedStores[0] || 'Blinkit';
                      const searchUrl = getStoreItemSearchUrl(bestStore, item.name);
                      const inMainCart = state.groceryList.some(
                        (g) => !g.purchased && g.name.toLowerCase() === item.name.toLowerCase()
                      );
                      return (
                        <div
                          key={item.id}
                          className="flex flex-col gap-1.5 py-2 px-2 rounded-lg bg-white border border-[#EFECE3]"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <button
                              onClick={() =>
                                setGroceryItems((prev) =>
                                  prev.map((g) => (g.id === item.id ? { ...g, purchased: !g.purchased } : g))
                                )
                              }
                              className="flex items-center gap-2 text-left min-w-0 flex-1"
                            >
                              <CheckCircle2
                                className={`w-4 h-4 shrink-0 ${
                                  item.purchased ? 'text-[#4A7C59]' : 'text-[#D4CFC2]'
                                }`}
                              />
                              <div className="min-w-0">
                                <p
                                  className={`text-sm font-medium truncate ${
                                    item.purchased ? 'line-through text-[#5B625C]' : 'text-[#1F2421]'
                                  }`}
                                >
                                  {item.name}
                                </p>
                                <p className="text-xs text-[#5B625C] truncate">
                                  {item.packNote} · Best est. on {bestStore}
                                </p>
                              </div>
                            </button>
                            <span className="text-xs font-semibold text-[#1F2421] shrink-0 tabular-nums">
                              {formatCurrency(comp?.cheapestOffer?.priceINR || item.estimatedCostINR, state.user.currency)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between gap-2 pl-6 pt-1 border-t border-[#F3F1EA]">
                            <button
                              onClick={() => handleQuickAddSingleItem(item)}
                              disabled={inMainCart}
                              className="text-[11px] font-semibold text-[#4A7C59] hover:underline disabled:text-[#5B625C] disabled:no-underline"
                            >
                              {inMainCart ? 'In Grocery Cart' : '+ Add to Cart'}
                            </button>
                            <a
                              href={searchUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] font-semibold text-[#D97736] hover:underline inline-flex items-center gap-1"
                            >
                              <span>Buy on {bestStore}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Store Catalog Offerings (What selected stores offer right now) */}
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="font-display text-base font-semibold text-[#1F2421]">
                What {selectedStores[0] || 'stores'} & partner apps offer — Quick Add to Cart
              </h3>
              <p className="text-xs text-[#5B625C]">
                Add daily staples directly to your cart or open the item page on {selectedStores[0] || 'Blinkit'}.
              </p>
            </div>
            <button
              onClick={() => setScreen('grocery-list')}
              className="text-xs font-semibold text-[#4A7C59] hover:underline"
            >
              Browse full catalog →
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {catalogForRegion.map((prod) => {
              const primaryPlat = storePlatformsForRegion[0];
              const mult = primaryPlat ? prod.multipliers[primaryPlat.id] ?? 0.9 : 0.9;
              const priceINR = Math.round(prod.mrpINR * mult);
              const primaryStoreName = selectedStores[0] || primaryPlat?.name || 'Blinkit';
              return (
                <div
                  key={prod.id}
                  className="bg-[#FAF9F5] border border-[#EFECE3] rounded-xl p-3.5 flex flex-col justify-between gap-2.5"
                >
                  <div>
                    <p className="text-[11px] font-medium text-[#5B625C]">
                      {prod.brand} · {prod.packSize}
                    </p>
                    <p className="text-sm font-semibold text-[#1F2421] leading-snug mt-0.5">{prod.name}</p>
                    <p className="text-xs font-semibold text-[#4A7C59] mt-1 tabular-nums">
                      Est. {formatCurrency(priceINR, state.user.currency)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 pt-2 border-t border-[#E6E3DA]">
                    <button
                      onClick={() =>
                        handleQuickAddSingleItem({
                          name: prod.name,
                          quantity: prod.quantity,
                          unit: prod.unit,
                          category: prod.category,
                          estimatedCostINR: priceINR,
                          packNote: prod.packSize,
                        })
                      }
                      className="flex-1 py-1.5 px-2.5 rounded-lg bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A]"
                    >
                      + Add to Cart
                    </button>
                    <a
                      href={getStoreItemSearchUrl(primaryStoreName, prod.name)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-1.5 px-2.5 rounded-lg bg-white border border-[#E6E3DA] text-xs font-medium text-[#1F2421] hover:bg-[#F3F1EA] inline-flex items-center gap-1"
                    >
                      <span>Shop</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Planned Meals List with Swap + View Recipe */}
        <div className="space-y-3">
          <h3 className="font-display text-lg font-semibold text-[#1F2421]">
            Your Planned Meals ({meals.length})
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            {meals.map((meal, idx) => (
              <div
                key={`${meal.id}-${idx}`}
                className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden flex flex-col sm:flex-row"
              >
                <div className="sm:w-36 h-36 sm:h-auto shrink-0">
                  <FoodImage src={meal.image} alt={meal.title} className="w-full h-full object-cover" />
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#4A7C59] mb-1">
                      {meal.dayLabel} · {meal.cuisine}
                    </p>
                    <h4 className="font-display text-base font-semibold text-[#1F2421] leading-snug mb-1">
                      {meal.title}
                    </h4>
                    <p className="text-xs text-[#5B625C] line-clamp-2 mb-2">{meal.description}</p>
                    <p className="text-xs text-[#5B625C] tabular-nums flex flex-wrap items-center gap-2">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {meal.prepTimeMins} min
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5 text-[#D97736]" />
                        {meal.nutrition.calories} kcal
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{meal.nutrition.protein}g protein</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-[#EFECE3]">
                    <button
                      onClick={() => {
                        addCustomRecipe(meal);
                        openRecipe(meal);
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] text-center"
                    >
                      View Recipe
                    </button>
                    <button
                      onClick={() => handleSwapMeal(idx)}
                      disabled={swappingIdx === idx}
                      className="py-2 px-3 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7] inline-flex items-center gap-1.5 disabled:opacity-60"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${swappingIdx === idx ? 'animate-spin' : ''}`} />
                      <span>{swappingIdx === idx ? 'Swapping...' : 'Swap'}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const totalQuestions = 12;
  const progressPct = Math.round((step / totalQuestions) * 100);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header & Step Progress */}
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={() => (step > 1 ? setStep(step - 1) : setScreen('grocery-list'))}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-[#5B625C] hover:text-[#1F2421] min-h-[40px]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{step > 1 ? 'Back' : 'Grocery List'}</span>
        </button>
        <div className="text-xs font-mono font-medium text-[#5B625C] tabular-nums">
          Step {step} of {totalQuestions}
        </div>
      </div>

      <div className="h-1.5 w-full bg-[#EFECE3] rounded-full overflow-hidden">
        <div
          className="h-full bg-[#4A7C59] rounded-full transition-all duration-300"
          style={{ width: `${progressPct}%` }}
        />
      </div>

      {/* Main Card for Current Step */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 sm:p-8 space-y-6">
        {/* Step 1: Where do you shop? */}
        {step === 1 && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-[#4A7C59] mb-1">Guided Grocery Trip Builder</p>
                <h2 className="font-display text-2xl font-semibold text-[#1F2421]">Where do you shop?</h2>
                <p className="text-sm text-[#5B625C] mt-1">
                  Choose your favorite grocery store(s) so we tailor pack sizes and basket estimates.
                </p>
              </div>
              <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1 self-start">
                {(['Global', 'India'] as const).map((reg) => (
                  <button
                    key={reg}
                    onClick={() => {
                      setStoreRegion(reg);
                      setSelectedStores(reg === 'India' ? ['Blinkit'] : ["Trader Joe's"]);
                    }}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
                      storeRegion === reg ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
                    }`}
                  >
                    {reg === 'Global' ? 'US & Global' : 'India'}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {visibleStores.map((st) => {
                const active = selectedStores.includes(st.name);
                return (
                  <button
                    key={st.id}
                    onClick={() => toggleItem(selectedStores, setSelectedStores, st.name)}
                    className={`p-3.5 rounded-xl border text-left transition-colors min-h-[68px] flex flex-col justify-between ${
                      active
                        ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-display text-sm font-semibold">{st.name}</span>
                      {active && <CheckCircle2 className="w-4 h-4 text-[#4A7C59] shrink-0" />}
                    </div>
                    <span className="text-xs text-[#5B625C]">{st.note}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 2: Who's eating? */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">Who’s eating?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                We scale recipe quantities and grocery packs accurately for your household.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-5 flex items-center justify-between">
                <div>
                  <p className="font-display text-base font-semibold text-[#1F2421]">Adults</p>
                  <p className="text-xs text-[#5B625C]">1 full portion each</p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setAdults((a) => Math.max(1, a - 1))}
                    aria-label="Decrease adults"
                    className="w-10 h-10 rounded-xl bg-white border border-[#E6E3DA] font-semibold hover:bg-[#F3F1EA]"
                  >
                    −
                  </button>
                  <span className="font-mono text-lg font-bold w-6 text-center tabular-nums">{adults}</span>
                  <button
                    onClick={() => setAdults((a) => Math.min(12, a + 1))}
                    aria-label="Increase adults"
                    className="w-10 h-10 rounded-xl bg-white border border-[#E6E3DA] font-semibold hover:bg-[#F3F1EA]"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-5 flex items-center justify-between">
                <div>
                  <p className="font-display text-base font-semibold text-[#1F2421]">Kids</p>
                  <p className="text-xs text-[#5B625C]">½ portion each</p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setKids((k) => Math.max(0, k - 1))}
                    aria-label="Decrease kids"
                    className="w-10 h-10 rounded-xl bg-white border border-[#E6E3DA] font-semibold hover:bg-[#F3F1EA]"
                  >
                    −
                  </button>
                  <span className="font-mono text-lg font-bold w-6 text-center tabular-nums">{kids}</span>
                  <button
                    onClick={() => setKids((k) => Math.min(12, k + 1))}
                    aria-label="Increase kids"
                    className="w-10 h-10 rounded-xl bg-white border border-[#E6E3DA] font-semibold hover:bg-[#F3F1EA]"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-[#F3F1EA] rounded-xl p-4 flex items-center justify-between text-sm">
              <span className="text-[#5B625C] inline-flex items-center gap-2">
                <Users className="w-4 h-4 text-[#4A7C59]" />
                <span>Total portions per meal</span>
              </span>
              <span className="font-mono font-bold text-[#1F2421] tabular-nums">{portionsPerMeal} portions</span>
            </div>
          </div>
        )}

        {/* Step 3: Which meals? */}
        {step === 3 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">Which meals?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Pick the daily meals you want included in your grocery shopping trip.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {MEAL_SLOT_OPTIONS.map((slot) => {
                const active = mealSlots.includes(slot);
                return (
                  <button
                    key={slot}
                    onClick={() => toggleItem(mealSlots, setMealSlots, slot)}
                    className={`p-5 rounded-xl border text-left flex items-center justify-between transition-colors ${
                      active
                        ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <span className="font-display text-base font-semibold">{slot}</span>
                    <CheckCircle2 className={`w-5 h-5 ${active ? 'text-[#4A7C59]' : 'text-[#D4CFC2]'}`} />
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 4: Which days are you cooking? */}
        {step === 4 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">
                Which days are you cooking?
              </h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Tap the days you want groceries & recipes planned for ({days.length} selected).
              </p>
            </div>
            <div className="grid grid-cols-7 gap-2">
              {DAY_OPTIONS.map((d) => {
                const active = days.includes(d.full);
                return (
                  <button
                    key={d.full}
                    onClick={() => toggleItem(days, setDays, d.full)}
                    aria-label={d.full}
                    className={`min-h-[64px] rounded-xl border flex flex-col items-center justify-center gap-1 transition-colors ${
                      active
                        ? 'bg-[#4A7C59] border-[#4A7C59] text-white'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <span className="font-display text-base font-bold">{d.short}</span>
                    <span className={`text-[10px] ${active ? 'text-white/90' : 'text-[#5B625C]'}`}>
                      {d.full.slice(0, 3)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 5: What's in your Kitchen? */}
        {step === 5 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">What’s in your Kitchen?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                We’ll only suggest recipes using appliances you actually have.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {APPLIANCE_OPTIONS.map((app) => {
                const active = appliances.includes(app);
                return (
                  <button
                    key={app}
                    onClick={() => toggleItem(appliances, setAppliances, app)}
                    className={`p-3.5 rounded-xl border text-left flex items-center justify-between gap-2 min-h-[56px] ${
                      active
                        ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <span className="text-sm font-medium">{app}</span>
                    {active && <CheckCircle2 className="w-4 h-4 text-[#4A7C59] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 6: How do you eat? */}
        {step === 6 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">How do you eat?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Select one or more eating styles and flavor styles you prefer.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {EATING_STYLE_OPTIONS.map((style) => {
                const active = eatingStyles.includes(style);
                return (
                  <button
                    key={style}
                    onClick={() => {
                      if (style === 'No Restrictions') {
                        setEatingStyles(['No Restrictions']);
                      } else {
                        const withoutNo = eatingStyles.filter((x) => x !== 'No Restrictions');
                        const next = withoutNo.includes(style)
                          ? withoutNo.filter((x) => x !== style)
                          : [...withoutNo, style];
                        setEatingStyles(next.length > 0 ? next : ['No Restrictions']);
                      }
                    }}
                    className={`px-3.5 py-3 rounded-xl border text-left text-sm font-medium flex items-center justify-between gap-2 ${
                      active
                        ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <span>{style}</span>
                    {active && <Check className="w-4 h-4 text-[#4A7C59] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 7: What kind of vibe? */}
        {step === 7 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">What kind of vibe?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Pick the cooking mood for this grocery haul.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {VIBE_OPTIONS.map((v) => {
                const active = vibes.includes(v.label);
                return (
                  <button
                    key={v.label}
                    onClick={() => toggleItem(vibes, setVibes, v.label)}
                    className={`p-4 rounded-xl border text-left flex items-center justify-between gap-2 ${
                      active
                        ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <div>
                      <p className="font-display text-sm font-semibold">{v.label}</p>
                      <p className="text-xs text-[#5B625C]">{v.sub}</p>
                    </div>
                    {active && <CheckCircle2 className="w-4 h-4 text-[#4A7C59] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 8: Got a calorie target? */}
        {step === 8 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">Got a calorie target?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Keep it flexible or set an approximate daily energy guide per adult serving.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <button
                onClick={() => setHasCalorieTarget(false)}
                className={`p-5 rounded-xl border text-left space-y-1 ${
                  !hasCalorieTarget
                    ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                    : 'bg-[#FAF9F5] border-[#E6E3DA]'
                }`}
              >
                <p className="font-display text-base font-semibold">No, keep it simple</p>
                <p className="text-xs text-[#5B625C]">Balanced, everyday portions without tracking.</p>
              </button>
              <button
                onClick={() => setHasCalorieTarget(true)}
                className={`p-5 rounded-xl border text-left space-y-1 ${
                  hasCalorieTarget
                    ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                    : 'bg-[#FAF9F5] border-[#E6E3DA]'
                }`}
              >
                <p className="font-display text-base font-semibold">Yes, I have a target</p>
                <p className="text-xs text-[#5B625C]">Guide daily calories per person.</p>
              </button>
            </div>
            {hasCalorieTarget && (
              <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-4 flex items-center justify-between gap-4">
                <label htmlFor="wizard-cal-input" className="text-sm font-medium text-[#1F2421]">
                  Daily kcal per person
                </label>
                <input
                  id="wizard-cal-input"
                  type="number"
                  min={1200}
                  max={4000}
                  step={50}
                  value={calorieTarget}
                  onChange={(e) => setCalorieTarget(Number(e.target.value) || 1800)}
                  className="w-28 h-10 px-3 rounded-xl border border-[#E6E3DA] bg-white font-mono text-sm text-right tabular-nums"
                />
              </div>
            )}
          </div>
        )}

        {/* Step 9: Any allergies? */}
        {step === 9 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">Any allergies?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Allergies are strictly excluded from every recipe and grocery item.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {ALLERGY_OPTIONS.map((allergy) => {
                const active = allergies.includes(allergy);
                return (
                  <button
                    key={allergy}
                    onClick={() => {
                      if (allergy === 'No allergies') {
                        setAllergies(['No allergies']);
                      } else {
                        const withoutNone = allergies.filter((a) => a !== 'No allergies');
                        const next = withoutNone.includes(allergy)
                          ? withoutNone.filter((a) => a !== allergy)
                          : [...withoutNone, allergy];
                        setAllergies(next.length > 0 ? next : ['No allergies']);
                      }
                    }}
                    className={`px-3.5 py-3 rounded-xl border text-left text-sm font-medium flex items-center justify-between gap-2 ${
                      active
                        ? allergy === 'No allergies'
                          ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                          : 'bg-[#D97736]/10 border-[#D97736] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <span>{allergy}</span>
                    {active && (
                      <Check
                        className={`w-4 h-4 shrink-0 ${
                          allergy === 'No allergies' ? 'text-[#4A7C59]' : 'text-[#D97736]'
                        }`}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 10: Any dislikes? */}
        {step === 10 && (
          <div className="space-y-4">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">Any dislikes?</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Tap anything you’d rather keep off your plate and shopping list ({dislikes.length} excluded).
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#5B625C] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  value={dislikeSearch}
                  onChange={(e) => setDislikeSearch(e.target.value)}
                  placeholder="Search ingredients to avoid..."
                  className="w-full h-10 pl-9 pr-3 rounded-xl border border-[#E6E3DA] text-sm"
                />
              </div>
              <div className="flex gap-2">
                <input
                  value={customDislike}
                  onChange={(e) => setCustomDislike(e.target.value)}
                  placeholder="Add custom dislike"
                  className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
                />
                <button
                  onClick={() => {
                    const clean = customDislike.trim();
                    if (!clean) return;
                    if (!dislikes.includes(clean)) setDislikes([...dislikes, clean]);
                    setCustomDislike('');
                  }}
                  className="h-10 px-3.5 rounded-xl bg-[#F3F1EA] border border-[#E6E3DA] text-xs font-semibold hover:bg-[#E7E3D7] inline-flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-72 overflow-y-auto pr-1">
              {filteredDislikes.map((item) => {
                const active = dislikes.some((d) => d.toLowerCase() === item.toLowerCase());
                return (
                  <button
                    key={item}
                    onClick={() =>
                      setDislikes((prev) =>
                        active
                          ? prev.filter((d) => d.toLowerCase() !== item.toLowerCase())
                          : [...prev, item]
                      )
                    }
                    className={`px-3 py-2.5 rounded-xl border text-left text-xs font-medium flex items-center justify-between gap-2 ${
                      active
                        ? 'bg-[#D97736]/10 border-[#D97736] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <span className="truncate">{item}</span>
                    {active && <span className="text-[11px] font-semibold text-[#D97736]">Avoid</span>}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 11: What do you already have? */}
        {step === 11 && (
          <div className="space-y-4">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">
                What do you already have?
              </h2>
              <p className="text-sm text-[#5B625C] mt-1">
                We’ll build meals around these and leave them off your shopping list ({alreadyHave.length} selected).
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
                {(['All', 'Fresh', 'Meat', 'Fridge', 'Pantry'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setPantryTab(tab)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                      pantryTab === tab ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
              <div className="flex gap-1.5">
                <input
                  value={customPantryInput}
                  onChange={(e) => setCustomPantryInput(e.target.value)}
                  placeholder="Add item at home..."
                  className="h-9 px-3 rounded-xl border border-[#E6E3DA] text-xs"
                />
                <button
                  onClick={() => {
                    const clean = customPantryInput.trim();
                    if (!clean) return;
                    if (!alreadyHave.includes(clean)) setAlreadyHave([...alreadyHave, clean]);
                    setCustomPantryInput('');
                  }}
                  className="h-9 px-3 rounded-xl bg-[#F3F1EA] text-xs font-semibold hover:bg-[#E7E3D7]"
                >
                  + Add
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-72 overflow-y-auto pr-1">
              {filteredPantryTiles.map((tile) => {
                const active = alreadyHave.some((x) => x.toLowerCase() === tile.name.toLowerCase());
                return (
                  <button
                    key={tile.name}
                    onClick={() =>
                      setAlreadyHave((prev) =>
                        active
                          ? prev.filter((x) => x.toLowerCase() !== tile.name.toLowerCase())
                          : [...prev, tile.name]
                      )
                    }
                    className={`px-3 py-2.5 rounded-xl border text-left text-xs font-medium flex items-center justify-between gap-2 ${
                      active
                        ? 'bg-[#4A7C59]/10 border-[#4A7C59] text-[#1F2421]'
                        : 'bg-[#FAF9F5] border-[#E6E3DA] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    <span className="truncate">{tile.name}</span>
                    {active && <CheckCircle2 className="w-4 h-4 text-[#4A7C59] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 12: Your weekly budget */}
        {step === 12 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1F2421]">Your weekly budget</h2>
              <p className="text-sm text-[#5B625C] mt-1">
                Slide or tap to set your weekly grocery target. Kitchly keeps your basket below this cap.
              </p>
            </div>

            <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-2xl p-6 text-center space-y-4">
              <p className="text-xs font-semibold text-[#4A7C59]">Weekly grocery target</p>
              <div className="flex items-center justify-center gap-2">
                <span className="font-display text-3xl font-semibold text-[#1F2421]">
                  {currencyCfg.symbol}
                </span>
                <input
                  type="number"
                  aria-label="Weekly budget amount"
                  min={sliderMin}
                  max={sliderMax * 2}
                  value={budgetDisplayAmount}
                  onChange={(e) => setBudgetDisplayAmount(Math.max(1, Number(e.target.value) || sliderMin))}
                  className="w-32 text-center font-mono text-3xl font-bold text-[#1F2421] bg-white border border-[#E6E3DA] rounded-xl py-1 tabular-nums"
                />
              </div>

              <input
                type="range"
                aria-label="Weekly budget slider"
                min={sliderMin}
                max={sliderMax}
                step={sliderStep}
                value={Math.min(sliderMax, budgetDisplayAmount)}
                onChange={(e) => setBudgetDisplayAmount(Number(e.target.value))}
                className="w-full accent-[#4A7C59]"
              />

              <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                {(state.user.currency === 'INR' ? [750, 1200, 1500, 2000, 3000] : [25, 45, 75, 100]).map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setBudgetDisplayAmount(preset)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-semibold tabular-nums transition-colors ${
                      budgetDisplayAmount === preset
                        ? 'bg-[#4A7C59] border-[#4A7C59] text-white'
                        : 'bg-white border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                    }`}
                  >
                    {currencyCfg.symbol}
                    {preset.toLocaleString()}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 text-left">
                <div className="bg-white border border-[#E6E3DA] rounded-xl p-3">
                  <p className="text-xs text-[#5B625C]">Per serving target</p>
                  <p className="font-mono text-base font-bold text-[#1F2421] tabular-nums">
                    {currencyCfg.symbol}
                    {perServingDisplay} / serving
                  </p>
                </div>
                <div className="bg-white border border-[#E6E3DA] rounded-xl p-3">
                  <p className="text-xs text-[#5B625C]">Weekly servings</p>
                  <p className="font-mono text-base font-bold text-[#4A7C59] tabular-nums">
                    {servingsPerWeek} servings/week
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer Controls */}
        <div className="pt-4 border-t border-[#EFECE3] flex items-center justify-between gap-3">
          {step === 10 ? (
            <button
              onClick={() => setStep(11)}
              className="text-xs font-medium text-[#5B625C] hover:text-[#1F2421]"
            >
              Skip for now
            </button>
          ) : (
            <span className="text-xs text-[#5B625C] inline-flex items-center gap-1.5">
              {step === 1 && <Store className="w-3.5 h-3.5 text-[#4A7C59]" />}
              {step === 12 && <Wallet className="w-3.5 h-3.5 text-[#4A7C59]" />}
              {step !== 1 && step !== 12 && <Utensils className="w-3.5 h-3.5 text-[#4A7C59]" />}
              <span>
                {selectedStores[0] || 'Store'} · {portionsPerMeal} portions · {days.length} days
              </span>
            </span>
          )}

          {step < 12 ? (
            <button
              onClick={() => setStep(step + 1)}
              className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] inline-flex items-center gap-2"
            >
              <span>
                {step === 1
                  ? `Confirm (${selectedStores.length})`
                  : step === 11
                  ? `Continue · ${alreadyHave.length} selected`
                  : 'Next'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={generateTripPlan}
              className="px-5 py-2.5 rounded-xl bg-[#D97736] text-white text-sm font-semibold hover:opacity-95 inline-flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Build My Grocery & Meal Plan</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
