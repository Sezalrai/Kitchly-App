import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Plus,
  ShoppingCart,
  Trash2,
  UtensilsCrossed,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { CURRENCY_RATES, formatCurrency } from '../i18n/translations';
import { CurrencyCode, GroceryCategory, PantryItem, StorageLocation } from '../types/kitchly';

const STORAGE_LOCATIONS: StorageLocation[] = ['Fridge', 'Freezer', 'Pantry', 'Spice Rack'];
const CATEGORIES: GroceryCategory[] = [
  'Vegetables',
  'Fruits',
  'Dairy',
  'Meat and seafood',
  'Grains',
  'Bakery',
  'Spices',
  'Beverages',
  'Household essentials',
];

export function SmartPantryScreen() {
  const { state, t, savePantryItem, removePantryItem, saveGroceryItem, setScreen, showToast } = useKitchly();
  const [filterLoc, setFilterLoc] = useState<'All' | StorageLocation>('All');

  const todayISO = new Date().toISOString().split('T')[0];
  const weekISO = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];

  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState(500);
  const [unit, setUnit] = useState('g');
  const [category, setCategory] = useState<GroceryCategory>('Vegetables');
  const [storageLocation, setStorageLocation] = useState<StorageLocation>('Fridge');
  const [purchaseDate, setPurchaseDate] = useState(todayISO);
  const [expiryDate, setExpiryDate] = useState(weekISO);
  const [lowThreshold, setLowThreshold] = useState(150);

  const nowMs = Date.now();

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Enter an ingredient name first.');
      return;
    }
    const item: PantryItem = {
      id: `pan-${Date.now()}`,
      name: name.trim(),
      quantity: Math.max(0, quantity),
      unit: unit.trim() || 'pc',
      category,
      purchaseDate,
      expiryDate,
      storageLocation,
      lowStockThreshold: Math.max(0, lowThreshold),
    };
    savePantryItem(item);
    setName('');
    showToast(`Added "${item.name}" to ${item.storageLocation}.`);
  };

  const enriched = useMemo(() => {
    return state.pantry
      .filter((p) => filterLoc === 'All' || p.storageLocation === filterLoc)
      .map((item) => {
        const expMs = new Date(item.expiryDate).getTime();
        const daysLeft = Math.ceil((expMs - nowMs) / 86400000);
        const isExpiringSoon = daysLeft <= 3;
        const isLowStock = item.quantity <= item.lowStockThreshold;
        return { item, daysLeft, isExpiringSoon, isLowStock };
      })
      .sort((a, b) => a.daysLeft - b.daysLeft);
  }, [state.pantry, filterLoc, nowMs]);

  const expiringItems = enriched.filter((x) => x.isExpiringSoon);
  const lowStockItems = enriched.filter((x) => x.isLowStock);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">{t.smartPantry}</h2>
          <p className="text-sm text-[#5B625C]">
            Track fridge, freezer, and pantry stock with expiry reminders and low-stock alerts.
          </p>
        </div>
        <button
          onClick={() => setScreen('cook-with-have')}
          className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] inline-flex items-center gap-2 self-start"
        >
          <UtensilsCrossed className="w-4 h-4" />
          <span>Cook With Expiring Items</span>
        </button>
      </div>

      {/* Summary Alerts */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="bg-[#FDF2EC] border border-[#D97736]/30 rounded-2xl p-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#9A4A18] mb-1">
            <AlertTriangle className="w-4 h-4" />
            <span>Use Soon ({expiringItems.length} items expiring within 3 days)</span>
          </div>
          <p className="text-xs text-[#5B625C]">
            {expiringItems.length > 0
              ? expiringItems.map((e) => `${e.item.name} (${e.daysLeft <= 0 ? 'today' : `${e.daysLeft}d`})`).join(' · ')
              : 'No urgent expiries right now.'}
          </p>
        </div>
        <div className="bg-[#F3F1EA] border border-[#E6E3DA] rounded-2xl p-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#1F2421] mb-1">
            <ShoppingCart className="w-4 h-4 text-[#4A7C59]" />
            <span>{t.lowStock} ({lowStockItems.length} items below threshold)</span>
          </div>
          <p className="text-xs text-[#5B625C]">
            {lowStockItems.length > 0
              ? lowStockItems.map((l) => `${l.item.name} (${l.item.quantity} ${l.item.unit})`).join(' · ')
              : 'All pantry staples are well stocked.'}
          </p>
        </div>
      </div>

      {/* Add Inventory Form */}
      <form onSubmit={handleAdd} className="bg-white border border-[#E6E3DA] rounded-2xl p-5 grid sm:grid-cols-4 lg:grid-cols-8 gap-3 items-end">
        <div className="sm:col-span-2">
          <label className="block text-xs text-[#5B625C] mb-1">Ingredient</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Greek Yogurt"
            className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
          />
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Qty</label>
          <input
            type="number"
            min="0"
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
            className="w-full h-10 px-2.5 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
          />
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Unit</label>
          <input
            value={unit}
            onChange={(e) => setUnit(e.target.value)}
            className="w-full h-10 px-2.5 rounded-xl border border-[#E6E3DA] text-sm"
          />
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Location</label>
          <select
            value={storageLocation}
            onChange={(e) => setStorageLocation(e.target.value as StorageLocation)}
            className="w-full h-10 px-2 rounded-xl border border-[#E6E3DA] text-sm bg-white"
          >
            {STORAGE_LOCATIONS.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Expiry Date</label>
          <input
            type="date"
            value={expiryDate}
            onChange={(e) => setExpiryDate(e.target.value)}
            className="w-full h-10 px-2 rounded-xl border border-[#E6E3DA] text-xs"
          />
        </div>
        <div>
          <label className="block text-xs text-[#5B625C] mb-1">Low Alert At</label>
          <input
            type="number"
            min="0"
            value={lowThreshold}
            onChange={(e) => setLowThreshold(Number(e.target.value))}
            className="w-full h-10 px-2.5 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
          />
        </div>
        <button
          type="submit"
          className="h-10 px-4 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A] inline-flex items-center justify-center gap-1"
        >
          <Plus className="w-4 h-4" />
          <span>Add</span>
        </button>
        <div className="sm:col-span-4 lg:col-span-8 flex flex-wrap gap-3 pt-2 border-t border-[#EFECE3] text-xs text-[#5B625C]">
          <label className="inline-flex items-center gap-2">
            <span>Category:</span>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as GroceryCategory)}
              className="h-8 px-2 rounded-lg border border-[#E6E3DA] bg-white text-xs"
            >
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
          <label className="inline-flex items-center gap-2">
            <span>Purchased:</span>
            <input
              type="date"
              value={purchaseDate}
              onChange={(e) => setPurchaseDate(e.target.value)}
              className="h-8 px-2 rounded-lg border border-[#E6E3DA] text-xs"
            />
          </label>
        </div>
      </form>

      {/* Location Filter */}
      <div className="flex flex-wrap gap-1.5">
        {(['All', ...STORAGE_LOCATIONS] as const).map((loc) => (
          <button
            key={loc}
            onClick={() => setFilterLoc(loc)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              filterLoc === loc ? 'bg-[#4A7C59] text-white' : 'bg-white border border-[#E6E3DA] text-[#1F2421]'
            }`}
          >
            {loc}
          </button>
        ))}
      </div>

      {/* Inventory Table */}
      <div className="bg-white border border-[#E6E3DA] rounded-2xl overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-[#E6E3DA] text-xs text-[#5B625C]">
              <th className="py-3 px-4 font-medium">Ingredient</th>
              <th className="py-3 px-4 font-medium">Location</th>
              <th className="py-3 px-4 font-medium text-right">Quantity</th>
              <th className="py-3 px-4 font-medium">Purchased</th>
              <th className="py-3 px-4 font-medium">Expires</th>
              <th className="py-3 px-4 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#EFECE3] text-sm">
            {enriched.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-10 px-4 text-center text-sm text-[#5B625C]">
                  Your pantry is empty. Add your fridge, freezer, or spice rack staples above so Kitchly can recommend zero-waste recipes and track expiries.
                </td>
              </tr>
            ) : (
              enriched.map(({ item, daysLeft, isExpiringSoon, isLowStock }) => (
              <tr key={item.id} className="hover:bg-[#FAF9F5]">
                <td className="py-3 px-4">
                  <div className="font-medium text-[#1F2421]">{item.name}</div>
                  <div className="text-xs text-[#5B625C]">
                    {item.category}
                    {isExpiringSoon && <span className="text-[#D97736] font-semibold"> · {t.useSoon}</span>}
                    {isLowStock && <span className="text-[#D97736] font-semibold"> · {t.lowStock}</span>}
                  </div>
                </td>
                <td className="py-3 px-4 text-xs text-[#5B625C]">{item.storageLocation}</td>
                <td className="py-3 px-4 text-right font-mono tabular-nums">
                  <input
                    type="number"
                    min="0"
                    aria-label={`Quantity for ${item.name}`}
                    value={item.quantity}
                    onChange={(e) => savePantryItem({ ...item, quantity: Math.max(0, Number(e.target.value)) })}
                    className="w-16 h-8 px-2 rounded border border-[#E6E3DA] text-right text-xs font-mono mr-1"
                  />
                  <span className="text-xs text-[#5B625C]">{item.unit}</span>
                </td>
                <td className="py-3 px-4 text-xs font-mono text-[#5B625C] tabular-nums">{item.purchaseDate}</td>
                <td className={`py-3 px-4 text-xs font-mono tabular-nums ${isExpiringSoon ? 'text-[#D97736] font-semibold' : 'text-[#5B625C]'}`}>
                  {item.expiryDate} ({daysLeft <= 0 ? 'due' : `${daysLeft}d`})
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="inline-flex items-center gap-2">
                    <button
                      onClick={() => {
                        saveGroceryItem({
                          id: `groc-restock-${Date.now()}`,
                          name: item.name,
                          quantity: Math.max(1, item.lowStockThreshold || 1),
                          unit: item.unit,
                          category: item.category,
                          estimatedCostINR: 75,
                          purchased: false,
                          source: 'pantry-restock',
                        });
                        showToast(`Added "${item.name}" to shopping list.`);
                      }}
                      className="text-xs font-medium text-[#4A7C59] hover:underline"
                    >
                      + Restock
                    </button>
                    <button
                      onClick={() => removePantryItem(item.id)}
                      aria-label={`Delete ${item.name}`}
                      className="p-1 text-[#5B625C] hover:text-[#D97736]"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function BudgetManagementScreen() {
  const { state, updateDietProfile, setCurrency, showToast } = useKitchly();
  const [daily, setDaily] = useState(state.dietProfile.dailyBudget);
  const [weekly, setWeekly] = useState(state.dietProfile.weeklyBudget);
  const [monthly, setMonthly] = useState(state.dietProfile.monthlyBudget);

  useEffect(() => {
    setDaily(state.dietProfile.dailyBudget);
    setWeekly(state.dietProfile.weeklyBudget);
    setMonthly(state.dietProfile.monthlyBudget);
  }, [state.user.id, state.dietProfile.dailyBudget, state.dietProfile.weeklyBudget, state.dietProfile.monthlyBudget]);

  const basketSpendINR = state.groceryList.reduce((sum, g) => sum + g.estimatedCostINR, 0);
  const categoryBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    state.groceryList.forEach((g) => {
      map.set(g.category, (map.get(g.category) || 0) + g.estimatedCostINR);
    });
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [state.groceryList]);

  const monthlyPct = monthly > 0 ? Math.min(100, Math.round((state.monthlySpentINR / monthly) * 100)) : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">Budget Management</h2>
          <p className="text-sm text-[#5B625C]">
            Monitor daily, weekly, and monthly grocery budgets alongside pantry & comparison savings.
          </p>
        </div>
        <select
          aria-label="Currency selector"
          value={state.user.currency}
          onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
          className="h-10 px-3 rounded-xl bg-white border border-[#E6E3DA] text-sm font-medium self-start"
        >
          {Object.entries(CURRENCY_RATES).map(([code, meta]) => (
            <option key={code} value={code}>
              {meta.label}
            </option>
          ))}
        </select>
      </div>

      {/* KPI Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 tabular-nums">
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
          <p className="text-xs text-[#5B625C] mb-1">Monthly Spend vs Target</p>
          <p className="font-mono text-xl font-bold text-[#1F2421]">
            {formatCurrency(state.monthlySpentINR, state.user.currency)}
          </p>
          <p className="text-xs text-[#5B625C] mt-1">
            {monthly > 0 ? `of ${formatCurrency(monthly, state.user.currency)} (${monthlyPct}%)` : 'Monthly cap not set'}
          </p>
        </div>
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
          <p className="text-xs text-[#5B625C] mb-1">Current Grocery Basket</p>
          <p className="font-mono text-xl font-bold text-[#1F2421]">
            {formatCurrency(basketSpendINR, state.user.currency)}
          </p>
          <p className="text-xs text-[#4A7C59] mt-1">
            {weekly > 0 ? `Weekly cap: ${formatCurrency(weekly, state.user.currency)}` : 'Weekly cap not set'}
          </p>
        </div>
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
          <p className="text-xs text-[#5B625C] mb-1">Smart Comparison & Pantry Savings</p>
          <p className="font-mono text-xl font-bold text-[#4A7C59]">
            {formatCurrency(state.estimatedSavingsINR, state.user.currency)}
          </p>
          <p className="text-xs text-[#5B625C] mt-1">Estimated this month</p>
        </div>
        <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
          <p className="text-xs text-[#5B625C] mb-1">Daily Meal Budget</p>
          <p className="font-mono text-xl font-bold text-[#1F2421]">
            {daily > 0 ? formatCurrency(daily, state.user.currency) : 'Not set'}
          </p>
          <p className="text-xs text-[#5B625C] mt-1">Per household day</p>
        </div>
      </div>

      {/* Edit Budget Targets + Category Breakdown */}
      <div className="grid lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-display text-base font-semibold">Adjust Budget Targets (INR base)</h3>
            <button
              type="button"
              onClick={() => {
                if (weekly > 0) {
                  setDaily(Math.round(weekly / 7));
                  setMonthly(Math.round(weekly * 4.3));
                }
              }}
              className="text-xs font-medium text-[#4A7C59] hover:underline"
            >
              Auto-calc from Weekly
            </button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#5B625C] mb-1">Daily Food Budget</label>
              <input
                type="number"
                min={0}
                value={daily}
                onChange={(e) => setDaily(Math.max(0, Number(e.target.value) || 0))}
                className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm font-mono tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs text-[#5B625C] mb-1">Weekly Grocery Budget</label>
              <input
                type="number"
                min={0}
                value={weekly}
                onChange={(e) => setWeekly(Math.max(0, Number(e.target.value) || 0))}
                className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm font-mono tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs text-[#5B625C] mb-1">Monthly Grocery Budget</label>
              <input
                type="number"
                min={0}
                value={monthly}
                onChange={(e) => setMonthly(Math.max(0, Number(e.target.value) || 0))}
                className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm font-mono tabular-nums"
              />
            </div>
          </div>
          <button
            onClick={() => {
              updateDietProfile({
                ...state.dietProfile,
                dailyBudget: daily,
                weeklyBudget: weekly,
                monthlyBudget: monthly,
              });
              showToast('Budget targets updated.');
            }}
            className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-medium hover:bg-[#3D684A]"
          >
            Save Budget Targets
          </button>
        </div>

        <div className="lg:col-span-6 bg-white border border-[#E6E3DA] rounded-2xl p-6 space-y-4">
          <h3 className="font-display text-base font-semibold">Spend Breakdown by Category</h3>
          {categoryBreakdown.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#5B625C]">
              No items in your grocery basket yet. Add items manually or build a Guided Trip to see category spend breakdown.
            </div>
          ) : (
            <div className="space-y-3">
              {categoryBreakdown.map(([cat, amt]) => {
                const pct = basketSpendINR > 0 ? Math.round((amt / basketSpendINR) * 100) : 0;
                return (
                  <div key={cat} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-[#1F2421]">{cat}</span>
                      <span className="font-mono text-[#5B625C] tabular-nums">
                        {formatCurrency(amt, state.user.currency)} ({pct}%)
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-[#EFECE3] overflow-hidden">
                      <div className="h-full bg-[#4A7C59]" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
