import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  ChefHat,
  ListChecks,
  Package,
  Scale,
  Send,
  ShoppingCart,
  Sparkles,
  UtensilsCrossed,
} from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { IMAGES } from '../data/recipes';
import { formatCurrency } from '../i18n/translations';
import { FoodImage } from '../components/Logo';
import { MobileAppInstallBanner } from '../components/PWAComponents';

export function DashboardScreen() {
  const {
    state,
    t,
    setScreen,
    openRecipe,
    allRecipes,
    toggleGroceryPurchased,
    askAssistantWithPrompt,
  } = useKitchly();

  const [quickPrompt, setQuickPrompt] = useState('');

  const recipeMap = new Map(allRecipes.map((r) => [r.id, r]));
  const todayPlan = state.currentDietPlan;
  const firstWeekDay = state.weeklyPlan[0];

  const todayMeals = [
    {
      slot: t.breakfast,
      recipe: todayPlan?.breakfast || (firstWeekDay?.breakfastId ? recipeMap.get(firstWeekDay.breakfastId) : undefined),
    },
    {
      slot: t.lunch,
      recipe: todayPlan?.lunch || (firstWeekDay?.lunchId ? recipeMap.get(firstWeekDay.lunchId) : undefined),
    },
    {
      slot: t.dinner,
      recipe: todayPlan?.dinner || (firstWeekDay?.dinnerId ? recipeMap.get(firstWeekDay.dinnerId) : undefined),
    },
    {
      slot: t.snacks,
      recipe: todayPlan?.morningSnack || (firstWeekDay?.snackId ? recipeMap.get(firstWeekDay.snackId) : undefined),
    },
  ].filter((m): m is { slot: string; recipe: NonNullable<typeof m.recipe> } => Boolean(m.recipe));

  const hasPlannedMenu = todayMeals.length > 0;
  const featuredMeal = todayMeals.find((m) => m.slot === t.dinner)?.recipe || todayMeals[0]?.recipe;

  const now = new Date();
  const expiringSoon = state.pantry.filter((item) => {
    const exp = new Date(item.expiryDate);
    const diffDays = Math.ceil((exp.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays <= 3;
  });

  const fridgeCount = state.pantry.filter((p) => p.storageLocation === 'Fridge' || p.storageLocation === 'Freezer').length;
  const pantryOnlyCount = state.pantry.length - fridgeCount;

  const pendingGroceries = state.groceryList.filter((g) => !g.purchased);
  const estimatedBasketINR = pendingGroceries.reduce((acc, g) => acc + g.estimatedCostINR, 0);
  const hasWeeklyBudget = state.dietProfile.weeklyBudget > 0;
  const weeklyBudgetPct = hasWeeklyBudget
    ? Math.min(100, Math.round((estimatedBasketINR / Math.max(1, state.dietProfile.weeklyBudget)) * 100))
    : 0;
  const isOverBudget = hasWeeklyBudget && estimatedBasketINR > state.dietProfile.weeklyBudget;

  const shortcuts = [
    {
      label: t.dontKnowWhatToEat,
      hint: 'Mood-based meal picks',
      screen: 'dont-know' as const,
      icon: Sparkles,
      featured: true,
      accent: 'bg-[#D97736] text-white border-[#D97736]',
    },
    {
      label: t.cookWithWhatIHave,
      hint: 'Match your fridge stock',
      screen: 'cook-with-have' as const,
      icon: UtensilsCrossed,
      featured: true,
      accent: 'bg-[#4A7C59] text-white border-[#4A7C59]',
    },
    {
      label: t.dietPlanner,
      hint: 'Allergies & daily macros',
      screen: 'diet-planner' as const,
      icon: ChefHat,
      featured: false,
      accent: 'bg-white text-[#1F2421] border-[#E6E3DA]',
    },
    {
      label: t.mealPlanner,
      hint: '7-day family schedule',
      screen: 'meal-planner' as const,
      icon: CalendarDays,
      featured: false,
      accent: 'bg-white text-[#1F2421] border-[#E6E3DA]',
    },
    {
      label: t.comparePrices,
      hint: 'Stores & split savings',
      screen: 'price-comparison' as const,
      icon: Scale,
      featured: false,
      accent: 'bg-white text-[#1F2421] border-[#E6E3DA]',
    },
    {
      label: t.smartPantry,
      hint: 'Expiry & restock tracking',
      screen: 'pantry' as const,
      icon: Package,
      featured: false,
      accent: 'bg-white text-[#1F2421] border-[#E6E3DA]',
    },
  ];

  const handleQuickAsk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickPrompt.trim()) {
      setScreen('ai-assistant');
      return;
    }
    const q = quickPrompt.trim();
    setQuickPrompt('');
    askAssistantWithPrompt(q);
  };

  return (
    <div className="space-y-6 sm:space-y-8">
      <MobileAppInstallBanner />

      {/* Culinary Command Hero Split */}
      <section className="grid lg:grid-cols-12 gap-5 items-stretch">
        <div className="lg:col-span-7 bg-[#1E3A2A] text-[#FAF9F5] rounded-2xl p-6 lg:p-7 flex flex-col justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-[#B8D2C0]">
              <span>{state.user.householdName}</span>
              <span aria-hidden="true">·</span>
              <span>{state.dietProfile.householdSize} Eating</span>
              <span aria-hidden="true">·</span>
              <span>{state.user.currency}</span>
              {state.dietProfile.foodPreferences.length > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{state.dietProfile.foodPreferences.join(', ')}</span>
                </>
              )}
            </div>
            <h2
              className="font-display text-2xl sm:text-3xl font-bold leading-[1.16] text-white"
              style={{ textWrap: 'balance' }}
            >
              {t.welcomeGreeting}
            </h2>
            <p className="text-sm text-[#D6E6DC] max-w-xl leading-relaxed">
              {hasPlannedMenu
                ? `Your menu is ready with ${pendingGroceries.length} grocery item(s) to buy and ${state.pantry.length} pantry item(s) stocked.`
                : 'Start by building a guided grocery trip, generating a custom diet plan, or asking Kitchly AI anything about cooking and setup.'}
            </p>
          </div>

          {/* Inline AI Quick-Ask Bar */}
          <form onSubmit={handleQuickAsk} className="flex flex-col sm:flex-row gap-2">
            <input
              value={quickPrompt}
              onChange={(e) => setQuickPrompt(e.target.value)}
              placeholder="Ask Kitchly AI anything (recipes, change language, budget tips, pantry ideas)..."
              className="flex-1 h-11 px-4 rounded-xl bg-white/10 border border-white/20 text-sm text-white placeholder:text-[#B8D2C0] focus:outline-none focus:bg-white/15 focus:border-white/50"
            />
            <button
              type="submit"
              className="h-11 px-5 rounded-xl bg-[#D97736] text-white text-sm font-semibold hover:opacity-95 transition-opacity inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Ask AI</span>
            </button>
          </form>

          {/* Primary Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            {!state.user.onboarded ? (
              <button
                onClick={() => setScreen('onboarding')}
                className="px-4 py-2.5 rounded-xl bg-[#FAF9F5] text-[#1E3A2A] text-sm font-semibold hover:bg-white transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4 text-[#D97736]" />
                <span>Complete Kitchen Setup</span>
              </button>
            ) : (
              <button
                onClick={() => setScreen('grocery-wizard')}
                className="px-4 py-2.5 rounded-xl bg-[#FAF9F5] text-[#1E3A2A] text-sm font-semibold hover:bg-white transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
              >
                <ListChecks className="w-4 h-4 text-[#4A7C59]" />
                <span>Build Grocery Trip</span>
              </button>
            )}
            <button
              onClick={() => setScreen('cook-mode')}
              className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/15 text-white text-sm font-medium hover:bg-white/20 transition-colors whitespace-nowrap shrink-0"
            >
              Open {t.cookMode} →
            </button>
            <button
              onClick={() => setScreen('community')}
              className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/15 text-white text-sm font-medium hover:bg-white/20 transition-colors whitespace-nowrap shrink-0"
            >
              Share & Explore Community
            </button>
            {!state.user.onboarded && (
              <button
                onClick={() => setScreen('grocery-wizard')}
                className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/15 text-white text-sm font-medium hover:bg-white/20 transition-colors whitespace-nowrap shrink-0"
              >
                Build Grocery Trip
              </button>
            )}
          </div>
        </div>

        {/* Right Hero Spotlight */}
        <div className="lg:col-span-5">
          {featuredMeal ? (
            <button
              onClick={() => openRecipe(featuredMeal)}
              className="group relative w-full h-full min-h-[260px] rounded-2xl overflow-hidden border border-[#E6E3DA] text-left flex flex-col justify-end"
            >
              <FoodImage
                src={featuredMeal.image}
                alt={featuredMeal.title}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/10" />
              <div className="relative p-6 text-white space-y-1.5">
                <p className="text-xs font-medium text-[#E6E3DA]">
                  Today’s Featured Dish · {featuredMeal.cuisine} · {featuredMeal.prepTimeMins} min
                </p>
                <h3 className="font-display text-xl font-bold leading-snug line-clamp-2">
                  {featuredMeal.title}
                </h3>
                <div className="flex items-center justify-between pt-2 text-xs text-[#E6E3DA] tabular-nums">
                  <span>
                    {featuredMeal.nutrition.calories} kcal · {featuredMeal.nutrition.protein}g protein
                  </span>
                  <span className="font-semibold text-white inline-flex items-center gap-1">
                    <span>View Recipe</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </button>
          ) : (
            <div className="relative w-full h-full min-h-[260px] rounded-2xl overflow-hidden border border-[#E6E3DA] flex flex-col justify-end">
              <FoodImage
                src={IMAGES.hero}
                alt="Fresh kitchen ingredients ready for your first meal plan"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/15" />
              <div className="relative p-6 text-white space-y-2.5">
                <p className="text-xs font-medium text-[#E6E3DA]">
                  Fresh Kitchen · Zero Pre-Filled Clutter
                </p>
                <h3 className="font-display text-xl font-bold leading-snug">
                  Ready for your first personalized menu?
                </h3>
                <p className="text-xs text-[#E6E3DA] leading-relaxed">
                  Tell Kitchly your tastes, allergies, and budget to create your custom weekly meals and smart shopping list.
                </p>
                <div className="pt-1 flex flex-wrap gap-2">
                  <button
                    onClick={() => setScreen('diet-planner')}
                    className="px-4 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A] inline-flex items-center gap-1.5"
                  >
                    <span>Generate Meal Plan</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Budget & Kitchen Summary Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => setScreen('budget')}
          className="bg-white border border-[#E6E3DA] rounded-2xl p-5 text-left hover:border-[#4A7C59] transition-colors flex flex-col justify-between gap-2.5"
        >
          <div>
            <p className="text-xs font-medium text-[#5B625C] mb-1">{t.weeklyGroceryBudget}</p>
            <p className="font-mono text-2xl font-bold text-[#1F2421] tabular-nums">
              {hasWeeklyBudget ? formatCurrency(state.dietProfile.weeklyBudget, state.user.currency) : 'Not set'}
            </p>
          </div>
          {hasWeeklyBudget ? (
            <div className="space-y-1.5">
              <div className="h-1.5 w-full bg-[#EFECE3] rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${isOverBudget ? 'bg-[#D97736]' : 'bg-[#4A7C59]'}`}
                  style={{ width: `${weeklyBudgetPct}%` }}
                />
              </div>
              <p className={`text-xs tabular-nums ${isOverBudget ? 'text-[#D97736] font-medium' : 'text-[#4A7C59]'}`}>
                Basket: {formatCurrency(estimatedBasketINR, state.user.currency)} ({weeklyBudgetPct}%)
              </p>
            </div>
          ) : (
            <p className="text-xs font-medium text-[#4A7C59]">Set your weekly target →</p>
          )}
        </button>

        <button
          onClick={() => setScreen('price-comparison')}
          className="bg-white border border-[#E6E3DA] rounded-2xl p-5 text-left hover:border-[#4A7C59] transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <p className="text-xs font-medium text-[#5B625C] mb-1">{t.estimatedSavings}</p>
            <p className="font-mono text-2xl font-bold text-[#4A7C59] tabular-nums">
              {formatCurrency(state.estimatedSavingsINR, state.user.currency)}
            </p>
          </div>
          <p className="text-xs text-[#5B625C]">Compare store baskets & pantry reuse →</p>
        </button>

        <button
          onClick={() => setScreen('pantry')}
          className="bg-white border border-[#E6E3DA] rounded-2xl p-5 text-left hover:border-[#4A7C59] transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <p className="text-xs font-medium text-[#5B625C] mb-1">{t.availableIngredients}</p>
            <p className="font-mono text-2xl font-bold text-[#1F2421] tabular-nums">
              {state.pantry.length} {state.pantry.length === 1 ? 'item' : 'items'}
            </p>
          </div>
          <p className="text-xs text-[#5B625C]">
            {state.pantry.length > 0
              ? `${fridgeCount} Fridge/Freezer · ${pantryOnlyCount} Pantry`
              : 'Add pantry staples →'}
          </p>
        </button>

        <button
          onClick={() => setScreen('pantry')}
          className="bg-white border border-[#E6E3DA] rounded-2xl p-5 text-left hover:border-[#D97736] transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <p className="text-xs font-medium text-[#5B625C] mb-1">{t.upcomingExpiry}</p>
            <p className={`font-mono text-2xl font-bold tabular-nums ${expiringSoon.length > 0 ? 'text-[#D97736]' : 'text-[#1F2421]'}`}>
              {expiringSoon.length} alert{expiringSoon.length === 1 ? '' : 's'}
            </p>
          </div>
          <p className="text-xs text-[#5B625C] truncate">
            {expiringSoon.length > 0 ? expiringSoon.map((i) => i.name).join(', ') : 'All items fresh'}
          </p>
        </button>
      </section>

      {/* 6 Interactive Kitchen Shortcuts */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-base font-semibold text-[#1F2421]">Quick Kitchen Actions</h3>
          <button
            onClick={() => setScreen('cuisine-explorer')}
            className="text-xs font-medium text-[#4A7C59] hover:underline"
          >
            Browse 14+ Cuisines →
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {shortcuts.map((sc) => {
            const Icon = sc.icon;
            return (
              <button
                key={sc.screen}
                onClick={() => setScreen(sc.screen)}
                className={`p-4 rounded-xl border text-left transition-transform active:scale-[0.98] hover:opacity-95 flex flex-col justify-between min-h-[104px] ${sc.accent}`}
              >
                <Icon className={`w-4 h-4 mb-3 shrink-0 ${sc.featured ? 'text-white' : 'text-[#4A7C59]'}`} />
                <div className="space-y-0.5">
                  <div className="text-xs font-semibold leading-snug line-clamp-2">{sc.label}</div>
                  <div className={`text-[11px] line-clamp-1 ${sc.featured ? 'text-white/80' : 'text-[#5B625C]'}`}>
                    {sc.hint}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Today's Menu: Breakfast, Lunch, Dinner, Snacks */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg font-semibold text-[#1F2421]">Today’s Menu</h3>
          <button
            onClick={() => setScreen('diet-planner')}
            className="text-sm font-medium text-[#4A7C59] hover:text-[#3D684A] inline-flex items-center gap-1"
          >
            <span>{hasPlannedMenu ? 'Customize Diet Plan' : 'Create Meal Plan'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {hasPlannedMenu ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {todayMeals.map(({ slot, recipe }) => (
              <button
                key={slot}
                onClick={() => openRecipe(recipe)}
                className="group bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden text-left hover:border-[#4A7C59] transition-colors flex flex-col"
              >
                <div className="h-40 w-full overflow-hidden">
                  <FoodImage
                    src={recipe.image}
                    alt={recipe.title}
                    className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform"
                  />
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-xs font-medium text-[#4A7C59] mb-1">
                      {slot} · {recipe.cuisine}
                    </p>
                    <h4 className="font-display text-sm font-semibold text-[#1F2421] line-clamp-2 mb-2">
                      {recipe.title}
                    </h4>
                  </div>
                  <p className="text-xs text-[#5B625C] tabular-nums pt-2 border-t border-[#EFECE3]">
                    {recipe.prepTimeMins} min · {recipe.nutrition.calories} kcal ·{' '}
                    {formatCurrency(recipe.estimatedCostINR, state.user.currency)}
                  </p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="bg-white border border-[#E6E3DA] rounded-2xl p-6 grid sm:grid-cols-3 gap-4 items-center">
            <div className="sm:col-span-2 space-y-1.5">
              <h4 className="font-display text-base font-semibold text-[#1F2421]">
                No meals scheduled for today yet
              </h4>
              <p className="text-sm text-[#5B625C] leading-relaxed">
                Generate a personalized menu tailored to your allergies, cuisines, and budget, or build a weekly grocery trip in minutes.
              </p>
            </div>
            <div className="flex flex-wrap sm:justify-end gap-2">
              <button
                onClick={() => setScreen('diet-planner')}
                className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A]"
              >
                Personal Diet Planner
              </button>
              <button
                onClick={() => setScreen('dont-know')}
                className="px-4 py-2.5 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7]"
              >
                Surprise Picks
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Split Section: Weekly Plan Preview + Interactive Grocery & Expiry */}
      <section className="grid lg:grid-cols-12 gap-6">
        {/* Weekly Meal Plan Strip */}
        <div className="lg:col-span-7 bg-white border border-[#E6E3DA] rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-base font-semibold text-[#1F2421]">{t.weeklyMealPlan}</h3>
              <button
                onClick={() => setScreen('meal-planner')}
                className="text-xs font-medium text-[#4A7C59] hover:underline"
              >
                {state.weeklyPlan.length > 0 ? 'Edit Full Week' : 'Open Planner'}
              </button>
            </div>
            {state.weeklyPlan.length === 0 ? (
              <div className="py-6 text-center space-y-3">
                <p className="text-sm text-[#5B625C]">
                  Your 7-day meal schedule is empty. Plan days manually or generate meals with the Guided Trip Builder.
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  <button
                    onClick={() => setScreen('grocery-wizard')}
                    className="px-4 py-2 rounded-xl bg-[#D97736] text-white text-xs font-semibold hover:opacity-95"
                  >
                    Build Weekly Trip
                  </button>
                  <button
                    onClick={() => setScreen('meal-planner')}
                    className="px-4 py-2 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs font-semibold hover:bg-[#E7E3D7]"
                  >
                    Open Weekly Planner
                  </button>
                </div>
              </div>
            ) : (
              <div className="divide-y divide-[#EFECE3]">
                {state.weeklyPlan.slice(0, 5).map((day) => {
                  const lunch = recipeMap.get(day.lunchId);
                  const dinner = recipeMap.get(day.dinnerId);
                  return (
                    <div key={day.day} className="py-2.5 flex items-center justify-between gap-4 text-sm">
                      <span className="font-medium text-[#1F2421] w-24 shrink-0">{day.day}</span>
                      <div className="flex-1 min-w-0 text-xs text-[#5B625C] truncate">
                        <span className="text-[#1F2421] font-medium">{lunch?.title || 'Unassigned'}</span>
                        <span className="mx-1.5" aria-hidden="true">·</span>
                        <span>{dinner?.title || 'Unassigned'}</span>
                      </div>
                      {dinner && (
                        <button
                          onClick={() => openRecipe(dinner)}
                          className="text-xs font-medium text-[#4A7C59] hover:underline shrink-0"
                        >
                          View
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Interactive Grocery List + Expiry Alerts */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display text-base font-semibold text-[#1F2421] flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-[#4A7C59]" />
                <span>{t.groceryList}</span>
              </h3>
              <button
                onClick={() => setScreen('grocery-list')}
                className="text-xs font-medium text-[#4A7C59] hover:underline"
              >
                Open List ({pendingGroceries.length})
              </button>
            </div>
            {state.groceryList.length === 0 ? (
              <div className="py-3 space-y-2.5">
                <p className="text-xs text-[#5B625C]">
                  Your grocery cart is empty. Add items manually or build a custom shopping trip.
                </p>
                <button
                  onClick={() => setScreen('grocery-list')}
                  className="px-3.5 py-2 rounded-xl bg-[#F3F1EA] text-xs font-semibold text-[#1F2421] hover:bg-[#E7E3D7]"
                >
                  + Add Grocery Items
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {state.groceryList.slice(0, 4).map((item) => (
                  <button
                    key={item.id}
                    onClick={() => toggleGroceryPurchased(item.id)}
                    className="w-full flex items-center justify-between py-1.5 text-sm text-left hover:bg-[#FAF9F5] rounded px-1"
                  >
                    <span className={`flex items-center gap-2 ${item.purchased ? 'line-through text-[#5B625C]' : 'text-[#1F2421]'}`}>
                      <CheckCircle2 className={`w-4 h-4 ${item.purchased ? 'text-[#4A7C59]' : 'text-[#D4CFC2]'}`} />
                      <span>{item.name}</span>
                    </span>
                    <span className="text-xs font-mono text-[#5B625C] tabular-nums">
                      {item.quantity} {item.unit}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="bg-[#F3F1EA] border border-[#E6E3DA] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-display text-sm font-semibold text-[#1F2421] flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-[#D97736]" />
                <span>{t.useSoon}</span>
              </h3>
              <button
                onClick={() => setScreen('cook-with-have')}
                className="text-xs font-medium text-[#D97736] hover:underline"
              >
                Cook Now
              </button>
            </div>
            {expiringSoon.length === 0 ? (
              <p className="text-xs text-[#5B625C]">
                {state.pantry.length === 0
                  ? 'Add fridge or pantry items to track expiry alerts.'
                  : 'No items expiring in the next 3 days.'}
              </p>
            ) : (
              <div className="space-y-1.5">
                {expiringSoon.slice(0, 3).map((item) => (
                  <div key={item.id} className="flex items-center justify-between text-xs">
                    <span className="font-medium text-[#1F2421]">{item.name}</span>
                    <span className="text-[#D97736] font-mono tabular-nums">
                      {item.quantity} {item.unit} · exp {item.expiryDate}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
