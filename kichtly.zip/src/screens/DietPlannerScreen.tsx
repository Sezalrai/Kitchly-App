import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarDays, RefreshCw, Save, Sparkles, Star, Plus, CalendarPlus, Loader2, Search, SlidersHorizontal, Flame, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { useKitchly } from '../context/KitchlyContext';
import { CURRENCY_RATES, formatCurrency } from '../i18n/translations';
import { postJson } from '../services/apiClient';
import {
  AllergyType,
  CuisineType,
  CurrencyCode,
  DietaryPrefType,
  DietPlannerProfile,
  DietType,
  GeneratedDietPlan,
  GoalType,
  Recipe,
} from '../types/kitchly';
import { FoodImage } from '../components/Logo';
import { isNationalIndianCuisine } from '../data/recipes';

const FOOD_PREFS: DietType[] = ['Vegetarian', 'Non-vegetarian', 'Eggetarian', 'Vegan', 'Pescatarian', 'Flexitarian'];
const NATIONAL_CUISINE_PRESETS = ['Indian', 'North Indian', 'South Indian', 'Punjabi', 'Hyderabadi'];
const INTERNATIONAL_CUISINES: CuisineType[] = [
  'Italian', 'Continental', 'Chinese', 'Korean', 'Japanese', 'Mexican', 'Mediterranean', 'Thai', 'American', 'French', 'Middle Eastern', 'Turkish', 'Spanish',
];
const ALL_PRESET_CUISINES: string[] = [...NATIONAL_CUISINE_PRESETS, ...INTERNATIONAL_CUISINES];
const ALLERGY_LIST: AllergyType[] = ['Nut allergies', 'Dairy intolerance', 'Gluten intolerance', 'Lactose intolerance', 'Shellfish allergies', 'Soy allergies', 'Egg allergy'];
const DIETARY_PREFS: DietaryPrefType[] = [
  'Zero sugar',
  'Low oil',
  'Less fat',
  'Gluten-free',
  'Dairy-free',
  'Low-sodium',
  'High-protein',
  'Plant-based',
];
const CLEAN_BUILDER_RULES: DietaryPrefType[] = ['Zero sugar', 'Low oil', 'Less fat', 'High-protein', 'Low-sodium'];
const GOAL_LIST: GoalType[] = ['Balanced everyday eating', 'Weight management', 'Muscle gain', 'High-protein meals', 'Budget-friendly meals', 'Family meal planning', 'General nutrition improvement'];

const WEEK_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const;

export function DietPlannerScreen() {
  const {
    state,
    allRecipes,
    t,
    updateDietProfile,
    setCurrency,
    setDietPlan,
    updateWeeklySlot,
    setWeeklyPlanBulk,
    addCustomRecipe,
    openRecipe,
    toggleFavoriteRecipe,
    addRecipeIngredientsToGrocery,
    showToast,
    setScreen,
  } = useKitchly();

  const [form, setForm] = useState<DietPlannerProfile>(state.dietProfile);
  const [showQuestionnaire, setShowQuestionnaire] = useState(!state.currentDietPlan);
  const [loadingPlan, setLoadingPlan] = useState(false);
  const [replacingSlot, setReplacingSlot] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [newLove, setNewLove] = useState('');
  const [newDislike, setNewDislike] = useState('');
  const [newAvoidVeg, setNewAvoidVeg] = useState('');
  const [newNever, setNewNever] = useState('');
  const [newAllergy, setNewAllergy] = useState('');
  const [newCuisine, setNewCuisine] = useState('');
  const [servingsScale, setServingsScale] = useState(form.householdSize || 1);
  const [mealSearch, setMealSearch] = useState('');
  const [slotFilter, setSlotFilter] = useState<'All' | 'Breakfast' | 'Snack' | 'Lunch' | 'Dinner' | 'Dessert'>('All');
  const [regionFilter, setRegionFilter] = useState<'all' | 'national' | 'international'>('all');
  const [dietQuickFilter, setDietQuickFilter] = useState<
    'All' | 'quick' | 'zero-sugar' | 'low-oil' | 'less-fat' | 'veg' | 'vegan' | 'high-protein' | 'favorites'
  >('All');
  const [sortBy, setSortBy] = useState<'schedule' | 'cost-asc' | 'cost-desc' | 'prep-asc' | 'cal-asc' | 'cal-desc' | 'protein-desc'>('schedule');
  const [libraryTab, setLibraryTab] = useState<'national' | 'international'>('national');
  const [libraryApplySlot, setLibraryApplySlot] = useState<'breakfast' | 'lunch' | 'dinner' | 'morningSnack'>('lunch');

  // 1-Day Calorie & Available-Food Diet Builder
  const [showCalBuilder, setShowCalBuilder] = useState(true);
  const [dayCalorieTarget, setDayCalorieTarget] = useState<number>(state.dietProfile.calorieTarget || 1800);
  const [availableFoodInput, setAvailableFoodInput] = useState('');
  const foodInputRef = useRef<HTMLInputElement>(null);
  const [availableFoods, setAvailableFoods] = useState<string[]>(() =>
    Array.from(new Set(state.pantry.slice(0, 6).map((p) => p.name)))
  );
  const [strictFoodsOnly, setStrictFoodsOnly] = useState(false);
  const [builderRegion, setBuilderRegion] = useState<'all' | 'national' | 'international'>('all');
  const [portionPref, setPortionPref] = useState<'auto' | 'small' | 'regular'>('auto');
  const [loadingCalPlan, setLoadingCalPlan] = useState(false);
  const [weeklyDietDays, setWeeklyDietDays] = useState<Record<string, GeneratedDietPlan> | null>(null);
  const [activeWeekDay, setActiveWeekDay] = useState<string>('Monday');
  const planResultRef = useRef<HTMLDivElement>(null);

  const scrollToPlan = () => {
    window.setTimeout(() => {
      planResultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const [didAutoOpenPlan, setDidAutoOpenPlan] = useState(Boolean(state.currentDietPlan));

  useEffect(() => {
    setForm(state.dietProfile);
    setServingsScale(state.dietProfile.householdSize || 1);
    setDayCalorieTarget(state.dietProfile.calorieTarget || 1800);
    setShowQuestionnaire(!state.currentDietPlan);
    setDidAutoOpenPlan(Boolean(state.currentDietPlan));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.user.id]);

  useEffect(() => {
    if (!didAutoOpenPlan && state.currentDietPlan) {
      setShowQuestionnaire(false);
      setDidAutoOpenPlan(true);
    }
  }, [didAutoOpenPlan, state.currentDietPlan]);

  const toggleArr = <T extends string>(arr: T[], val: T): T[] =>
    arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val];

  const addTag = (field: 'lovedFoods' | 'dislikedIngredients' | 'avoidedVegetables' | 'neverRecommend' | 'customAllergies' | 'cuisines', val: string, clear: () => void) => {
    const parts = val.split(',').map((s) => s.trim()).filter(Boolean);
    if (parts.length === 0) {
      showToast('Type an item first before clicking Add.');
      return;
    }
    const existingLower = new Set(form[field].map((x) => x.toLowerCase()));
    const added: string[] = [];
    const next = [...form[field]];
    parts.forEach((p) => {
      if (!existingLower.has(p.toLowerCase())) {
        existingLower.add(p.toLowerCase());
        next.push(p);
        added.push(p);
      }
    });
    if (added.length > 0) {
      setForm({ ...form, [field]: next });
      showToast(`Added "${added.join(', ')}"!`);
    } else {
      showToast(`"${parts.join(', ')}" is already added.`);
    }
    clear();
  };

  const removeTag = (field: 'lovedFoods' | 'dislikedIngredients' | 'avoidedVegetables' | 'neverRecommend' | 'customAllergies' | 'cuisines', val: string) => {
    setForm({ ...form, [field]: form[field].filter((x) => x !== val) });
  };

  const handleSaveAndGenerate = async () => {
    const foodsToUse = commitPendingFoodInput();
    const safeTarget = dayCalorieTarget > 0 ? Math.min(5000, Math.max(600, Number(dayCalorieTarget))) : form.calorieTarget;
    const nextProfile: DietPlannerProfile = {
      ...form,
      ...(safeTarget ? { calorieTarget: safeTarget } : {}),
    };
    setForm(nextProfile);
    updateDietProfile(nextProfile);
    setLoadingPlan(true);
    setErrorMsg(null);
    try {
      const data = await postJson<{ plan?: GeneratedDietPlan }>('/api/ai/diet-plan', {
        profile: nextProfile,
        pantryNames: state.pantry.map((p) => p.name),
        language: state.user.language,
        ...(safeTarget ? { calorieTarget: safeTarget } : {}),
        ...(foodsToUse.length > 0 ? { availableFoods: foodsToUse } : {}),
        strictFoodsOnly,
        cuisineRegion: builderRegion,
        portionPreference: portionPref,
      });
      if (data.plan) {
        const plan = data.plan as GeneratedDietPlan;
        [plan.breakfast, plan.morningSnack, plan.lunch, plan.eveningSnack, plan.dinner, plan.optionalDessert].forEach((r) => {
          if (r) addCustomRecipe(r);
        });
        setWeeklyDietDays(null);
        setDietPlan(plan);
        setShowQuestionnaire(false);
        showToast('Personalized diet plan generated!');
        scrollToPlan();
      }
    } catch {
      buildCalorieFoodLocalPlan(foodsToUse, safeTarget || 1800, nextProfile, true);
    } finally {
      setLoadingPlan(false);
    }
  };

  const handleBuildLocalPlan = () => {
    const foodsToUse = commitPendingFoodInput();
    const safeTarget = Math.min(5000, Math.max(600, Number(dayCalorieTarget) || form.calorieTarget || 1800));
    const nextProfile: DietPlannerProfile = { ...form, calorieTarget: safeTarget };
    setForm(nextProfile);
    updateDietProfile(nextProfile);
    buildCalorieFoodLocalPlan(foodsToUse, safeTarget, nextProfile, false);
  };

  const QUICK_DAY_FOODS = [
    'Bread',
    'Eggs',
    'Rice',
    'Oats',
    'Butter',
    'Milk',
    'Banana',
    'Rajma',
    'Paneer',
    'Chicken',
    'Mutton / Meat',
    'Potatoes',
    'Onions',
    'Tomatoes',
    'Toor Dal',
    'Poha',
    'Curd / Yogurt',
    'Spinach',
    'Chickpeas',
    'Roti / Atta',
  ];

  const parseFoodTokens = (raw: string): string[] =>
    raw
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

  const commitPendingFoodInput = (): string[] => {
    const extra = parseFoodTokens(availableFoodInput);
    if (extra.length === 0) return availableFoods;
    const lower = new Set(availableFoods.map((x) => x.toLowerCase()));
    const next = [...availableFoods];
    extra.forEach((p) => {
      if (!lower.has(p.toLowerCase())) {
        lower.add(p.toLowerCase());
        next.push(p);
      }
    });
    setAvailableFoods(next);
    setAvailableFoodInput('');
    return next;
  };

  const addAvailableFoodsFromText = (raw: string) => {
    const parts = parseFoodTokens(raw);
    if (parts.length === 0) {
      showToast('Type food names first (e.g. brown bread, peanut butter).');
      foodInputRef.current?.focus();
      return;
    }
    const lower = new Set(availableFoods.map((x) => x.toLowerCase()));
    const added: string[] = [];
    const next = [...availableFoods];
    parts.forEach((p) => {
      if (!lower.has(p.toLowerCase())) {
        lower.add(p.toLowerCase());
        next.push(p);
        added.push(p);
      }
    });
    setAvailableFoods(next);
    setAvailableFoodInput('');
    if (added.length > 0) {
      showToast(`Added ${added.join(', ')} to your kitchen foods.`);
    } else {
      showToast(`${parts.join(', ')} already selected.`);
    }
  };

  const toggleAvailableFood = (name: string) => {
    const exists = availableFoods.some((f) => f.toLowerCase() === name.toLowerCase());
    setAvailableFoods((prev) =>
      exists ? prev.filter((f) => f.toLowerCase() !== name.toLowerCase()) : [...prev, name]
    );
  };

  const getMatchedFoodsForRecipe = (recipe: Recipe, foodList: string[]): string[] => {
    if (foodList.length === 0) return [];
    const foodsLower = foodList.map((f) => f.toLowerCase());
    const matched: string[] = [];
    recipe.ingredients.forEach((ing) => {
      const ingL = ing.name.toLowerCase();
      const hit = foodsLower.some((f) => {
        const cleanF = f.replace(/\(.*?\)/g, '').split('/')[0].trim();
        return (
          ingL.includes(f) ||
          f.includes(ingL) ||
          (cleanF.length >= 3 && ingL.includes(cleanF)) ||
          (f.includes('bread') && (ingL.includes('bread') || ingL.includes('toast') || ingL.includes('sourdough') || ingL.includes('kulcha'))) ||
          (f.includes('meat') && (ingL.includes('mutton') || ingL.includes('chicken') || ingL.includes('meat'))) ||
          (f.includes('curd') && ingL.includes('yogurt')) ||
          (f.includes('roti') && (ingL.includes('atta') || ingL.includes('roti') || ingL.includes('phulka')))
        );
      });
      if (hit) matched.push(ing.name);
    });
    return matched;
  };

  const scaleRecipePortion = (recipe: Recipe, ratio: number): Recipe => {
    if (Math.abs(ratio - 1) < 0.08) return recipe;
    const label =
      ratio <= 0.58
        ? 'Small Portion'
        : ratio <= 0.85
        ? 'Light Portion'
        : 'Extra Portion';
    return {
      ...recipe,
      id: `${recipe.id}-portion-${Math.round(ratio * 100)}`,
      title: recipe.title.includes('Small Portion') || recipe.title.includes('Light Portion')
        ? recipe.title
        : `${recipe.title} (${label})`,
      estimatedCostINR: Math.max(15, Math.round(recipe.estimatedCostINR * ratio)),
      nutrition: {
        calories: Math.max(60, Math.round(recipe.nutrition.calories * ratio)),
        protein: Math.max(1, Math.round(recipe.nutrition.protein * ratio)),
        carbs: Math.max(1, Math.round(recipe.nutrition.carbs * ratio)),
        fat: Math.max(1, Math.round(recipe.nutrition.fat * ratio)),
      },
      ingredients: recipe.ingredients.map((ing) => ({
        ...ing,
        quantity: Number(Math.max(0.25, ing.quantity * ratio).toFixed(1)),
      })),
    };
  };

  const buildCustomMealsFromEnteredFoods = (
    foodsToUse: string[],
    activeProfile: DietPlannerProfile,
    targetCalories: number
  ): Partial<Record<'Breakfast' | 'Snack' | 'Lunch' | 'Dinner', Recipe>> => {
    if (foodsToUse.length === 0) return {};
    const has = (kw: string) => foodsToUse.some((f) => f.toLowerCase().includes(kw));
    const wantsZeroSugar = activeProfile.dietaryPreferences.includes('Zero sugar');
    const wantsLowOil = activeProfile.dietaryPreferences.includes('Low oil');
    const wantsLessFat = activeProfile.dietaryPreferences.includes('Less fat');
    const cleanTags = [
      ...(wantsZeroSugar ? ['Zero sugar'] : []),
      ...(wantsLowOil ? ['Low oil'] : []),
      ...(wantsLessFat ? ['Less fat'] : []),
      ...(targetCalories <= 1450 || portionPref === 'small' ? ['Small Portion'] : []),
    ];

    const out: Partial<Record<'Breakfast' | 'Snack' | 'Lunch' | 'Dinner', Recipe>> = {};
    const imgBread = '/src/assets/images/meal_breakfast_bowl_1795377617419.jpg';
    const imgIndian = '/src/assets/images/meal_dinner_indian_1795377616543.jpg';

    if (has('bread') && has('peanut')) {
      const sliceCount = targetCalories <= 1400 || portionPref === 'small' ? 1 : 2;
      const pbTsp = wantsLessFat || targetCalories <= 1400 ? 1 : 2;
      out.Breakfast = {
        id: `user-food-bread-pb-${Date.now().toString().slice(-4)}`,
        title: `${sliceCount === 1 ? 'Single-Slice ' : ''}Toasted Brown Bread & ${wantsZeroSugar ? 'Unsweetened ' : ''}Peanut Butter`,
        cuisine: 'Continental',
        dietType: 'Vegan',
        prepTimeMins: 5,
        difficulty: 'Easy',
        servings: 1,
        estimatedCostINR: 35,
        image: imgBread,
        description: `Clean ${wantsZeroSugar ? 'zero-sugar, ' : ''}${wantsLowOil ? 'oil-free dry-toasted ' : ''}${sliceCount === 1 ? 'small portion of ' : ''}brown bread spread lightly with natural peanut butter.`,
        mealSlot: 'Breakfast',
        allergens: [],
        tags: ['Quick', 'Plant-based', ...cleanTags],
        nutrition: {
          calories: sliceCount === 1 ? (pbTsp === 1 ? 165 : 210) : 275,
          protein: sliceCount === 1 ? 8 : 11,
          carbs: sliceCount === 1 ? 18 : 30,
          fat: pbTsp === 1 ? 6 : 11,
        },
        ingredients: [
          { name: has('brown bread') ? 'Brown Bread' : 'Whole Wheat Bread', quantity: sliceCount, unit: sliceCount === 1 ? 'slice' : 'slices', category: 'Bakery' },
          { name: wantsZeroSugar ? 'Unsweetened Peanut Butter' : 'Peanut Butter', quantity: pbTsp, unit: 'tsp', category: 'Grains' },
        ],
        instructions: [
          `Dry-toast ${sliceCount} slice(s) of brown bread on a tawa or toaster with zero butter or oil.`,
          `Spread ${pbTsp} tsp of natural ${wantsZeroSugar ? 'zero-sugar ' : ''}peanut butter evenly while warm.`,
          has('banana') ? 'Top with thin banana slices and a pinch of cinnamon.' : 'Serve warm with black coffee or unsweetened green tea.',
        ],
      };
    }

    if (foodsToUse.length > 0 && (!out.Breakfast || strictFoodsOnly)) {
      const primaryFoods = foodsToUse.slice(0, 4);
      const smallRatio = targetCalories <= 1400 || portionPref === 'small';
      const customSnack: Recipe = {
        id: `user-food-snack-${Date.now().toString().slice(-4)}`,
        title: `${smallRatio ? 'Light ' : ''}${primaryFoods.slice(0, 2).join(' & ')} Portion`,
        cuisine: builderRegion === 'national' ? 'Indian' : 'Continental',
        dietType: 'Vegetarian',
        prepTimeMins: 8,
        difficulty: 'Easy',
        servings: 1,
        estimatedCostINR: 40,
        image: builderRegion === 'national' ? imgIndian : imgBread,
        description: `Simple ${smallRatio ? 'small-portion ' : ''}snack made from your entered kitchen foods (${primaryFoods.join(', ')}), prepared ${wantsLowOil ? 'with minimal or zero oil' : 'fresh'}${wantsZeroSugar ? ' and zero added sugar' : ''}.`,
        mealSlot: 'Snack',
        allergens: [],
        tags: ['Quick', ...cleanTags],
        nutrition: {
          calories: smallRatio ? 155 : 220,
          protein: 7,
          carbs: 20,
          fat: wantsLessFat ? 4 : 7,
        },
        ingredients: primaryFoods.map((f) => ({
          name: f,
          quantity: smallRatio ? 0.5 : 1,
          unit: f.toLowerCase().includes('bread') ? 'slice' : 'portion',
          category: 'Grains',
        })),
        instructions: [
          `Measure a ${smallRatio ? 'light small portion' : 'regular serving'} of ${primaryFoods.join(', ')}.`,
          wantsLowOil
            ? 'Dry-roast, steam, or serve fresh without extra oil, butter, or sugar.'
            : 'Prepare lightly seasoned with black pepper, cumin, or herbs.',
        ],
      };
      out.Snack = customSnack;
    }

    return out;
  };

  const createCalorieFoodDayPlan = (
    foodsToUse: string[],
    safeTarget: number,
    activeProfile: DietPlannerProfile,
    daySeed = 0
  ): { plan: GeneratedDietPlan; createdRecipes: Recipe[]; totalCal: number } => {
    const enteredNutFood = foodsToUse.some((f) => /peanut|almond|walnut|cashew|nut/i.test(f));
    const allergies = [...activeProfile.allergies, ...activeProfile.customAllergies]
      .map((a) => a.toLowerCase())
      .filter((a) => !(enteredNutFood && a.includes('nut')));
    const dislikes = [...activeProfile.dislikedIngredients, ...activeProfile.neverRecommend].map((d) => d.toLowerCase());
    const prefs = activeProfile.foodPreferences;
    const vegOnly = prefs.length > 0 && prefs.every((p) => p === 'Vegetarian' || p === 'Vegan');
    const veganOnly = prefs.length > 0 && prefs.every((p) => p === 'Vegan');
    const wantsZeroSugar = activeProfile.dietaryPreferences.includes('Zero sugar');
    const wantsLowOil = activeProfile.dietaryPreferences.includes('Low oil');
    const wantsLessFat = activeProfile.dietaryPreferences.includes('Less fat');

    const safePool = allRecipes.filter((r) => {
      if (r.allergens.some((a) => allergies.includes(a.toLowerCase()))) return false;
      if (dislikes.some((d) => r.title.toLowerCase().includes(d) || r.ingredients.some((i) => i.name.toLowerCase().includes(d)))) {
        return false;
      }
      if (veganOnly && r.dietType !== 'Vegan') return false;
      if (vegOnly && !['Vegetarian', 'Vegan'].includes(r.dietType)) return false;
      if (builderRegion === 'national' && !isNationalIndianCuisine(r.cuisine)) return false;
      if (builderRegion === 'international' && isNationalIndianCuisine(r.cuisine)) return false;
      return true;
    });

    const pool = safePool.length >= 5 ? safePool : allRecipes;
    const preferSmallPortions = portionPref === 'small' || safeTarget <= 1500;
    const customUserMeals = buildCustomMealsFromEnteredFoods(foodsToUse, activeProfile, safeTarget);

    const cleanScoreForRecipe = (r: Recipe) => {
      let s = 0;
      if (wantsZeroSugar) {
        if (r.tags.includes('Zero sugar')) s += 8;
        if (r.mealSlot === 'Dessert' || /sweet|honey|sugar|jam/i.test(r.title + r.description)) s -= 10;
      }
      if (wantsLowOil) {
        if (r.tags.includes('Low oil')) s += 8;
        if (/fried|butter|paratha|biryani/i.test(r.title)) s -= 4;
      }
      if (wantsLessFat) {
        if (r.tags.includes('Less fat')) s += 8;
        if (r.nutrition.fat <= 8) s += 6;
        else if (r.nutrition.fat >= 18) s -= 6;
      }
      return s;
    };

    const rankForSlot = (slotName: string, slotCalBudget: number) => {
      const slotItems = pool.filter((r) => r.mealSlot === slotName);
      const candidates = slotItems.length >= 3 ? slotItems : pool;
      return [...candidates]
        .sort((a, b) => {
          const aMatches = getMatchedFoodsForRecipe(a, foodsToUse).length;
          const bMatches = getMatchedFoodsForRecipe(b, foodsToUse).length;
          const aSmallBonus = preferSmallPortions && (a.tags.includes('Small Portion') || a.nutrition.calories <= 280) ? 3 : 0;
          const bSmallBonus = preferSmallPortions && (b.tags.includes('Small Portion') || b.nutrition.calories <= 280) ? 3 : 0;
          const aMissingPenalty = strictFoodsOnly ? Math.max(0, a.ingredients.length - aMatches) * 2 : 0;
          const bMissingPenalty = strictFoodsOnly ? Math.max(0, b.ingredients.length - bMatches) * 2 : 0;
          const aScore = aMatches * 7 + aSmallBonus + cleanScoreForRecipe(a) - aMissingPenalty - Math.abs(a.nutrition.calories - slotCalBudget) / 100;
          const bScore = bMatches * 7 + bSmallBonus + cleanScoreForRecipe(b) - bMissingPenalty - Math.abs(b.nutrition.calories - slotCalBudget) / 100;
          return bScore - aScore;
        })
        .slice(0, 8);
    };

    const bRanked = customUserMeals.Breakfast
      ? [customUserMeals.Breakfast, ...rankForSlot('Breakfast', safeTarget * 0.22)]
      : rankForSlot('Breakfast', safeTarget * 0.25);
    const msRanked = customUserMeals.Snack
      ? [customUserMeals.Snack, ...rankForSlot('Snack', safeTarget * 0.12)]
      : rankForSlot('Snack', safeTarget * 0.12);
    const lRanked = rankForSlot('Lunch', safeTarget * 0.30);
    const esRanked = rankForSlot('Snack', safeTarget * 0.12);
    const dRanked = rankForSlot('Dinner', safeTarget * 0.24);

    // Build all candidate combos and pick ranked #1 for day 0, rotating top combos for 7-day variety
    const combos: { b: Recipe; ms: Recipe; l: Recipe; es: Recipe; d: Recipe; score: number }[] = [];
    for (const b of bRanked.slice(0, 4)) {
      for (const l of lRanked.slice(0, 4)) {
        if (l.id === b.id) continue;
        for (const d of dRanked.slice(0, 4)) {
          if (d.id === b.id || d.id === l.id) continue;
          const ms = msRanked.find((x) => x.id !== b.id && x.id !== l.id && x.id !== d.id) || msRanked[0];
          const es = esRanked.find((x) => x.id !== b.id && x.id !== l.id && x.id !== d.id && x.id !== ms.id) || esRanked[0];
          const rawTotalCal =
            b.nutrition.calories + ms.nutrition.calories + l.nutrition.calories + es.nutrition.calories + d.nutrition.calories;
          const totalMatches =
            getMatchedFoodsForRecipe(b, foodsToUse).length +
            getMatchedFoodsForRecipe(ms, foodsToUse).length +
            getMatchedFoodsForRecipe(l, foodsToUse).length +
            getMatchedFoodsForRecipe(es, foodsToUse).length +
            getMatchedFoodsForRecipe(d, foodsToUse).length;
          const cleanBonus =
            cleanScoreForRecipe(b) + cleanScoreForRecipe(ms) + cleanScoreForRecipe(l) + cleanScoreForRecipe(es) + cleanScoreForRecipe(d);
          const scaledDeviation =
            portionPref === 'regular'
              ? Math.abs(rawTotalCal - safeTarget) / 30
              : Math.abs(rawTotalCal - safeTarget) / 160;
          const comboScore = totalMatches * 8 + cleanBonus - scaledDeviation;
          combos.push({ b, ms, l, es, d, score: comboScore });
        }
      }
    }
    combos.sort((x, y) => y.score - x.score);

    const picked =
      combos.length > 0
        ? combos[(daySeed * 3) % Math.min(combos.length, 14)]
        : {
            b: bRanked[daySeed % bRanked.length] || bRanked[0],
            ms: msRanked[daySeed % msRanked.length] || msRanked[0],
            l: lRanked[daySeed % lRanked.length] || lRanked[0],
            es: esRanked[(daySeed + 1) % esRanked.length] || msRanked[0],
            d: dRanked[daySeed % dRanked.length] || dRanked[0],
          };

    const rawSum =
      picked.b.nutrition.calories +
      picked.ms.nutrition.calories +
      picked.l.nutrition.calories +
      picked.es.nutrition.calories +
      picked.d.nutrition.calories;

    let ratio = 1;
    if (portionPref === 'small') {
      ratio = Math.min(0.85, Math.max(0.45, safeTarget / Math.max(1, rawSum)));
    } else if (portionPref === 'auto' && Math.abs(rawSum - safeTarget) > safeTarget * 0.08) {
      ratio = Math.min(1.4, Math.max(0.45, safeTarget / Math.max(1, rawSum)));
    }

    const applyCleanStyle = (rec: Recipe) => {
      const scaled = rec.id.startsWith('user-food-') && Math.abs(ratio - 1) < 0.25 ? rec : scaleRecipePortion(rec, ratio);
      if (!wantsZeroSugar && !wantsLowOil && !wantsLessFat) return scaled;
      return {
        ...scaled,
        nutrition: {
          ...scaled.nutrition,
          fat: wantsLessFat ? Math.max(2, Math.round(scaled.nutrition.fat * 0.72)) : scaled.nutrition.fat,
        },
        tags: Array.from(
          new Set([
            ...scaled.tags,
            ...(wantsZeroSugar ? ['Zero sugar'] : []),
            ...(wantsLowOil ? ['Low oil'] : []),
            ...(wantsLessFat ? ['Less fat'] : []),
          ])
        ),
      };
    };

    const bFinal = applyCleanStyle(picked.b);
    const msFinal = applyCleanStyle(picked.ms);
    const lFinal = applyCleanStyle(picked.l);
    const esFinal = applyCleanStyle(picked.es);
    const dFinal = applyCleanStyle(picked.d);

    const totalCal =
      bFinal.nutrition.calories +
      msFinal.nutrition.calories +
      lFinal.nutrition.calories +
      esFinal.nutrition.calories +
      dFinal.nutrition.calories;

    const cleanRulesLabel = [
      wantsZeroSugar ? 'Zero Sugar' : '',
      wantsLowOil ? 'Low Oil' : '',
      wantsLessFat ? 'Less Fat' : '',
    ]
      .filter(Boolean)
      .join(' · ');

    const portionNote = ratio < 0.88 ? ' with small portion sizing' : ratio > 1.12 ? ' with hearty portions' : '';
    const foodSummary = foodsToUse.length > 0 ? ` using your foods (${foodsToUse.slice(0, 6).join(', ')})` : '';
    const dayPrefix = daySeed > 0 ? `${WEEK_DAYS[daySeed % 7]} ` : '1-Day ';
    const createdRecipes = [bFinal, msFinal, lFinal, esFinal, dFinal];
    const planObj: GeneratedDietPlan = {
      id: `cal-plan-${Date.now()}-${daySeed}`,
      generatedAt: new Date().toISOString(),
      summary: `${dayPrefix}${safeTarget} kcal plan (${totalCal} kcal planned${portionNote})${cleanRulesLabel ? ` · ${cleanRulesLabel}` : ''}${foodSummary}.`,
      breakfast: bFinal,
      morningSnack: msFinal,
      lunch: lFinal,
      eveningSnack: esFinal,
      dinner: dFinal,
    };
    return { plan: planObj, createdRecipes, totalCal };
  };

  const buildCalorieFoodLocalPlan = (
    foodsToUse: string[],
    safeTarget: number,
    activeProfile: DietPlannerProfile,
    fromAIFallback = false
  ) => {
    setErrorMsg(null);
    const { plan: localPlan, createdRecipes, totalCal } = createCalorieFoodDayPlan(foodsToUse, safeTarget, activeProfile, 0);
    createdRecipes.forEach((rec) => addCustomRecipe(rec));
    setWeeklyDietDays(null);
    setDietPlan(localPlan);
    setShowQuestionnaire(false);
    showToast(
      fromAIFallback
        ? `Built your ${totalCal} kcal plan instantly using your kitchen inputs!`
        : `Built 1-day diet (${totalCal} kcal for ${safeTarget} kcal target)!`
    );
    scrollToPlan();
  };

  const handleBuild7DayWeeklyDietPlan = () => {
    const foodsToUse = commitPendingFoodInput();
    const safeTarget = Math.min(5000, Math.max(600, Number(dayCalorieTarget) || 1200));
    setDayCalorieTarget(safeTarget);
    const nextProfile: DietPlannerProfile = { ...form, calorieTarget: safeTarget };
    setForm(nextProfile);
    updateDietProfile(nextProfile);
    setErrorMsg(null);

    const byDay: Record<string, GeneratedDietPlan> = {};
    const allCreated: Recipe[] = [];
    const weeklySlots = WEEK_DAYS.map((dayName, idx) => {
      const { plan: dayPlan, createdRecipes } = createCalorieFoodDayPlan(foodsToUse, safeTarget, nextProfile, idx);
      dayPlan.summary = dayPlan.summary.replace(/^1-Day /, `${dayName} · `);
      byDay[dayName] = dayPlan;
      allCreated.push(...createdRecipes);
      return {
        day: dayName,
        breakfastId: dayPlan.breakfast.id,
        lunchId: dayPlan.lunch.id,
        dinnerId: dayPlan.dinner.id,
        snackId: dayPlan.morningSnack.id,
      };
    });

    setWeeklyPlanBulk(weeklySlots, allCreated);
    setWeeklyDietDays(byDay);
    setActiveWeekDay('Monday');
    setDietPlan(byDay.Monday);
    setShowQuestionnaire(false);
    showToast(`Built full 7-day diet plan (~${safeTarget} kcal/day) and synced to Weekly Meal Planner!`);
    scrollToPlan();
  };

  const handleBuildCalorieFoodAIPlan = async () => {
    const foodsToUse = commitPendingFoodInput();
    const safeTarget = Math.min(5000, Math.max(600, Number(dayCalorieTarget) || 1200));
    setDayCalorieTarget(safeTarget);
    const nextProfile: DietPlannerProfile = { ...form, calorieTarget: safeTarget };
    setForm(nextProfile);
    updateDietProfile(nextProfile);
    setLoadingCalPlan(true);
    setErrorMsg(null);

    try {
      const data = await postJson<{ plan?: GeneratedDietPlan }>('/api/ai/diet-plan', {
        profile: nextProfile,
        pantryNames: state.pantry.map((p) => p.name),
        language: state.user.language,
        calorieTarget: safeTarget,
        availableFoods: foodsToUse,
        strictFoodsOnly,
        cuisineRegion: builderRegion,
        portionPreference: portionPref,
      });
      if (data.plan) {
        const generated = data.plan as GeneratedDietPlan;
        [generated.breakfast, generated.morningSnack, generated.lunch, generated.eveningSnack, generated.dinner, generated.optionalDessert].forEach((r) => {
          if (r) addCustomRecipe(r);
        });
        setWeeklyDietDays(null);
        setDietPlan(generated);
        setShowQuestionnaire(false);
        const sumCal = [generated.breakfast, generated.morningSnack, generated.lunch, generated.eveningSnack, generated.dinner]
          .filter(Boolean)
          .reduce((s, r) => s + (r?.nutrition.calories || 0), 0);
        showToast(`Built 1-day plan (${sumCal} kcal vs ${safeTarget} kcal target) using your foods!`);
        scrollToPlan();
      }
    } catch {
      buildCalorieFoodLocalPlan(foodsToUse, safeTarget, nextProfile, true);
    } finally {
      setLoadingCalPlan(false);
    }
  };

  const handleBuildCalorieFoodLocalPlan = () => {
    const foodsToUse = commitPendingFoodInput();
    const safeTarget = Math.min(5000, Math.max(600, Number(dayCalorieTarget) || 1200));
    setDayCalorieTarget(safeTarget);
    const nextProfile: DietPlannerProfile = { ...form, calorieTarget: safeTarget };
    setForm(nextProfile);
    updateDietProfile(nextProfile);
    buildCalorieFoodLocalPlan(foodsToUse, safeTarget, nextProfile, false);
  };

  const handleReplaceMeal = async (slotKey: 'breakfast' | 'morningSnack' | 'lunch' | 'eveningSnack' | 'dinner' | 'optionalDessert', label: string) => {
    if (!state.currentDietPlan) return;
    const foodsToUse = commitPendingFoodInput();
    setReplacingSlot(slotKey);
    setErrorMsg(null);
    try {
      const data = await postJson<{ meal?: Recipe }>('/api/ai/diet-plan', {
        profile: form,
        pantryNames: state.pantry.map((p) => p.name),
        language: state.user.language,
        replaceSlot: label,
        calorieTarget: dayCalorieTarget,
        availableFoods: foodsToUse,
      });
      if (data.meal) {
        const meal = data.meal as Recipe;
        addCustomRecipe(meal);
        setDietPlan({ ...state.currentDietPlan, [slotKey]: meal });
        showToast(`Replaced ${label} with "${meal.title}".`);
      }
    } catch {
      const currentId = state.currentDietPlan[slotKey]?.id;
      const slotTarget =
        slotKey === 'breakfast'
          ? 'Breakfast'
          : slotKey === 'lunch'
          ? 'Lunch'
          : slotKey === 'dinner'
          ? 'Dinner'
          : 'Snack';
      const fallback =
        allRecipes.find((r) => r.id !== currentId && r.mealSlot === slotTarget) ||
        allRecipes.find((r) => r.id !== currentId) ||
        allRecipes[0];
      if (fallback) {
        setDietPlan({ ...state.currentDietPlan, [slotKey]: fallback });
        showToast(`Swapped ${label} to "${fallback.title}".`);
      }
    } finally {
      setReplacingSlot(null);
    }
  };

  const plan = state.currentDietPlan;
  const planMeals = useMemo(() => {
    const raw: { key: 'breakfast' | 'morningSnack' | 'lunch' | 'eveningSnack' | 'dinner' | 'optionalDessert'; label: string; slotGroup: 'Breakfast' | 'Snack' | 'Lunch' | 'Dinner' | 'Dessert'; recipe?: Recipe }[] = plan
      ? [
          { key: 'breakfast', label: 'Breakfast', slotGroup: 'Breakfast', recipe: plan.breakfast },
          { key: 'morningSnack', label: 'Morning Snack', slotGroup: 'Snack', recipe: plan.morningSnack },
          { key: 'lunch', label: 'Lunch', slotGroup: 'Lunch', recipe: plan.lunch },
          { key: 'eveningSnack', label: 'Evening Snack', slotGroup: 'Snack', recipe: plan.eveningSnack },
          { key: 'dinner', label: 'Dinner', slotGroup: 'Dinner', recipe: plan.dinner },
          ...(plan.optionalDessert ? [{ key: 'optionalDessert' as const, label: 'Optional Dessert', slotGroup: 'Dessert' as const, recipe: plan.optionalDessert }] : []),
        ]
      : [];
    return raw.filter((item): item is typeof item & { recipe: Recipe } => Boolean(item.recipe));
  }, [plan]);

  const filteredAndSortedPlanMeals = useMemo(() => {
    const q = mealSearch.trim().toLowerCase();
    const list = planMeals.filter(({ label, slotGroup, recipe }) => {
      if (slotFilter !== 'All' && slotGroup !== slotFilter) return false;
      const isNational = isNationalIndianCuisine(recipe.cuisine);
      if (regionFilter === 'national' && !isNational) return false;
      if (regionFilter === 'international' && isNational) return false;
      if (dietQuickFilter === 'quick' && recipe.prepTimeMins > 20) return false;
      if (dietQuickFilter === 'zero-sugar' && !recipe.tags.includes('Zero sugar')) return false;
      if (dietQuickFilter === 'low-oil' && !recipe.tags.includes('Low oil')) return false;
      if (dietQuickFilter === 'less-fat' && !recipe.tags.includes('Less fat') && recipe.nutrition.fat > 10) return false;
      if (dietQuickFilter === 'veg' && !['Vegetarian', 'Vegan'].includes(recipe.dietType)) return false;
      if (dietQuickFilter === 'vegan' && recipe.dietType !== 'Vegan') return false;
      if (dietQuickFilter === 'high-protein' && recipe.nutrition.protein < 18) return false;
      if (dietQuickFilter === 'favorites' && !state.favoriteRecipeIds.includes(recipe.id)) return false;
      if (q) {
        const hay = `${label} ${recipe.title} ${recipe.cuisine} ${recipe.dietType} ${recipe.ingredients.map((i) => i.name).join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    if (sortBy === 'schedule') return list;

    return [...list].sort((a, b) => {
      const ra = a.recipe;
      const rb = b.recipe;
      switch (sortBy) {
        case 'cost-asc':
          return ra.estimatedCostINR - rb.estimatedCostINR;
        case 'cost-desc':
          return rb.estimatedCostINR - ra.estimatedCostINR;
        case 'prep-asc':
          return ra.prepTimeMins - rb.prepTimeMins;
        case 'cal-asc':
          return ra.nutrition.calories - rb.nutrition.calories;
        case 'cal-desc':
          return rb.nutrition.calories - ra.nutrition.calories;
        case 'protein-desc':
          return rb.nutrition.protein - ra.nutrition.protein;
        default:
          return 0;
      }
    });
  }, [planMeals, mealSearch, slotFilter, regionFilter, dietQuickFilter, sortBy, state.favoriteRecipeIds]);

  const nationalPlanMeals = useMemo(
    () => filteredAndSortedPlanMeals.filter((m) => isNationalIndianCuisine(m.recipe.cuisine)),
    [filteredAndSortedPlanMeals]
  );
  const internationalPlanMeals = useMemo(
    () => filteredAndSortedPlanMeals.filter((m) => !isNationalIndianCuisine(m.recipe.cuisine)),
    [filteredAndSortedPlanMeals]
  );

  const regionalLibraryRecipes = useMemo(() => {
    const allergies = [...form.allergies, ...form.customAllergies].map((a) => a.toLowerCase());
    return allRecipes.filter((r) => {
      if (r.allergens.some((a) => allergies.includes(a.toLowerCase()))) return false;
      const isInd = isNationalIndianCuisine(r.cuisine);
      return libraryTab === 'national' ? isInd : !isInd;
    });
  }, [allRecipes, form.allergies, form.customAllergies, libraryTab]);

  const hasActiveMealFilters =
    mealSearch.trim() !== '' ||
    slotFilter !== 'All' ||
    regionFilter !== 'all' ||
    dietQuickFilter !== 'All' ||
    sortBy !== 'schedule';

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#4A7C59] mb-1">MY PERSONAL DIET PLANNER</p>
          <h2 className="font-display text-2xl font-bold text-[#1F2421]">
            Tailored nutrition & meal planning
          </h2>
          <p className="text-sm text-[#5B625C] mt-1">
            Designed around your tastes, strict allergy exclusions, cooking schedule, and food budget.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setShowQuestionnaire(!showQuestionnaire)}
            className="px-4 py-2.5 rounded-xl bg-white border border-[#E6E3DA] text-sm font-medium hover:bg-[#F3F1EA]"
          >
            {showQuestionnaire ? 'View Generated Plan' : 'Edit Preferences'}
          </button>
          <button
            onClick={handleSaveAndGenerate}
            disabled={loadingPlan}
            className="px-4 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] disabled:opacity-60 inline-flex items-center gap-2"
          >
            {loadingPlan ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{loadingPlan ? 'Generating...' : t.generatePlan}</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="bg-[#FDF2EC] border border-[#D97736]/40 text-[#9A4A18] rounded-xl p-4 text-sm flex flex-wrap items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button
            type="button"
            onClick={() => (showCalBuilder ? handleBuildCalorieFoodLocalPlan() : handleBuildLocalPlan())}
            className="px-3.5 py-2 rounded-xl bg-[#D97736] text-white text-xs font-semibold hover:opacity-95 shrink-0"
          >
            Build Instant Local Plan
          </button>
        </div>
      )}

      {/* Quick 1-Day & 7-Day Calorie & Available Food Diet Builder */}
      <section className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden">
        <div className="p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#EFECE3] bg-[#FAF9F5]">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FDF2EC] text-[#D97736] flex items-center justify-center shrink-0">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-[#1F2421]">
                1-Day & 7-Day Diet Builder by Calories & Foods You Have
              </h3>
              <p className="text-xs text-[#5B625C]">
                1. Set daily kcal (e.g. 1200) → 2. Type or tap foods you have → 3. Click <strong className="text-[#1F2421]">Make Diet for Today</strong> or <strong className="text-[#1F2421]">Make 7-Day Weekly Plan</strong>.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowCalBuilder((v) => !v)}
            className="self-start sm:self-auto px-3 py-1.5 rounded-xl bg-white border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] inline-flex items-center gap-1"
          >
            <span>{showCalBuilder ? 'Hide Builder' : 'Open Builder'}</span>
            {showCalBuilder ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {showCalBuilder && (
          <div className="p-5 sm:p-6 space-y-5">
            <div className="grid md:grid-cols-12 gap-5">
              {/* Step 1: Daily Calories */}
              <div className="md:col-span-5 space-y-3">
                <label htmlFor="daily-calorie-builder-input" className="block text-xs font-semibold text-[#1F2421]">
                  1. Target Daily Calories (kcal)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    id="daily-calorie-builder-input"
                    type="number"
                    min={600}
                    max={5000}
                    step={50}
                    value={dayCalorieTarget}
                    onChange={(e) => setDayCalorieTarget(Math.max(0, Number(e.target.value) || 0))}
                    className="w-36 h-11 px-3.5 rounded-xl border border-[#E6E3DA] font-mono text-base font-bold text-[#1F2421] tabular-nums"
                  />
                  <span className="text-xs text-[#5B625C]">kcal / day</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { kcal: 1000, label: '1,000 · Very Light' },
                    { kcal: 1200, label: '1,200 · Light' },
                    { kcal: 1500, label: '1,500 · Cut' },
                    { kcal: 1800, label: '1,800 · Balanced' },
                    { kcal: 2200, label: '2,200 · Active' },
                  ].map((preset) => (
                    <button
                      key={preset.kcal}
                      type="button"
                      onClick={() => setDayCalorieTarget(preset.kcal)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        dayCalorieTarget === preset.kcal
                          ? 'bg-[#D97736] text-white border-[#D97736]'
                          : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-[#5B625C]">
                  Portions automatically scale (e.g. 1 slice toast or half-bowl serving) to match even light 1,000–1,200 kcal days.
                </p>
              </div>

              {/* Step 2: Foods You Have */}
              <div className="md:col-span-7 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label htmlFor="available-foods-input" className="text-xs font-semibold text-[#1F2421]">
                    2. Foods You Have With You Right Now
                  </label>
                  <div className="flex items-center gap-2">
                    {state.pantry.length > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setAvailableFoods(Array.from(new Set(state.pantry.map((p) => p.name))));
                          showToast(`Loaded ${state.pantry.length} foods from your Pantry.`);
                        }}
                        className="text-xs font-semibold text-[#4A7C59] hover:underline"
                      >
                        Load My Pantry ({state.pantry.length})
                      </button>
                    )}
                    {availableFoods.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setAvailableFoods([])}
                        className="text-xs text-[#5B625C] hover:text-[#1F2421] underline"
                      >
                        Clear ({availableFoods.length})
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    ref={foodInputRef}
                    id="available-foods-input"
                    value={availableFoodInput}
                    onChange={(e) => setAvailableFoodInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addAvailableFoodsFromText(availableFoodInput);
                      }
                    }}
                    placeholder="Type foods (e.g. brown bread, peanut butter, eggs)..."
                    className="flex-1 h-11 px-3.5 rounded-xl border border-[#E6E3DA] text-sm"
                  />
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => addAvailableFoodsFromText(availableFoodInput)}
                    className="px-4 h-11 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] active:scale-[0.98] transition-all shrink-0 inline-flex items-center gap-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add</span>
                  </button>
                </div>

                {availableFoods.length > 0 && (
                  <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-2.5 space-y-1.5">
                    <p className="text-[11px] font-semibold text-[#4A7C59]">
                      Your Selected Foods ({availableFoods.length}):
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {availableFoods.map((food) => (
                        <button
                          key={`sel-${food}`}
                          type="button"
                          onClick={() => toggleAvailableFood(food)}
                          className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-[#4A7C59] text-white inline-flex items-center gap-1 hover:bg-[#3D684A]"
                        >
                          <span>{food}</span>
                          <span aria-hidden="true">×</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap gap-1.5">
                  {QUICK_DAY_FOODS.map((food) => {
                    const active = availableFoods.some((f) => f.toLowerCase() === food.toLowerCase());
                    return (
                      <button
                        key={food}
                        type="button"
                        onClick={() => toggleAvailableFood(food)}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border inline-flex items-center gap-1 transition-colors ${
                          active
                            ? 'bg-[#4A7C59] text-white border-[#4A7C59]'
                            : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                        }`}
                      >
                        {active && <Check className="w-3 h-3" />}
                        <span>{food}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Immediate 1-Day & 7-Day Action Strip right after adding foods */}
            <div className="bg-[#FAF9F5] border border-[#E6E3DA] rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-2.5">
              <span className="text-xs font-medium text-[#5B625C]">
                Ready with <strong className="text-[#1F2421]">{dayCalorieTarget} kcal</strong> &{' '}
                <strong className="text-[#1F2421]">{availableFoods.length}</strong> kitchen food{availableFoods.length === 1 ? '' : 's'}:
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleBuildCalorieFoodAIPlan}
                  disabled={loadingCalPlan}
                  className="px-4 py-2 rounded-xl bg-[#4A7C59] text-white text-xs sm:text-sm font-semibold hover:bg-[#3D684A] disabled:opacity-60 inline-flex items-center gap-1.5"
                >
                  {loadingCalPlan ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>{loadingCalPlan ? 'Making Diet...' : `Make Diet Meal for Today (${dayCalorieTarget} kcal)`}</span>
                </button>
                <button
                  type="button"
                  onClick={handleBuild7DayWeeklyDietPlan}
                  className="px-4 py-2 rounded-xl bg-[#D97736] text-white text-xs sm:text-sm font-semibold hover:opacity-95 inline-flex items-center gap-1.5"
                >
                  <CalendarDays className="w-4 h-4" />
                  <span>Make 7-Day Weekly Diet ({dayCalorieTarget} kcal/day)</span>
                </button>
              </div>
            </div>

            {/* Step 3: Clean Cooking & Sugar / Oil / Fat Options */}
            <div className="pt-4 border-t border-[#EFECE3] space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-semibold text-[#1F2421]">
                  3. Diet Rules & Clean Cooking Options (Zero Sugar · Low Oil · Less Fat)
                </span>
                <span className="text-[11px] text-[#5B625C]">
                  Synced with your personal preferences
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {CLEAN_BUILDER_RULES.map((rule) => {
                  const active = form.dietaryPreferences.includes(rule);
                  return (
                    <button
                      key={rule}
                      type="button"
                      onClick={() => {
                        const nextPrefs = toggleArr(form.dietaryPreferences, rule);
                        const nextProfile = { ...form, dietaryPreferences: nextPrefs };
                        setForm(nextProfile);
                        updateDietProfile(nextProfile);
                      }}
                      className={`px-3.5 py-2 rounded-xl text-xs font-semibold border inline-flex items-center gap-1.5 transition-colors ${
                        active
                          ? 'bg-[#1E3A2A] text-white border-[#1E3A2A]'
                          : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                      }`}
                    >
                      {active && <Check className="w-3.5 h-3.5" />}
                      <span>{rule}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-[#EFECE3] flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
                    {([
                      { id: 'all', label: 'All (Indian + Global)' },
                      { id: 'national', label: 'National · Indian' },
                      { id: 'international', label: 'International' },
                    ] as const).map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setBuilderRegion(tab.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                          builderRegion === tab.id ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
                    {([
                      { id: 'auto', label: 'Portions: Auto Fit' },
                      { id: 'small', label: 'Small Portions (0.5x)' },
                      { id: 'regular', label: 'Regular Portions' },
                    ] as const).map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setPortionPref(tab.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                          portionPref === tab.id ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>

                <label className="inline-flex items-center gap-2 text-xs text-[#1F2421] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={strictFoodsOnly}
                    onChange={(e) => setStrictFoodsOnly(e.target.checked)}
                    className="w-4 h-4 accent-[#4A7C59] rounded"
                  />
                  <span>Stick mostly to foods I listed (+ basic spices)</span>
                </label>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={handleBuildCalorieFoodLocalPlan}
                  className="px-4 py-2.5 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-xs sm:text-sm font-semibold hover:bg-[#E7E3D7]"
                >
                  Instant 1-Day Match ({dayCalorieTarget} kcal)
                </button>
                <button
                  type="button"
                  onClick={handleBuild7DayWeeklyDietPlan}
                  className="px-4 py-2.5 rounded-xl bg-[#D97736] text-white text-xs sm:text-sm font-semibold hover:opacity-95 inline-flex items-center gap-1.5"
                >
                  <CalendarDays className="w-4 h-4" />
                  <span>Make 7-Day Weekly Diet</span>
                </button>
                <button
                  type="button"
                  onClick={handleBuildCalorieFoodAIPlan}
                  disabled={loadingCalPlan}
                  className="px-5 py-2.5 rounded-xl bg-[#4A7C59] text-white text-xs sm:text-sm font-semibold hover:bg-[#3D684A] disabled:opacity-60 inline-flex items-center gap-2"
                >
                  {loadingCalPlan ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>{loadingCalPlan ? 'Crafting 1-Day Diet...' : 'Make Diet Meal for Today'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* A-G Onboarding Questionnaire */}
      {showQuestionnaire && (
        <div className="space-y-6 bg-white border border-[#E6E3DA] rounded-2xl p-6 lg:p-8">
          {/* A. Food Preferences */}
          <div>
            <h3 className="font-display text-base font-semibold mb-2">A. Food Preferences</h3>
            <div className="flex flex-wrap gap-2">
              {FOOD_PREFS.map((fp) => {
                const active = form.foodPreferences.includes(fp);
                return (
                  <button
                    key={fp}
                    onClick={() => setForm({ ...form, foodPreferences: toggleArr(form.foodPreferences, fp) })}
                    className={`px-3.5 py-2 rounded-xl text-sm font-medium border ${
                      active ? 'bg-[#4A7C59] text-white border-[#4A7C59]' : 'bg-[#FAF9F5] border-[#E6E3DA]'
                    }`}
                  >
                    {fp}
                  </button>
                );
              })}
            </div>
          </div>

          {/* B. Cuisine Preferences — National (Indian) & International */}
          <div className="pt-5 border-t border-[#EFECE3] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="font-display text-base font-semibold">B. Cuisine Preferences (National & International)</h3>
                <p className="text-xs text-[#5B625C]">
                  Pick Indian home-style cuisines, international flavors, or mix both.
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setForm({ ...form, cuisines: ['Indian', 'North Indian', 'Punjabi'] })}
                  className="px-3 py-1.5 rounded-lg bg-[#FDF2EC] border border-[#D97736]/30 text-xs font-semibold text-[#9A4A18] hover:bg-[#FCE6D8]"
                >
                  National (Indian) Only
                </button>
                <button
                  type="button"
                  onClick={() => setForm({ ...form, cuisines: ['Italian', 'Mediterranean', 'Thai', 'Mexican'] })}
                  className="px-3 py-1.5 rounded-lg bg-[#F3F1EA] border border-[#E6E3DA] text-xs font-semibold text-[#1F2421] hover:bg-[#E7E3D7]"
                >
                  International Only
                </button>
                <button
                  type="button"
                  onClick={() => setForm({ ...form, cuisines: ['Indian', 'Italian', 'Mediterranean', 'Chinese'] })}
                  className="px-3 py-1.5 rounded-lg bg-[#EBF3ED] border border-[#4A7C59]/30 text-xs font-semibold text-[#3D684A] hover:bg-[#DCEBDC]"
                >
                  Both National & International
                </button>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[#FAF9F5] border border-[#EFECE3] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#9A4A18] uppercase tracking-wide">
                    National · Indian Kitchen
                  </span>
                  <span className="text-[11px] text-[#5B625C]">Rajma Chawal, Egg Curry, Biryani, Dal...</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {NATIONAL_CUISINE_PRESETS.map((c) => {
                    const active = form.cuisines.includes(c);
                    return (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setForm({ ...form, cuisines: toggleArr(form.cuisines, c) })}
                        className={`px-3 py-1.5 rounded-xl text-sm border ${
                          active ? 'bg-[#D97736] text-white border-[#D97736]' : 'bg-white border-[#E6E3DA]'
                        }`}
                      >
                        {c}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#FAF9F5] border border-[#EFECE3] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#4A7C59] uppercase tracking-wide">
                    International · Global Kitchens
                  </span>
                  <span className="text-[11px] text-[#5B625C]">13 global traditions</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {INTERNATIONAL_CUISINES.map((c) => {
                    const active = form.cuisines.includes(c);
                    return (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setForm({ ...form, cuisines: toggleArr(form.cuisines, c) })}
                        className={`px-3 py-1.5 rounded-xl text-sm border ${
                          active ? 'bg-[#4A7C59] text-white border-[#4A7C59]' : 'bg-white border-[#E6E3DA]'
                        }`}
                      >
                        {c}
                      </button>
                    );
                  })}
                  {form.cuisines.filter((c) => !ALL_PRESET_CUISINES.includes(c)).map((custom) => (
                    <button
                      key={custom}
                      type="button"
                      onClick={() => removeTag('cuisines', custom)}
                      className="px-3 py-1.5 rounded-xl text-sm bg-[#4A7C59] text-white border border-[#4A7C59]"
                    >
                      {custom} ×
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-2 max-w-sm">
              <input
                value={newCuisine}
                onChange={(e) => setNewCuisine(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag('cuisines', newCuisine, () => setNewCuisine('')))}
                placeholder="Add another Indian regional or global cuisine..."
                className="flex-1 h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
              />
              <button
                type="button"
                onClick={() => addTag('cuisines', newCuisine, () => setNewCuisine(''))}
                className="px-3.5 rounded-xl bg-[#F3F1EA] text-sm font-medium hover:bg-[#E7E3D7]"
              >
                Add
              </button>
            </div>
          </div>

          {/* C. Food Likes and Dislikes */}
          <div className="pt-5 border-t border-[#EFECE3] space-y-4">
            <h3 className="font-display text-base font-semibold">C. Food Likes, Dislikes & Spice Level</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <TagEditor
                label="What foods do you love?"
                items={form.lovedFoods}
                value={newLove}
                onChange={setNewLove}
                onAdd={() => addTag('lovedFoods', newLove, () => setNewLove(''))}
                onRemove={(v) => removeTag('lovedFoods', v)}
                placeholder="e.g. Avocado, Paneer, Sourdough"
              />
              <TagEditor
                label="What ingredients do you dislike?"
                items={form.dislikedIngredients}
                value={newDislike}
                onChange={setNewDislike}
                onAdd={() => addTag('dislikedIngredients', newDislike, () => setNewDislike(''))}
                onRemove={(v) => removeTag('dislikedIngredients', v)}
                placeholder="e.g. Olives, Cilantro"
              />
              <TagEditor
                label="Which vegetables do you avoid?"
                items={form.avoidedVegetables}
                value={newAvoidVeg}
                onChange={setNewAvoidVeg}
                onAdd={() => addTag('avoidedVegetables', newAvoidVeg, () => setNewAvoidVeg(''))}
                onRemove={(v) => removeTag('avoidedVegetables', v)}
                placeholder="e.g. Bitter gourd, Okra"
              />
              <TagEditor
                label="Foods you NEVER want recommended"
                items={form.neverRecommend}
                value={newNever}
                onChange={setNewNever}
                onAdd={() => addTag('neverRecommend', newNever, () => setNewNever(''))}
                onRemove={(v) => removeTag('neverRecommend', v)}
                placeholder="e.g. Mushrooms, Anchovies"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#5B625C] mb-1.5">How spicy do you like your food?</label>
              <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
                {(['Mild', 'Medium', 'Spicy', 'Extra Spicy'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setForm({ ...form, spiceLevel: lvl })}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-medium ${
                      form.spiceLevel === lvl ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C]'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* D. Allergies & Dietary Requirements */}
          <div className="pt-5 border-t border-[#EFECE3] space-y-4">
            <div>
              <h3 className="font-display text-base font-semibold">D. Allergies & Dietary Requirements</h3>
              <p className="text-xs text-[#D97736] mt-0.5">
                Allergies are enforced as strict exclusions across AI meal generation, recipes, and assistant advice.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {ALLERGY_LIST.map((a) => {
                const active = form.allergies.includes(a);
                return (
                  <button
                    key={a}
                    onClick={() => setForm({ ...form, allergies: toggleArr(form.allergies, a) })}
                    className={`px-3 py-1.5 rounded-xl text-sm border ${
                      active ? 'bg-[#D97736] text-white border-[#D97736]' : 'bg-[#FAF9F5] border-[#E6E3DA]'
                    }`}
                  >
                    {a}
                  </button>
                );
              })}
              {form.customAllergies.map((ca) => (
                <button
                  key={ca}
                  onClick={() => removeTag('customAllergies', ca)}
                  className="px-3 py-1.5 rounded-xl text-sm bg-[#D97736] text-white border border-[#D97736]"
                >
                  {ca} ×
                </button>
              ))}
            </div>
            <div className="flex gap-2 max-w-sm">
              <input
                value={newAllergy}
                onChange={(e) => setNewAllergy(e.target.value)}
                placeholder="Other allergy (e.g. Sesame)..."
                className="flex-1 h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
              />
              <button
                onClick={() => addTag('customAllergies', newAllergy, () => setNewAllergy(''))}
                className="px-3.5 rounded-xl bg-[#F3F1EA] text-sm font-medium"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              {DIETARY_PREFS.map((dp) => {
                const active = form.dietaryPreferences.includes(dp);
                return (
                  <button
                    key={dp}
                    onClick={() => setForm({ ...form, dietaryPreferences: toggleArr(form.dietaryPreferences, dp) })}
                    className={`px-3 py-1.5 rounded-xl text-sm border ${
                      active ? 'bg-[#4A7C59] text-white border-[#4A7C59]' : 'bg-[#FAF9F5] border-[#E6E3DA]'
                    }`}
                  >
                    {dp}
                  </button>
                );
              })}
            </div>
          </div>

          {/* E. Personal Goals */}
          <div className="pt-5 border-t border-[#EFECE3] space-y-4">
            <h3 className="font-display text-base font-semibold">E. Personal Wellness & Kitchen Goals</h3>
            <div className="flex flex-wrap gap-2">
              {GOAL_LIST.map((g) => {
                const active = form.goals.includes(g);
                return (
                  <button
                    key={g}
                    onClick={() => setForm({ ...form, goals: toggleArr(form.goals, g) })}
                    className={`px-3 py-1.5 rounded-xl text-sm border ${
                      active ? 'bg-[#4A7C59] text-white border-[#4A7C59]' : 'bg-[#FAF9F5] border-[#E6E3DA]'
                    }`}
                  >
                    {g}
                  </button>
                );
              })}
            </div>
            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1">Age (optional)</label>
                <input
                  type="number"
                  value={form.age || ''}
                  onChange={(e) => setForm({ ...form, age: Number(e.target.value) || undefined })}
                  className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1">Activity Level</label>
                <select
                  value={form.activityLevel || 'Moderate'}
                  onChange={(e) => setForm({ ...form, activityLevel: e.target.value as DietPlannerProfile['activityLevel'] })}
                  className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                >
                  <option value="Sedentary">Sedentary</option>
                  <option value="Light">Light</option>
                  <option value="Moderate">Moderate</option>
                  <option value="Active">Active</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#5B625C] mb-1">Daily Calorie Target (optional)</label>
                <input
                  type="number"
                  value={form.calorieTarget || ''}
                  onChange={(e) => setForm({ ...form, calorieTarget: Number(e.target.value) || undefined })}
                  className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                />
              </div>
            </div>
            <p className="text-xs text-[#5B625C]">
              Note: Kitchly provides general culinary & everyday nutrition suggestions, not medical dietary prescriptions.
            </p>
          </div>

          {/* F. Meal Schedule & G. Budget */}
          <div className="pt-5 border-t border-[#EFECE3] grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="font-display text-base font-semibold">F. Meal Schedule & Cooking</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Meals Daily</label>
                  <input
                    type="number"
                    min={2}
                    max={6}
                    value={form.mealsPerDay}
                    onChange={(e) => setForm({ ...form, mealsPerDay: Math.max(2, Number(e.target.value)) })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">People Eating</label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={form.householdSize}
                    onChange={(e) => setForm({ ...form, householdSize: Math.max(1, Number(e.target.value)) })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Breakfast Time</label>
                  <input
                    type="time"
                    value={form.breakfastTime}
                    onChange={(e) => setForm({ ...form, breakfastTime: e.target.value })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Lunch Time</label>
                  <input
                    type="time"
                    value={form.lunchTime}
                    onChange={(e) => setForm({ ...form, lunchTime: e.target.value })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Dinner Time</label>
                  <input
                    type="time"
                    value={form.dinnerTime}
                    onChange={(e) => setForm({ ...form, dinnerTime: e.target.value })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Max Cook Time (min)</label>
                  <input
                    type="number"
                    min={10}
                    max={180}
                    value={form.maxCookingTimeMins}
                    onChange={(e) => setForm({ ...form, maxCookingTimeMins: Math.max(10, Number(e.target.value)) })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs text-[#5B625C] mb-1">Skill Level</label>
                <select
                  value={form.skillLevel}
                  onChange={(e) => setForm({ ...form, skillLevel: e.target.value as DietPlannerProfile['skillLevel'] })}
                  className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-display text-base font-semibold">G. Budget & Currency</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Currency</label>
                  <select
                    value={state.user.currency}
                    onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
                  >
                    {Object.entries(CURRENCY_RATES).map(([code, meta]) => (
                      <option key={code} value={code}>
                        {meta.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Daily Food Budget (INR base)</label>
                  <input
                    type="number"
                    min={0}
                    value={form.dailyBudget}
                    onChange={(e) => setForm({ ...form, dailyBudget: Math.max(0, Number(e.target.value) || 0) })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Weekly Grocery Budget</label>
                  <input
                    type="number"
                    min={0}
                    value={form.weeklyBudget}
                    onChange={(e) => setForm({ ...form, weeklyBudget: Math.max(0, Number(e.target.value) || 0) })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#5B625C] mb-1">Monthly Grocery Budget</label>
                  <input
                    type="number"
                    min={0}
                    value={form.monthlyBudget}
                    onChange={(e) => setForm({ ...form, monthlyBudget: Math.max(0, Number(e.target.value) || 0) })}
                    className="w-full h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm tabular-nums"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-3 pt-4 border-t border-[#EFECE3]">
            <button
              onClick={() => {
                updateDietProfile(form);
                showToast('Diet preferences saved.');
              }}
              className="px-4 py-2.5 rounded-xl bg-white border border-[#E6E3DA] text-sm font-medium inline-flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>{t.savePreferences}</span>
            </button>
            <button
              type="button"
              onClick={handleBuildLocalPlan}
              className="px-4 py-2.5 rounded-xl bg-[#F3F1EA] text-[#1F2421] text-sm font-semibold hover:bg-[#E7E3D7]"
            >
              Build Instant Local Plan
            </button>
            <button
              onClick={handleSaveAndGenerate}
              disabled={loadingPlan}
              className="px-6 py-2.5 rounded-xl bg-[#4A7C59] text-white text-sm font-semibold hover:bg-[#3D684A] inline-flex items-center gap-2"
            >
              {loadingPlan ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>{t.generatePlan}</span>
            </button>
          </div>
        </div>
      )}

      {/* H. Generated Personalized Diet Plan */}
      {plan && (
        <div ref={planResultRef} className="space-y-5 scroll-mt-20">
          {weeklyDietDays && (
            <div className="bg-white border border-[#E6E3DA] rounded-2xl p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-xs font-semibold text-[#D97736]">7-DAY WEEKLY DIET SCHEDULE (SYNCED TO WEEKLY PLANNER)</p>
                  <p className="text-xs text-[#5B625C]">
                    Switch between Monday–Sunday below to view all 7 days, or open your full Weekly Meal Planner & grocery generator.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setScreen('meal-planner')}
                  className="px-3.5 py-2 rounded-xl bg-[#1E3A2A] text-white text-xs font-semibold hover:bg-[#162C20] shrink-0"
                >
                  Open Full 7-Day Planner & Groceries →
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {WEEK_DAYS.map((dayName) => {
                  const selected = activeWeekDay === dayName;
                  return (
                    <button
                      key={dayName}
                      type="button"
                      onClick={() => {
                        setActiveWeekDay(dayName);
                        if (weeklyDietDays[dayName]) {
                          setDietPlan(weeklyDietDays[dayName]);
                        }
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                        selected
                          ? 'bg-[#D97736] text-white border-[#D97736]'
                          : 'bg-[#FAF9F5] border-[#E6E3DA] text-[#1F2421] hover:bg-[#F3F1EA]'
                      }`}
                    >
                      {dayName.slice(0, 3)}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {(() => {
            const coreMeals = [plan.breakfast, plan.morningSnack, plan.lunch, plan.eveningSnack, plan.dinner].filter(Boolean);
            const totalCal = coreMeals.reduce((s, r) => s + (r?.nutrition.calories || 0), 0);
            const totalProt = coreMeals.reduce((s, r) => s + (r?.nutrition.protein || 0), 0);
            const totalCarbs = coreMeals.reduce((s, r) => s + (r?.nutrition.carbs || 0), 0);
            const totalFat = coreMeals.reduce((s, r) => s + (r?.nutrition.fat || 0), 0);
            const totalCost = coreMeals.reduce((s, r) => s + (r?.estimatedCostINR || 0), 0);
            const target = form.calorieTarget || dayCalorieTarget || 0;
            const diff = target > 0 ? totalCal - target : 0;

            return (
              <div className="bg-[#F3F1EA] border border-[#E6E3DA] rounded-2xl p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-medium text-[#4A7C59] mb-1">Active Personalized Plan</p>
                    <p className="text-sm text-[#1F2421]">{plan.summary}</p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <label className="text-xs font-medium text-[#5B625C] flex items-center gap-2">
                      <span>Servings:</span>
                      <select
                        value={servingsScale}
                        onChange={(e) => setServingsScale(Number(e.target.value))}
                        className="h-9 px-2.5 rounded-lg bg-white border border-[#E6E3DA] text-sm font-mono tabular-nums"
                      >
                        {[1, 2, 3, 4, 5, 6].map((n) => (
                          <option key={n} value={n}>
                            {n}x
                          </option>
                        ))}
                      </select>
                    </label>
                    <button
                      onClick={handleSaveAndGenerate}
                      disabled={loadingPlan}
                      className="px-3.5 py-2 rounded-xl bg-white border border-[#E6E3DA] text-xs font-semibold hover:bg-[#FAF9F5] inline-flex items-center gap-1.5"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${loadingPlan ? 'animate-spin' : ''}`} />
                      <span>{t.regenerate}</span>
                    </button>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#E6E3DA] grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <div>
                    <div className="text-[11px] text-[#5B625C]">Day Calories (per serving)</div>
                    <div className="font-mono text-sm font-bold text-[#1F2421] tabular-nums">
                      {totalCal.toLocaleString()} kcal
                      {target > 0 && (
                        <span className="text-xs font-normal text-[#4A7C59]">
                          {' '}
                          / {target.toLocaleString()} ({diff >= 0 ? `+${diff}` : diff})
                        </span>
                      )}
                    </div>
                    {target > 0 && (
                      <progress
                        value={Math.min(totalCal, target)}
                        max={target}
                        className="mt-1 w-full h-1.5 rounded-full overflow-hidden accent-[#4A7C59]"
                      />
                    )}
                  </div>
                  <div>
                    <div className="text-[11px] text-[#5B625C]">Protein</div>
                    <div className="font-mono text-sm font-bold text-[#1F2421] tabular-nums">{totalProt}g</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-[#5B625C]">Carbs</div>
                    <div className="font-mono text-sm font-bold text-[#1F2421] tabular-nums">{totalCarbs}g</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-[#5B625C]">Fat</div>
                    <div className="font-mono text-sm font-bold text-[#1F2421] tabular-nums">{totalFat}g</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-[#5B625C]">Est. Day Cost</div>
                    <div className="font-mono text-sm font-bold text-[#1F2421] tabular-nums">
                      {formatCurrency(totalCost, state.user.currency)}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Sort & Filter Bar for Diet Plan Meals */}
          <div className="bg-white border border-[#E6E3DA] rounded-2xl p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#EFECE3]">
              <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
                {([
                  { id: 'all', label: `All Regions (${planMeals.length})` },
                  { id: 'national', label: `National · Indian (${planMeals.filter((m) => isNationalIndianCuisine(m.recipe.cuisine)).length})` },
                  { id: 'international', label: `International (${planMeals.filter((m) => !isNationalIndianCuisine(m.recipe.cuisine)).length})` },
                ] as const).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setRegionFilter(tab.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      regionFilter === tab.id ? 'bg-white text-[#1F2421] shadow-sm' : 'text-[#5B625C] hover:text-[#1F2421]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              <span className="text-xs text-[#5B625C]">
                Meals are organized into National (Indian) & International sections below
              </span>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-[#5B625C] absolute left-3 top-3 pointer-events-none" />
                <input
                  type="text"
                  aria-label="Filter planned diet meals"
                  value={mealSearch}
                  onChange={(e) => setMealSearch(e.target.value)}
                  placeholder="Search dish, cuisine, ingredient..."
                  className="w-full h-10 pl-9 pr-3 rounded-xl border border-[#E6E3DA] text-sm"
                />
              </div>

              <select
                aria-label="Filter by meal slot"
                value={slotFilter}
                onChange={(e) => setSlotFilter(e.target.value as typeof slotFilter)}
                className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
              >
                <option value="All">All Meal Slots</option>
                <option value="Breakfast">Breakfast</option>
                <option value="Snack">Snacks</option>
                <option value="Lunch">Lunch</option>
                <option value="Dinner">Dinner</option>
                <option value="Dessert">Dessert</option>
              </select>

              <select
                aria-label="Filter by diet or prep time"
                value={dietQuickFilter}
                onChange={(e) => setDietQuickFilter(e.target.value as typeof dietQuickFilter)}
                className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
              >
                <option value="All">All Diet & Prep Filters</option>
                <option value="zero-sugar">Zero Sugar Only</option>
                <option value="low-oil">Low Oil Only</option>
                <option value="less-fat">Less Fat (≤ 10g)</option>
                <option value="quick">Quick Prep (≤ 20 min)</option>
                <option value="high-protein">High Protein (≥ 18g)</option>
                <option value="veg">Vegetarian & Vegan</option>
                <option value="vegan">Vegan Only</option>
                <option value="favorites">Saved Favorites</option>
              </select>

              <select
                aria-label="Sort diet meals"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm bg-white"
              >
                <option value="schedule">Sort: Meal Schedule Order</option>
                <option value="cost-asc">Sort: Lowest Cost First</option>
                <option value="cost-desc">Sort: Highest Cost First</option>
                <option value="prep-asc">Sort: Quickest Prep Time</option>
                <option value="cal-asc">Sort: Lowest Calories</option>
                <option value="cal-desc">Sort: Highest Calories</option>
                <option value="protein-desc">Sort: Highest Protein</option>
              </select>
            </div>

            <div className="flex items-center justify-between text-xs text-[#5B625C]">
              <span className="inline-flex items-center gap-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#4A7C59]" />
                Showing {filteredAndSortedPlanMeals.length} of {planMeals.length} meals
              </span>
              {hasActiveMealFilters && (
                <button
                  type="button"
                  onClick={() => {
                    setMealSearch('');
                    setSlotFilter('All');
                    setRegionFilter('all');
                    setDietQuickFilter('All');
                    setSortBy('schedule');
                  }}
                  className="font-semibold text-[#4A7C59] hover:underline"
                >
                  Reset Sort & Filters
                </button>
              )}
            </div>
          </div>

          {filteredAndSortedPlanMeals.length === 0 ? (
            <div className="bg-white border border-[#E6E3DA] rounded-2xl p-8 text-center space-y-3">
              <p className="font-display text-base font-semibold text-[#1F2421]">
                No meals in your diet plan match those filters
              </p>
              <button
                type="button"
                onClick={() => {
                  setMealSearch('');
                  setSlotFilter('All');
                  setRegionFilter('all');
                  setDietQuickFilter('All');
                  setSortBy('schedule');
                }}
                className="px-4 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-semibold"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {[
                { title: 'National · Indian Kitchen', accent: 'text-[#9A4A18]', items: nationalPlanMeals },
                { title: 'International · Global Kitchen', accent: 'text-[#4A7C59]', items: internationalPlanMeals },
              ]
                .filter((sec) => sec.items.length > 0)
                .map((sec) => (
                  <div key={sec.title} className="space-y-3">
                    <div className="flex items-center justify-between border-b border-[#EFECE3] pb-2">
                      <h3 className={`font-display text-lg font-bold ${sec.accent}`}>{sec.title}</h3>
                      <span className="text-xs text-[#5B625C] tabular-nums">
                        {sec.items.length} meal{sec.items.length === 1 ? '' : 's'}
                      </span>
                    </div>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
                      {sec.items.map(({ key, label, recipe }) => {
                        const isFav = state.favoriteRecipeIds.includes(recipe.id);
                        const mult = servingsScale / Math.max(1, recipe.servings);
                        const scaledCost = Math.round(recipe.estimatedCostINR * mult);

                        return (
                          <div key={key} className="bg-white border border-[#E6E3DA] rounded-2xl overflow-hidden flex flex-col">
                            <div className="h-44 overflow-hidden">
                              <FoodImage src={recipe.image} alt={recipe.title} className="w-full h-full object-cover" />
                            </div>
                            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                              <div>
                                <p className="text-xs font-medium text-[#4A7C59] mb-1">
                                  {label} · {recipe.cuisine} · {recipe.prepTimeMins} min
                                </p>
                                <h4
                                  onClick={() => openRecipe(recipe)}
                                  className="font-display text-base font-semibold text-[#1F2421] hover:text-[#4A7C59] cursor-pointer mb-2"
                                >
                                  {recipe.title}
                                </h4>
                                <p className="text-xs text-[#5B625C] line-clamp-2 mb-3">{recipe.description}</p>
                                {(() => {
                                  const usedHomeFoods = getMatchedFoodsForRecipe(recipe, availableFoods);
                                  return usedHomeFoods.length > 0 ? (
                                    <p className="text-[11px] font-medium text-[#4A7C59] mb-2.5">
                                      Uses your kitchen foods: {usedHomeFoods.join(', ')}
                                    </p>
                                  ) : null;
                                })()}
                                <div className="grid grid-cols-4 gap-2 py-2 border-y border-[#EFECE3] text-center">
                                  <div>
                                    <div className="font-mono text-xs font-semibold tabular-nums">{recipe.nutrition.calories}</div>
                                    <div className="text-[11px] text-[#5B625C]">kcal</div>
                                  </div>
                                  <div>
                                    <div className="font-mono text-xs font-semibold tabular-nums">{recipe.nutrition.protein}g</div>
                                    <div className="text-[11px] text-[#5B625C]">Protein</div>
                                  </div>
                                  <div>
                                    <div className="font-mono text-xs font-semibold tabular-nums">{recipe.nutrition.carbs}g</div>
                                    <div className="text-[11px] text-[#5B625C]">Carbs</div>
                                  </div>
                                  <div>
                                    <div className="font-mono text-xs font-semibold tabular-nums">{formatCurrency(scaledCost, state.user.currency)}</div>
                                    <div className="text-[11px] text-[#5B625C]">Est. Cost</div>
                                  </div>
                                </div>
                              </div>

                              <div className="flex flex-wrap items-center gap-2">
                                <button
                                  onClick={() => openRecipe(recipe)}
                                  className="flex-1 px-3 py-2 rounded-xl bg-[#4A7C59] text-white text-xs font-medium hover:bg-[#3D684A]"
                                >
                                  Recipe
                                </button>
                                <button
                                  onClick={() => handleReplaceMeal(key, label)}
                                  disabled={replacingSlot === key}
                                  title={t.replaceMeal}
                                  className="px-3 py-2 rounded-xl bg-[#F3F1EA] text-xs font-medium hover:bg-[#E7E3D7] inline-flex items-center gap-1"
                                >
                                  <RefreshCw className={`w-3.5 h-3.5 ${replacingSlot === key ? 'animate-spin' : ''}`} />
                                  <span>Swap</span>
                                </button>
                                <button
                                  onClick={() => toggleFavoriteRecipe(recipe)}
                                  aria-label="Save favorite"
                                  className={`p-2 rounded-xl border ${isFav ? 'bg-[#FDF2EC] border-[#D97736] text-[#D97736]' : 'border-[#E6E3DA] text-[#5B625C]'}`}
                                >
                                  <Star className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    const slotField =
                                      key === 'breakfast'
                                        ? 'breakfastId'
                                        : key === 'lunch'
                                        ? 'lunchId'
                                        : key === 'dinner'
                                        ? 'dinnerId'
                                        : 'snackId';
                                    updateWeeklySlot('Monday', slotField, recipe.id);
                                    showToast(`Added "${recipe.title}" to Monday’s weekly plan.`);
                                  }}
                                  title="Add to Weekly Plan"
                                  className="p-2 rounded-xl border border-[#E6E3DA] text-[#5B625C] hover:text-[#1F2421]"
                                >
                                  <CalendarPlus className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => addRecipeIngredientsToGrocery(recipe, mult)}
                                  title={t.addToGrocery}
                                  className="p-2 rounded-xl border border-[#E6E3DA] text-[#5B625C] hover:text-[#1F2421]"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
            </div>
          )}

          {/* Quick National (Indian) & International Library Swap Browser */}
          <div className="bg-white border border-[#E6E3DA] rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-lg font-bold text-[#1F2421]">
                  Indian (National) & International Recipe Swaps
                </h3>
                <p className="text-xs text-[#5B625C]">
                  Browse National classics (Rajma Chawal, Egg Curry, Mutton Biryani, Dal Tadka) or Global dishes and apply any meal straight to your plan.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="inline-flex bg-[#F3F1EA] p-1 rounded-xl gap-1">
                  <button
                    type="button"
                    onClick={() => setLibraryTab('national')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                      libraryTab === 'national' ? 'bg-white text-[#9A4A18] shadow-sm' : 'text-[#5B625C]'
                    }`}
                  >
                    National · Indian ({allRecipes.filter((r) => isNationalIndianCuisine(r.cuisine)).length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setLibraryTab('international')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                      libraryTab === 'international' ? 'bg-white text-[#4A7C59] shadow-sm' : 'text-[#5B625C]'
                    }`}
                  >
                    International ({allRecipes.filter((r) => !isNationalIndianCuisine(r.cuisine)).length})
                  </button>
                </div>
                <select
                  aria-label="Target meal slot for swap"
                  value={libraryApplySlot}
                  onChange={(e) => setLibraryApplySlot(e.target.value as typeof libraryApplySlot)}
                  className="h-9 px-2.5 rounded-xl border border-[#E6E3DA] text-xs font-medium bg-white"
                >
                  <option value="breakfast">Apply to: Breakfast</option>
                  <option value="morningSnack">Apply to: Morning Snack</option>
                  <option value="lunch">Apply to: Lunch</option>
                  <option value="dinner">Apply to: Dinner</option>
                </select>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {regionalLibraryRecipes.slice(0, 9).map((r) => (
                <div
                  key={r.id}
                  className="border border-[#EFECE3] bg-[#FAF9F5] rounded-xl p-3.5 flex flex-col justify-between gap-3"
                >
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => openRecipe(r)}
                      className="w-16 h-16 rounded-lg overflow-hidden shrink-0"
                    >
                      <FoodImage src={r.image} alt={r.title} className="w-full h-full object-cover" />
                    </button>
                    <div className="min-w-0">
                      <p className="text-[11px] font-medium text-[#4A7C59]">
                        {r.cuisine} · {r.dietType} · {r.prepTimeMins}m
                      </p>
                      <button
                        type="button"
                        onClick={() => openRecipe(r)}
                        className="text-left font-display text-sm font-semibold text-[#1F2421] hover:text-[#4A7C59] line-clamp-2"
                      >
                        {r.title}
                      </button>
                      <p className="text-[11px] text-[#5B625C] tabular-nums mt-0.5">
                        {r.nutrition.calories} kcal · {r.nutrition.protein}g protein · {formatCurrency(r.estimatedCostINR, state.user.currency)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setDietPlan({ ...plan, [libraryApplySlot]: r });
                        const label =
                          libraryApplySlot === 'morningSnack'
                            ? 'Morning Snack'
                            : libraryApplySlot.charAt(0).toUpperCase() + libraryApplySlot.slice(1);
                        showToast(`Set "${r.title}" as your ${label}!`);
                      }}
                      className="flex-1 py-2 px-3 rounded-lg bg-[#4A7C59] text-white text-xs font-semibold hover:bg-[#3D684A]"
                    >
                      Use in Plan
                    </button>
                    <button
                      type="button"
                      onClick={() => addRecipeIngredientsToGrocery(r)}
                      className="py-2 px-2.5 rounded-lg bg-white border border-[#E6E3DA] text-xs font-medium hover:bg-[#F3F1EA]"
                      title="Add ingredients to grocery list"
                    >
                      + Grocery
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TagEditor({
  label,
  items,
  value,
  onChange,
  onAdd,
  onRemove,
  placeholder,
}: {
  label: string;
  items: string[];
  value: string;
  onChange: (v: string) => void;
  onAdd: () => void;
  onRemove: (v: string) => void;
  placeholder: string;
}) {
  return (
    <div className="space-y-2">
      <label className="block text-xs font-medium text-[#5B625C]">{label}</label>
      <div className="flex gap-2">
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), onAdd())}
          placeholder={placeholder}
          className="flex-1 h-10 px-3 rounded-xl border border-[#E6E3DA] text-sm"
        />
        <button
          type="button"
          onClick={onAdd}
          className="px-3.5 rounded-xl bg-[#F3F1EA] text-sm font-medium hover:bg-[#E7E3D7]"
        >
          Add
        </button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {items.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => onRemove(item)}
            className="px-2.5 py-1 rounded-lg bg-[#FAF9F5] border border-[#E6E3DA] text-xs font-medium text-[#1F2421] hover:bg-[#EFECE3]"
          >
            {item} ×
          </button>
        ))}
      </div>
    </div>
  );
}
